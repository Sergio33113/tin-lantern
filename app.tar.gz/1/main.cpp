// Shopping Sessions pipeline. One native binary, no engine.
//
// Phases (all parallel over NCPU threads):
//   1. links   -> lock-free union-find inside the user table; the root of a
//                 person is always their byte-wise smallest ID.
//   2. parse   -> events become 24-byte records partitioned by hash(event_id);
//                 clicks become 16-byte records partitioned by person bucket.
//   3. dedup   -> each event partition is deduplicated in cache (smallest
//                 ingest_ts wins, then validity decides), survivors are
//                 scattered to person buckets.
//   4. buckets -> per bucket: radix sort by (person, ts), sessionize, credit
//                 and assist from the person's clicks, write user_daily rows.
//   5. merge the per-thread campaign tables and write campaign_daily.
//
// IDs are kept exact without storing strings: an ID of 2..9 bytes that starts
// with the expected letter (e/u/k) and holds only bytes 0x01..0x7F is packed
// into a u64 (the 8 bytes after the letter). Anything else goes through a
// mutex-protected interner and gets a key with bit 63 set.
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <algorithm>
#include <atomic>
#include <cerrno>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include <dirent.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <time.h>
#include <unistd.h>

#if defined(__x86_64__)
#include <immintrin.h>
#elif defined(__aarch64__)
#include <arm_neon.h>
#endif

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int32_t i32;
typedef int64_t i64;

#define likely(x) __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)

static inline u64 load64(const u8* p) { u64 v; memcpy(&v, p, 8); return v; }
static inline u32 load32(const u8* p) { u32 v; memcpy(&v, p, 4); return v; }

[[noreturn]] static void die(const char* fmt, ...) __attribute__((format(printf, 1, 2)));
static void die(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "fatal: ");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
    _exit(1);
}

static double now_s() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}
static double T0;
static bool VERBOSE = false;
// Profiling only (SS_STAGE): stop early in the parse. 1 scan, 2 split, 3 fields, 4 lookups, 0 everything.
static int STAGE = 0;
static void lap(const char* what) {
    if (!VERBOSE) return;
    rusage ru;
    getrusage(RUSAGE_SELF, &ru);
    long thp = -1, rss = -1;
    if (FILE* f = fopen("/proc/self/smaps_rollup", "r")) {
        char line[256];
        while (fgets(line, sizeof line, f)) {
            if (!strncmp(line, "AnonHugePages:", 14)) thp = atol(line + 14) / 1024;
            if (!strncmp(line, "Rss:", 4)) rss = atol(line + 4) / 1024;
        }
        fclose(f);
    }
    fprintf(stderr, "[%8.1f ms] %-32s user %6.0f ms, sys %6.0f ms, minflt %7ld, rss %5ld MB, thp %5ld MB\n",
            (now_s() - T0) * 1e3, what, ru.ru_utime.tv_sec * 1e3 + ru.ru_utime.tv_usec * 1e-3,
            ru.ru_stime.tv_sec * 1e3 + ru.ru_stime.tv_usec * 1e-3, ru.ru_minflt, rss, thp);
}

static inline u64 mix64(u64 x) {
    x ^= x >> 32;
    x *= 0xd6e8feb86659fd93ULL;
    x ^= x >> 32;
    x *= 0xd6e8feb86659fd93ULL;
    x ^= x >> 32;
    return x;
}

static inline u32 tz64(u64 x) {
#if defined(__BMI__)
    return (u32)_tzcnt_u64(x);
#else
    return x ? (u32)__builtin_ctzll(x) : 64;
#endif
}

// ---------------------------------------------------------------- constants
static const i64 DAYMS = 86400000;
static const i64 WEEKMS = 7 * DAYMS;
static const u32 GAPMS = 1800000;
static const u64 SLOW = 1ull << 63;
static const u32 INVALID = 0xFFFFFFFFu;  // well-formed row that fails validation
static const u32 DEAD = 0xFFFFFFFEu;     // lost the dedup
static const u32 CHUNK = 16384;
static const u32 NOCHUNK = 0xFFFFFFFFu;

enum : u8 { ST_FREE = 0, ST_EREC = 1, ST_MAIN = 2, ST_PURCH = 3, ST_CLICK = 4 };

// ---------------------------------------------------------------- globals
static int T = 8;
static i64 WS, WE, CWS;  // event window and click window start, ms
static i64 ING_BASE;     // seconds; ingest is stored as u32 relative to this
static i64 DAY0;         // epoch day of the window start
static u32 WS_OFF;       // ms of the window start into its day
static u32 NDAYS;

static std::atomic<bool> g_overflow{false};

// ---------------------------------------------------------------- calendar
static i32 YEAR_START[10000];
static u8 YEAR_LEAP[10000];
static const u16 CUM[2][13] = {{0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334},
                               {0, 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335}};
static const u8 DIM[2][13] = {{0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
                              {0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}};

static i64 days_from_civil(i64 y, i64 m, i64 d) {
    y -= m <= 2;
    i64 era = (y >= 0 ? y : y - 399) / 400;
    i64 yoe = y - era * 400;
    i64 doy = (153 * ((m + 9) % 12) + 2) / 5 + d - 1;
    i64 doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + doe - 719468;
}
static void init_calendar() {
    for (int y = 0; y < 10000; y++) {
        YEAR_START[y] = (i32)days_from_civil(y, 1, 1);
        YEAR_LEAP[y] = (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)) ? 1 : 0;
    }
}
static void civil_from_days(i64 z, int& y, int& m, int& d) {
    z += 719468;
    i64 era = (z >= 0 ? z : z - 146096) / 146097;
    i64 doe = z - era * 146097;
    i64 yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    i64 yy = yoe + era * 400;
    i64 doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    i64 mp = (5 * doy + 2) / 153;
    d = (int)(doy - (153 * mp + 2) / 5 + 1);
    m = (int)(mp < 10 ? mp + 3 : mp - 9);
    y = (int)(yy + (m <= 2));
}

// ---------------------------------------------------------------- numbers
static const u64 M7 = 0x7F7F7F7F7F7F7F7FULL, H8 = 0x8080808080808080ULL;

static inline bool all_digits8(u64 w) {
    return ((w & 0xF0F0F0F0F0F0F0F0ULL) | (((w + 0x0606060606060606ULL) & 0xF0F0F0F0F0F0F0F0ULL) >> 4)) ==
           0x3333333333333333ULL;
}
static inline u32 parse8(u64 w) {
    w = (w & 0x0F0F0F0F0F0F0F0FULL) * 2561 >> 8;
    w = (w & 0x00FF00FF00FF00FFULL) * 6553601 >> 16;
    return (u32)((w & 0x0000FFFF0000FFFFULL) * 42949672960001ULL >> 32);
}
// The first n (1..8) chars at s as an 8-char block with leading '0's.
static inline u64 block8(const u8* s, size_t n) {
    u64 w = load64(s);
    if (n == 8) return w;
    int sh = (int)(8 - n) * 8;
    return (w << sh) | (0x3030303030303030ULL >> (64 - sh));
}
// Digits only, any length >= 1. More than 18 significant digits saturates.
static inline bool parse_digits(const u8* s, size_t n, u64& out) {
    if (likely(n - 1 < 8)) {
        u64 w = block8(s, n);
        if (!all_digits8(w)) return false;
        out = parse8(w);
        return true;
    }
    if (n == 0) return false;
    if (likely(n <= 16)) {
        u64 lo = load64(s + n - 8), hi = block8(s, n - 8);
        if (!all_digits8(lo) || !all_digits8(hi)) return false;
        out = (u64)parse8(hi) * 100000000ULL + parse8(lo);
        return true;
    }
    for (size_t i = 0; i < n; i++)
        if ((u8)(s[i] - '0') > 9) return false;
    while (n > 1 && *s == '0') s++, n--;
    if (n > 18) { out = ~0ULL; return true; }
    u64 v = 0;
    for (size_t i = 0; i < n; i++) v = v * 10 + (s[i] - '0');
    out = v;
    return true;
}
// Digits with no leading zero (or the single digit 0), at most 7 of them.
static inline bool canon_num(const u8* s, size_t n, u32& out) {
    if (n - 1 >= 7) return false;
    u64 w = block8(s, n);
    if (!all_digits8(w)) return false;
    if (n > 1 && s[0] == '0') return false;
    out = parse8(w);
    return true;
}

// ---------------------------------------------------------------- timestamps
static const i64 BAD_TS = INT64_MIN;

// "YYYY-MM-DDTHH:MM:SS" at p[0..19). Seconds since the epoch.
static inline bool parse_dt19(const u8* p, i64& secs) {
    u64 a = load64(p) ^ 0x2D30302D30303030ULL;
    u64 b = load64(p + 8) ^ 0x30303A3030543030ULL;
    u32 c = (load32(p + 16) ^ 0x0030303Au) & 0x00FFFFFFu;
    u64 bad = (((a & M7) + 0x7F76767F76767676ULL) | a | ((b & M7) + 0x76767F76767F7676ULL) | b) & H8;
    u32 badc = (((c & 0x7F7F7Fu) + 0x76767Fu) | c) & 0x808080u;
    if (unlikely(bad | badc)) return false;
    u64 pa = a * 2561, pb = b * 2561;
    u32 pc = (c >> 8) * 2561;
    u32 year = (u32)((pa >> 8) & 0xFF) * 100 + (u32)((pa >> 24) & 0xFF);
    u32 mon = (u32)(pa >> 48) & 0xFF;
    u32 day = (u32)(pb >> 8) & 0xFF, hh = (u32)(pb >> 32) & 0xFF, mi = (u32)(pb >> 56) & 0xFF;
    u32 ss = (pc >> 8) & 0xFF;
    if (unlikely(mon - 1 >= 12 || hh > 23 || mi > 59 || ss > 59)) return false;
    u32 leap = YEAR_LEAP[year];
    if (unlikely(day - 1 >= DIM[leap][mon])) return false;
    i64 days = (i64)YEAR_START[year] + CUM[leap][mon] + day - 1;
    secs = days * 86400 + hh * 3600 + mi * 60 + ss;
    return true;
}

// Any of the three forms, as epoch milliseconds, or BAD_TS.
static inline i64 parse_ts(const u8* p, size_t n) {
    if (n == 20 && p[19] == 'Z') {
        i64 s;
        return parse_dt19(p, s) ? s * 1000 : BAD_TS;
    }
    if (n == 25 && (p[19] == '+' || p[19] == '-')) {
        i64 s;
        if (!parse_dt19(p, s)) return BAD_TS;
        u64 d = (load64(p + 17) ^ 0x30303A3030000000ULL) & 0xFFFFFFFFFF000000ULL;
        if ((((d & M7) + 0x76767F7676000000ULL) | d) & H8) return BAD_TS;
        u64 pd = d * 2561;
        u32 oh = (u32)(pd >> 32) & 0xFF, om = (u32)(pd >> 56) & 0xFF;
        if (oh > 23 || om > 59) return BAD_TS;
        i64 off = oh * 3600 + om * 60;
        return (p[19] == '+' ? s - off : s + off) * 1000;
    }
    u64 v;
    if (!parse_digits(p, n, v)) return BAD_TS;
    return v > (u64)INT64_MAX ? INT64_MAX : (i64)v;
}

// ---------------------------------------------------------------- interner
// IDs that do not fit the packed form. The strings are spread over many small
// maps by a hash, each with its own lock, so threads rarely wait on each other
// even when every ID in a dataset takes this path. A key is the map's number
// and the string's number inside it.
struct Interner {
    static const u32 STRIPES = 1024;
    struct Stripe {
        std::mutex m;
        std::unordered_map<std::string, u32> map;
        std::deque<std::string> strs;
        char pad[64];
    };
    Stripe* stripes = new Stripe[STRIPES];
    u64 intern(const u8* s, size_t n) {
        u64 h = 0xcbf29ce484222325ULL;
        for (size_t i = 0; i < n; i++) h = (h ^ s[i]) * 0x100000001b3ULL;
        u32 si = (u32)(mix64(h) >> 54);
        Stripe& st = stripes[si];
        std::lock_guard<std::mutex> g(st.m);
        auto it = st.map.find(std::string((const char*)s, n));
        u32 id;
        if (it != st.map.end()) {
            id = it->second;
        } else {
            id = (u32)st.strs.size();
            st.strs.emplace_back((const char*)s, n);
            st.map.emplace(st.strs.back(), id);
        }
        return SLOW | ((u64)si << 32) | id;
    }
    std::string get(u64 key) {
        Stripe& st = stripes[(u32)(key >> 32) & (STRIPES - 1)];
        std::lock_guard<std::mutex> g(st.m);
        return st.strs[(u32)key];
    }
};
static Interner g_intern;

static inline u64 id_key(const u8* s, size_t n, u8 prefix) {
    if (likely(n - 2 < 8 && s[0] == prefix)) {
        u64 w = load64(s + 1);
        unsigned k = (unsigned)n - 1;
        u64 m = k == 8 ? ~0ULL : ((1ULL << (8 * k)) - 1);
        w &= m;
        u64 z = w | ~m;
        if (likely((w & H8) == 0 && ((z - 0x0101010101010101ULL) & ~z & H8) == 0)) return w;
    }
    return g_intern.intern(s, n);
}
// The ID a key stands for, written to out (at least 16 bytes). Returns its length
// when the key is packed; an interned key returns 0 and fills `slow`.
static inline size_t key_str_fast(u64 key, u8 prefix, u8* out) {
    out[0] = prefix;
    memcpy(out + 1, &key, 8);
    return 1 + (size_t)((71 - __builtin_clzll(key)) >> 3);
}
static std::string key_string(u64 key, u8 prefix) {
    if (key & SLOW) return g_intern.get(key);
    u8 b[16];
    size_t n = key_str_fast(key, prefix, b);
    return std::string((const char*)b, n);
}
// Byte-wise order of the IDs two keys stand for.
static inline bool id_less(u64 a, u64 b, u8 prefix) {
    if (likely(!((a | b) & SLOW))) return __builtin_bswap64(a) < __builtin_bswap64(b);
    return key_string(a, prefix) < key_string(b, prefix);
}

// ---------------------------------------------------------------- user table
struct Slot {
    u64 key;     // 0 = empty
    u32 parent;  // 0 = root, else parent slot + 1
    u32 pad;
};
static Slot* TAB;
static u64 TABN;
static u64 TAB_LIMIT, TAB_QUOTA;
static std::atomic<u64> g_tab_used{0};
static u32 LW;   // log2(slots per person bucket)
static u32 PB;   // person buckets
static u32 CBITS;  // bits of a campaign index
static u32 PEB;  // log2(event partitions)

static inline u64 tab_home(u64 key) { return (u64)(((unsigned __int128)mix64(key) * TABN) >> 64); }

struct TabCounter {
    u64 pending = 0;
    inline void inserted() {
        if (unlikely(++pending >= TAB_QUOTA)) {
            u64 total = g_tab_used.fetch_add(pending, std::memory_order_relaxed) + pending;
            pending = 0;
            if (total > TAB_LIMIT) g_overflow.store(true, std::memory_order_relaxed);
        }
    }
};

// The slot of a key, inserting it if it is new.
static inline u32 tab_slot(u64 key, u64 i, TabCounter& tc) {
    for (;;) {
        u64 k = __atomic_load_n(&TAB[i].key, __ATOMIC_RELAXED);
        if (k == key) return (u32)i;
        if (k == 0) {
            if (unlikely(g_overflow.load(std::memory_order_relaxed))) return 0;
            u64 expect = 0;
            if (__atomic_compare_exchange_n(&TAB[i].key, &expect, key, false, __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
                tc.inserted();
                return (u32)i;
            }
            if (expect == key) return (u32)i;
        }
        if (++i == TABN) i = 0;
    }
}
static inline u32 tab_person(u32 slot) {
    u32 p = __atomic_load_n(&TAB[slot].parent, __ATOMIC_RELAXED);
    return p ? p - 1 : slot;
}

static inline u32 uf_find(u32 x) {
    for (;;) {
        u32 p = __atomic_load_n(&TAB[x].parent, __ATOMIC_RELAXED);
        if (!p) return x;
        u32 gp = __atomic_load_n(&TAB[p - 1].parent, __ATOMIC_RELAXED);
        if (!gp) return p - 1;
        __atomic_store_n(&TAB[x].parent, gp, __ATOMIC_RELAXED);  // path halving
        x = gp - 1;
    }
}
static inline u32 uf_find_ro(u32 x) {
    for (;;) {
        u32 p = __atomic_load_n(&TAB[x].parent, __ATOMIC_RELAXED);
        if (!p) return x;
        x = p - 1;
    }
}
// Joins two slots. The root with the larger ID goes under the smaller one, so
// a root is always the smallest ID of its tree.
static inline void uf_union(u32 a, u32 b) {
    for (;;) {
        u32 ra = uf_find(a), rb = uf_find(b);
        if (ra == rb) return;
        u64 ka = __atomic_load_n(&TAB[ra].key, __ATOMIC_RELAXED), kb = __atomic_load_n(&TAB[rb].key, __ATOMIC_RELAXED);
        if (id_less(kb, ka, 'u')) std::swap(ra, rb);
        u32 expect = 0;
        if (__atomic_compare_exchange_n(&TAB[rb].parent, &expect, ra + 1, false, __ATOMIC_ACQ_REL, __ATOMIC_RELAXED))
            return;
    }
}

// ---------------------------------------------------------------- lookups
static std::vector<std::string> CAT_NAME;  // index ncat = "unknown"
static std::vector<u32> CAT_RANK;          // byte-wise rank of the name
static u32 NCAT;                           // categories in the file; NCAT = unknown
static std::vector<u32> PROD_DIRECT;       // by number, for canonical p<digits>
static std::unordered_map<std::string, u32> PROD_MAP;
static bool WIDE_CAT = false;

static std::vector<std::string> CAMP_NAME, CAMP_CHANNEL;  // index NCAMP = organic
static u32 NCAMP;
static std::vector<i32> CAMP_DIRECT;
static std::unordered_map<std::string, u32> CAMP_MAP;

static inline u32 product_cat(const u8* s, size_t n) {
    u32 num;
    if (likely(n >= 2 && s[0] == 'p' && canon_num(s + 1, n - 1, num)))
        return num < PROD_DIRECT.size() ? PROD_DIRECT[num] : NCAT;
    auto it = PROD_MAP.find(std::string((const char*)s, n));
    return it == PROD_MAP.end() ? NCAT : it->second;
}
static inline i32 campaign_idx(const u8* s, size_t n) {
    u32 num;
    if (likely(n >= 3 && s[0] == 'c' && s[1] == '_' && canon_num(s + 2, n - 2, num)))
        return num < CAMP_DIRECT.size() ? CAMP_DIRECT[num] : -1;
    auto it = CAMP_MAP.find(std::string((const char*)s, n));
    return it == CAMP_MAP.end() ? -1 : (i32)it->second;
}

// ---------------------------------------------------------------- scanner
static const u32 WIN = 32768;
struct Scan {
    u32* cidx;
    u32* nidx;
    u64* qb;
    u32 nc, nn;
    void init() {
        cidx = (u32*)malloc((WIN + 128) * 4);
        nidx = (u32*)malloc((WIN + 128) * 4);
        qb = (u64*)malloc((WIN / 64 + 2) * 8);
    }
};

static inline void emit_bits(u32*& out, u64 bits, u32 base) {
    u32 cnt = (u32)__builtin_popcountll(bits);
    u32* o = out;
    for (int i = 0; i < 8; i++) {
        o[i] = base + tz64(bits);
        bits &= bits - 1;
    }
    if (unlikely(cnt > 8)) {
        for (u32 i = 8; i < cnt; i++) {
            o[i] = base + tz64(bits);
            bits &= bits - 1;
        }
    }
    out += cnt;
}
static inline void emit_bits_few(u32*& out, u64 bits, u32 base) {
    u32 cnt = (u32)__builtin_popcountll(bits);
    u32* o = out;
    o[0] = base + tz64(bits);
    bits &= bits - 1;
    o[1] = base + tz64(bits);
    bits &= bits - 1;
    if (unlikely(cnt > 2)) {
        for (u32 i = 2; i < cnt; i++) {
            o[i] = base + tz64(bits);
            bits &= bits - 1;
        }
    }
    out += cnt;
}

// Comma, newline and quote masks of the 64 bytes at p.
static inline void masks64(const u8* p, u64& cm, u64& nm, u64& qm) {
#if defined(__AVX2__)
    __m256i a = _mm256_loadu_si256((const __m256i*)p), b = _mm256_loadu_si256((const __m256i*)(p + 32));
    const __m256i vc = _mm256_set1_epi8(','), vn = _mm256_set1_epi8('\n'), vq = _mm256_set1_epi8('"');
    cm = (u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(a, vc)) |
         ((u64)(u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(b, vc)) << 32);
    nm = (u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(a, vn)) |
         ((u64)(u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(b, vn)) << 32);
    qm = (u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(a, vq)) |
         ((u64)(u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(b, vq)) << 32);
#elif defined(__aarch64__)
    static const u8 bitv[16] = {1, 2, 4, 8, 16, 32, 64, 128, 1, 2, 4, 8, 16, 32, 64, 128};
    const uint8x16_t bm = vld1q_u8(bitv);
    uint8x16_t v0 = vld1q_u8(p), v1 = vld1q_u8(p + 16), v2 = vld1q_u8(p + 32), v3 = vld1q_u8(p + 48);
    auto mm = [&](u8 ch) -> u64 {
        const uint8x16_t c = vdupq_n_u8(ch);
        uint8x16_t t0 = vandq_u8(vceqq_u8(v0, c), bm), t1 = vandq_u8(vceqq_u8(v1, c), bm);
        uint8x16_t t2 = vandq_u8(vceqq_u8(v2, c), bm), t3 = vandq_u8(vceqq_u8(v3, c), bm);
        uint8x16_t s0 = vpaddq_u8(t0, t1), s1 = vpaddq_u8(t2, t3);
        s0 = vpaddq_u8(s0, s1);
        s0 = vpaddq_u8(s0, s0);
        return vgetq_lane_u64(vreinterpretq_u64_u8(s0), 0);
    };
    cm = mm(',');
    nm = mm('\n');
    qm = mm('"');
#else
    cm = nm = qm = 0;
    for (int i = 0; i < 64; i++) {
        u8 ch = p[i];
        cm |= (u64)(ch == ',') << i;
        nm |= (u64)(ch == '\n') << i;
        qm |= (u64)(ch == '"') << i;
    }
#endif
}

// Indexes the commas and newlines of base[0..len) and keeps a quote bitmap.
// Reads up to 63 bytes past len: every input has zero padding after it.
static inline void scan_window(const u8* base, u32 len, Scan& sc) {
    u32* co = sc.cidx;
    u32* no = sc.nidx;
    u32 nblk = (len + 63) >> 6;
    for (u32 b = 0; b < nblk; b++) {
        u64 cm, nm, qm;
        masks64(base + ((size_t)b << 6), cm, nm, qm);
        if (unlikely(b == nblk - 1) && (len & 63)) {
            u64 keep = (1ULL << (len & 63)) - 1;
            cm &= keep, nm &= keep, qm &= keep;
        }
        sc.qb[b] = qm;
        emit_bits(co, cm, b << 6);
        emit_bits_few(no, nm, b << 6);
    }
    sc.nc = (u32)(co - sc.cidx);
    sc.nn = (u32)(no - sc.nidx);
    for (int i = 0; i < 16; i++) co[i] = 0xFFFFFFFFu;
}

static inline u32 count_quotes(const u64* qb, u32 a, u32 b) {  // [a, b), b > a
    u32 wa = a >> 6, wb = (b - 1) >> 6;
    u64 ma = ~0ULL << (a & 63), mb = ~0ULL >> (63 - ((b - 1) & 63));
    if (likely(wa == wb)) return (u32)__builtin_popcountll(qb[wa] & ma & mb);
    u32 n = (u32)__builtin_popcountll(qb[wa] & ma) + (u32)__builtin_popcountll(qb[wb] & mb);
    for (u32 w = wa + 1; w < wb; w++) n += (u32)__builtin_popcountll(qb[w]);
    return n;
}

// One line by the plain rules, for the rare lines the window scan cannot take
// (longer than a window, or the last line of a file with no newline).
template <int NF, class H>
static void slow_line(const u8* lb, const u8* le, H& h) {
    const u8* s[NF];
    const u8* e[NF];
    int nf = 0;
    const u8* fs = lb;
    for (const u8* p = lb;; p++) {
        if (p == le || *p == ',') {
            if (nf == NF) return;
            s[nf] = fs, e[nf] = p, nf++;
            if (p == le) break;
            fs = p + 1;
        }
    }
    if (nf != NF) return;
    for (int k = 0; k < NF; k++) {
        size_t nq = 0;
        for (const u8* p = s[k]; p < e[k]; p++) nq += *p == '"';
        if (!nq) continue;
        if (nq != 2 || e[k] - s[k] < 2 || *s[k] != '"' || e[k][-1] != '"') return;
        s[k]++, e[k]--;
    }
    h.row(s, e);
}

// Calls h.row(starts, ends) for every well-formed line that starts in
// [cs, ce) of the file. The first line of the file is its header.
template <int NF, class H>
static void parse_range(const u8* buf, u64 fsz, u64 cs, u64 ce, Scan& sc, H& h) {
    u64 pos;
    {
        u64 from = cs ? cs - 1 : 0;
        if (from >= fsz) return;
        const u8* nl = (const u8*)memchr(buf + from, '\n', fsz - from);
        if (!nl) return;
        pos = (u64)(nl - buf) + 1;
    }
    if (ce > fsz) ce = fsz;
    while (pos < ce) {
        u32 wlen = (u32)std::min<u64>(WIN, fsz - pos);
        const u8* base = buf + pos;
        scan_window(base, wlen, sc);
        if (unlikely(sc.nn == 0)) {
            u64 lend = fsz;
            if (pos + wlen < fsz) {
                const u8* nl = (const u8*)memchr(base + wlen, '\n', fsz - pos - wlen);
                if (nl) lend = (u64)(nl - buf);
            }
            slow_line<NF, H>(base, buf + lend, h);
            pos = lend + 1;
            continue;
        }
        if (unlikely(STAGE == 1)) {
            pos += sc.nidx[sc.nn - 1] + 1;
            continue;
        }
        const u32* ci = sc.cidx;
        u64 limit = ce - pos;
        u32 ls = 0, c = 0;
        const u32 nn = sc.nn;
        for (u32 k = 0; k < nn; k++) {
            if (unlikely(ls >= limit)) break;
            u32 nl = sc.nidx[k];
            if (likely(ci[c + NF - 2] < nl && ci[c + NF - 1] > nl)) {
                const u8* s[NF];
                const u8* e[NF];
                u32 fs = ls;
                for (int f = 0; f < NF - 1; f++) {
                    s[f] = base + fs;
                    e[f] = base + ci[c + f];
                    fs = ci[c + f] + 1;
                }
                s[NF - 1] = base + fs;
                e[NF - 1] = base + nl;
                c += NF - 1;
                u32 nq = count_quotes(sc.qb, ls, nl);
                if (nq) {
                    u32 nw = 0;
                    for (int f = 0; f < NF; f++) {
                        u32 w = (e[f] - s[f] >= 2) & (*s[f] == '"') & (e[f][-1] == '"');
                        s[f] += w, e[f] -= w, nw += w;
                    }
                    if (unlikely(2 * nw != nq)) {
                        ls = nl + 1;
                        continue;
                    }
                }
                if (likely(STAGE != 2)) h.row(s, e);
            } else {
                while (ci[c] < nl) c++;
            }
            ls = nl + 1;
        }
        pos += ls;
    }
}

// ---------------------------------------------------------------- arena
struct ChunkMeta {
    u32 part;
    u16 fill;  // bytes used
    u8 stream;
    u8 pad;
};
static u8* ARENA;
static ChunkMeta* META;
static std::atomic<u32> g_next_chunk{0};
static u32 MAX_CHUNKS;

static inline void nt_copy(u8* dst, const u8* src, u32 n) {  // n is a multiple of 64
#if defined(__AVX2__)
    for (u32 i = 0; i < n; i += 32) _mm256_stream_si256((__m256i*)(dst + i), _mm256_load_si256((const __m256i*)(src + i)));
#else
    memcpy(dst, src, n);
#endif
}
static inline void nt_done() {
#if defined(__x86_64__)
    _mm_sfence();
#endif
}

struct TCtx;
static u32 alloc_chunk(TCtx* t);

// Appends fixed-size records to P partitions through small staging buffers.
template <int REC, int UB>
struct Scatter {
    static constexpr int UR = UB / REC;
    static constexpr u32 CAP = (CHUNK / UB) * UB;
    struct Dst {
        u8* cur;
        u32 left;
        u32 chunk;
    };
    u32 P = 0;
    u8 stream = 0;
    TCtx* t = nullptr;
    u8* stage = nullptr;
    u8* fill = nullptr;
    Dst* dst = nullptr;

    void init(u32 P_, u8 stream_, TCtx* t_) {
        P = P_, stream = stream_, t = t_;
        stage = (u8*)aligned_alloc(64, (size_t)P * UB);
        fill = (u8*)calloc(P, 1);
        dst = (Dst*)malloc(sizeof(Dst) * P);
        for (u32 p = 0; p < P; p++) dst[p] = {nullptr, 0, NOCHUNK};
    }
    void release() {
        free(stage), free(fill), free(dst);
        stage = fill = nullptr, dst = nullptr;
    }
    inline u8* slot(u32 p) { return stage + (size_t)p * UB + (size_t)fill[p] * REC; }
    inline void commit(u32 p) {
        if (unlikely(++fill[p] == UR)) flush(p);
    }
    void newchunk(u32 p) {
        Dst& d = dst[p];
        if (d.chunk != NOCHUNK) META[d.chunk].fill = (u16)CAP;
        u32 id = alloc_chunk(t);
        META[id].part = p, META[id].fill = 0, META[id].stream = stream;
        d.cur = ARENA + (size_t)id * CHUNK, d.left = CAP, d.chunk = id;
    }
    inline void flush(u32 p) {
        Dst& d = dst[p];
        if (unlikely(d.left == 0)) newchunk(p);
        nt_copy(d.cur, stage + (size_t)p * UB, UB);
        d.cur += UB, d.left -= UB;
        fill[p] = 0;
    }
    void finish() {
        for (u32 p = 0; p < P; p++) {
            Dst& d = dst[p];
            if (fill[p]) {
                if (d.left == 0) newchunk(p);
                u32 nb = (u32)fill[p] * REC;
                memcpy(d.cur, stage + (size_t)p * UB, nb);
                d.cur += nb, d.left = 0;  // a partly filled unit ends the chunk
                fill[p] = 0;
            }
            if (d.chunk != NOCHUNK) {
                META[d.chunk].fill = (u16)(d.cur - (ARENA + (size_t)d.chunk * CHUNK));
                d = {nullptr, 0, NOCHUNK};
            }
        }
        nt_done();
    }
};

struct ERec {
    u64 ekey;
    u32 ingest;
    u32 person;
    u32 ts;
    u32 aux;
};
struct Purch {
    u64 key;
    u32 aux;
    u32 pad;
};
struct Click {
    u64 key;
    u64 ckey;
};

struct Lists {
    std::vector<u32> start, ids;
    u32 count(u32 p) const { return start[p + 1] - start[p]; }
};
static Lists build_lists(u8 stream, u32 P) {
    Lists L;
    u32 nch = g_next_chunk.load();
    L.start.assign(P + 2, 0);
    for (u32 i = 0; i < nch; i++)
        if (META[i].stream == stream && META[i].fill) L.start[META[i].part + 2]++;
    for (u32 p = 0; p < P; p++) L.start[p + 2] += L.start[p + 1];
    L.ids.resize(L.start[P + 1]);
    for (u32 i = 0; i < nch; i++)
        if (META[i].stream == stream && META[i].fill) L.ids[L.start[META[i].part + 1]++] = i;
    L.start.pop_back();
    return L;
}

// ---------------------------------------------------------------- parquet
struct Buf {
    u8* p = nullptr;
    size_t n = 0, cap = 0;
    inline void ensure(size_t extra) {
        if (unlikely(n + extra > cap)) {
            cap = std::max(cap * 2, n + extra + 4096);
            p = (u8*)realloc(p, cap);
        }
    }
    inline void put(const void* s, size_t len) {
        ensure(len);
        memcpy(p + n, s, len);
        n += len;
    }
    inline void u8v(u8 v) { ensure(1), p[n++] = v; }
    inline void u32v(u32 v) { put(&v, 4); }
    inline void i64v(i64 v) { put(&v, 8); }
    void varint(u64 v) {
        while (v >= 0x80) u8v((u8)(v | 0x80)), v >>= 7;
        u8v((u8)v);
    }
    void zz(i64 v) { varint(((u64)v << 1) ^ (u64)(v >> 63)); }
};

struct Thrift {
    Buf& b;
    int last = 0;
    std::vector<int> stack;
    explicit Thrift(Buf& b_) : b(b_) {}
    void fh(int id, int type) {
        int d = id - last;
        if (d > 0 && d <= 15) b.u8v((u8)((d << 4) | type));
        else b.u8v((u8)type), b.zz(id);
        last = id;
    }
    void i32f(int id, i32 v) { fh(id, 5), b.zz(v); }
    void i64f(int id, i64 v) { fh(id, 6), b.zz(v); }
    void strf(int id, const std::string& s) { fh(id, 8), b.varint(s.size()), b.put(s.data(), s.size()); }
    void listf(int id, int etype, size_t n) {
        fh(id, 9);
        if (n < 15) b.u8v((u8)((n << 4) | etype));
        else b.u8v((u8)(0xF0 | etype)), b.varint(n);
    }
    void open() { stack.push_back(last), last = 0; }
    void openf(int id) { fh(id, 12), open(); }
    void close() { b.u8v(0), last = stack.back(), stack.pop_back(); }
};

enum { PQ_INT32 = 1, PQ_INT64 = 2, PQ_BYTES = 6 };
struct PqCol {
    std::string name;
    int type;
    int conv;  // -1 none, 0 UTF8, 6 DATE
    bool optional;
};
struct PqPart {
    const u8* data;
    size_t len;
    const u8* defbits;  // optional columns: one bit per row, set when not null
};
struct PqFile {
    int fd = -1;
    u64 off = 0, nrows = 0;
    std::vector<PqCol> cols;
    struct CC {
        u64 page_off, size;
    };
    struct RG {
        u64 rows, bytes;
        std::vector<CC> cc;
    };
    std::vector<RG> rgs;

    static void write_all(int fd, iovec* iov, int cnt) {
        while (cnt) {
            ssize_t w = writev(fd, iov, std::min(cnt, 512));
            if (w < 0) {
                if (errno == EINTR) continue;
                die("write failed: %s", strerror(errno));
            }
            size_t left = (size_t)w;
            while (cnt && left >= iov->iov_len) left -= iov->iov_len, iov++, cnt--;
            if (cnt && left) iov->iov_base = (u8*)iov->iov_base + left, iov->iov_len -= left;
        }
    }
    void open(const std::string& path, std::vector<PqCol> c) {
        cols = std::move(c);
        fd = ::open(path.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0666);
        if (fd < 0) die("cannot create %s: %s", path.c_str(), strerror(errno));
        iovec v = {(void*)"PAR1", 4};
        write_all(fd, &v, 1);
        off = 4;
    }
    void row_group(u64 rows, const PqPart* parts) {
        size_t nc = cols.size();
        std::vector<Buf> hdr(nc), lvl(nc);
        std::vector<iovec> iov;
        RG rg;
        rg.rows = rows, rg.bytes = 0;
        u64 at = off;
        for (size_t i = 0; i < nc; i++) {
            size_t body = parts[i].len;
            if (cols[i].optional) {
                size_t nbytes = (size_t)((rows + 7) / 8);
                Buf rle;
                rle.varint(((u64)nbytes << 1) | 1);
                lvl[i].u32v((u32)(rle.n + nbytes));
                lvl[i].put(rle.p, rle.n);
                lvl[i].put(parts[i].defbits, nbytes);
                free(rle.p);
                body += lvl[i].n;
            }
            Thrift t(hdr[i]);
            t.i32f(1, 0);
            t.i32f(2, (i32)body);
            t.i32f(3, (i32)body);
            t.openf(5);
            t.i32f(1, (i32)rows);
            t.i32f(2, 0);
            t.i32f(3, 3);
            t.i32f(4, 3);
            t.close();
            hdr[i].u8v(0);
            u64 size = hdr[i].n + body;
            rg.cc.push_back({at, size});
            rg.bytes += size;
            at += size;
            iov.push_back({hdr[i].p, hdr[i].n});
            if (lvl[i].n) iov.push_back({lvl[i].p, lvl[i].n});
            if (parts[i].len) iov.push_back({(void*)parts[i].data, parts[i].len});
        }
        write_all(fd, iov.data(), (int)iov.size());
        for (size_t i = 0; i < nc; i++) free(hdr[i].p), free(lvl[i].p);
        off = at;
        nrows += rows;
        rgs.push_back(std::move(rg));
    }
    void close() {
        Buf f;
        Thrift t(f);
        t.i32f(1, 1);
        t.listf(2, 12, cols.size() + 1);
        t.open();
        t.strf(4, "schema");
        t.i32f(5, (i32)cols.size());
        t.close();
        for (auto& c : cols) {
            t.open();
            t.i32f(1, c.type);
            t.i32f(3, c.optional ? 1 : 0);
            t.strf(4, c.name);
            if (c.conv >= 0) {
                t.i32f(6, c.conv);
                t.openf(10);
                t.openf(c.conv == 0 ? 1 : 6);
                t.close();
                t.close();
            }
            t.close();
        }
        t.i64f(3, (i64)nrows);
        t.listf(4, 12, rgs.size());
        for (auto& rg : rgs) {
            t.open();
            t.listf(1, 12, cols.size());
            for (size_t i = 0; i < cols.size(); i++) {
                t.open();
                t.i64f(2, (i64)rg.cc[i].page_off);
                t.openf(3);
                t.i32f(1, cols[i].type);
                t.listf(2, 5, 2);
                f.zz(0), f.zz(3);
                t.listf(3, 8, 1);
                f.varint(cols[i].name.size()), f.put(cols[i].name.data(), cols[i].name.size());
                t.i32f(4, 0);
                t.i64f(5, (i64)rg.rows);
                t.i64f(6, (i64)rg.cc[i].size);
                t.i64f(7, (i64)rg.cc[i].size);
                t.i64f(9, (i64)rg.cc[i].page_off);
                t.close();
                t.close();
            }
            t.i64f(2, (i64)rg.bytes);
            t.i64f(3, (i64)rg.rows);
            t.close();
        }
        t.strf(6, "shopping-sessions native");
        f.u8v(0);
        u32 flen = (u32)f.n;
        f.u32v(flen);
        f.put("PAR1", 4);
        iovec v = {f.p, f.n};
        write_all(fd, &v, 1);
        free(f.p);
        ::close(fd);
        fd = -1;
    }
};

static std::string OUT_DIR;

static std::vector<PqCol> user_daily_cols() {
    return {{"user_id", PQ_BYTES, 0, false},  {"day", PQ_INT32, 6, false},          {"sessions", PQ_INT32, -1, false},
            {"events", PQ_INT32, -1, false},  {"revenue_cents", PQ_INT64, -1, false}, {"top_category", PQ_BYTES, 0, true}};
}

static const u32 RG_ROWS = 1 << 17;
struct UDWriter {
    PqFile f;
    bool opened = false;
    int tid = 0;
    Buf uid, day, ses, evs, rev, cat;
    std::vector<u8> defbits;
    u32 rows = 0;
    u64 total = 0;
    void init(int tid_) {
        tid = tid_;
        defbits.assign(RG_ROWS / 8 + 8, 0);
    }
    void flush() {
        if (!rows) return;
        if (!opened) {
            char name[64];
            snprintf(name, sizeof name, "/user_daily/part-%03d.parquet", tid);
            f.open(OUT_DIR + name, user_daily_cols());
            opened = true;
        }
        PqPart parts[6] = {{uid.p, uid.n, nullptr}, {day.p, day.n, nullptr}, {ses.p, ses.n, nullptr},
                           {evs.p, evs.n, nullptr}, {rev.p, rev.n, nullptr}, {cat.p, cat.n, defbits.data()}};
        f.row_group(rows, parts);
        total += rows;
        uid.n = day.n = ses.n = evs.n = rev.n = cat.n = 0;
        memset(defbits.data(), 0, defbits.size());
        rows = 0;
    }
    inline void row(u64 ukey, i32 d, u32 sessions, u32 events, i64 revenue, i32 topcat) {
        if (likely(!(ukey & SLOW))) {
            uid.ensure(16);
            u8* o = uid.p + uid.n;
            size_t len = key_str_fast(ukey, 'u', o + 4);
            u32 l32 = (u32)len;
            memcpy(o, &l32, 4);
            uid.n += 4 + len;
        } else {
            std::string s = g_intern.get(ukey);
            uid.u32v((u32)s.size());
            uid.put(s.data(), s.size());
        }
        day.put(&d, 4);
        ses.put(&sessions, 4);
        evs.put(&events, 4);
        rev.put(&revenue, 8);
        if (topcat >= 0) {
            const std::string& c = CAT_NAME[topcat];
            cat.u32v((u32)c.size());
            cat.put(c.data(), c.size());
            defbits[rows >> 3] |= (u8)(1u << (rows & 7));
        }
        if (++rows == RG_ROWS) flush();
    }
    void close() {
        flush();
        if (opened) f.close();
    }
};

// ---------------------------------------------------------------- threads
struct CampAcc {
    u32 sessions, purchasing, assisted, pad;
    i64 revenue;
};

struct TCtx {
    int tid = 0;
    Scan sc;
    u8* rbuf = nullptr;  // read buffer
    u64 rcap = 0;
    TabCounter tc;
    std::vector<u32> freelist;
    Scatter<24, 192> se;  // events by event partition
    Scatter<16, 64> sk;   // clicks by person bucket
    Scatter<8, 64> sm;    // surviving events by person bucket
    Scatter<16, 64> sp;   // surviving purchases by person bucket
    std::vector<u64> wide;  // purchases when a category does not fit 8 bits
    // dedup
    std::vector<u64> dkeys;
    std::vector<u32> drefs;
    // buckets
    std::vector<u64> A, B;
    std::vector<Purch> PV;
    std::vector<Click> CA, CB2;
    std::vector<CampAcc> cd;
    std::vector<u32> wcnt, wpos, wact;
    std::vector<i64> catsum;
    std::vector<u32> cattouched;
    UDWriter ud;
    u64 n_rows = 0, n_ok = 0, n_surv = 0, n_clicks = 0, n_sessions = 0;
};
static std::vector<TCtx*> TC;

static u32 alloc_chunk(TCtx* t) {
    if (!t->freelist.empty()) {
        u32 id = t->freelist.back();
        t->freelist.pop_back();
        return id;
    }
    u32 id = g_next_chunk.fetch_add(1, std::memory_order_relaxed);
    if (unlikely(id >= MAX_CHUNKS)) die("record arena exhausted");
    return id;
}

template <class F>
static void run_threads(F&& f) {
    std::vector<std::thread> th;
    for (int i = 1; i < T; i++) th.emplace_back([&f, i] { f(i); });
    f(0);
    for (auto& t : th) t.join();
}

// ---------------------------------------------------------------- inputs
struct MFile {
    const u8* p = nullptr;  // set when the file is memory-mapped (SS_MMAP=1)
    u64 size = 0;
    int fd = -1;  // otherwise it is read in pieces from this descriptor
};
static const u64 PADB = 1 << 16;
static bool USE_MMAP = false;

static MFile map_file(const std::string& path) {
    MFile m;
    int fd = open(path.c_str(), O_RDONLY | O_CLOEXEC);
    if (fd < 0) die("cannot open %s: %s", path.c_str(), strerror(errno));
    struct stat st;
    if (fstat(fd, &st)) die("cannot stat %s", path.c_str());
    m.size = (u64)st.st_size;
    if (m.size && !USE_MMAP) {
        posix_fadvise(fd, 0, 0, POSIX_FADV_SEQUENTIAL);
        m.fd = fd;
        return m;
    }
    if (m.size) {
        u64 rounded = (m.size + 4095) & ~4095ULL;
        u8* r = (u8*)mmap(nullptr, rounded + PADB, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
        if (r == MAP_FAILED) die("mmap failed for %s", path.c_str());
        if (mmap(r, m.size, PROT_READ, MAP_PRIVATE | MAP_FIXED, fd, 0) == MAP_FAILED)
            die("cannot map %s: %s", path.c_str(), strerror(errno));
        m.p = r;
    }
    close(fd);
    return m;
}
static std::vector<MFile> map_dir(const std::string& dir, u64& total) {
    std::vector<std::string> names;
    if (DIR* d = opendir(dir.c_str())) {
        while (dirent* e = readdir(d)) {
            std::string n = e->d_name;
            if (n.size() > 4 && n.compare(n.size() - 4, 4, ".csv") == 0) names.push_back(n);
        }
        closedir(d);
    }
    std::sort(names.begin(), names.end());
    std::vector<MFile> out;
    for (auto& n : names) {
        std::string path = dir + "/" + n;
        struct stat st;
        if (stat(path.c_str(), &st) || !S_ISREG(st.st_mode)) continue;
        MFile m = map_file(path);
        total += m.size;
        if (m.size) out.push_back(m);
    }
    return out;
}
static std::string read_small(const std::string& path) {
    int fd = open(path.c_str(), O_RDONLY);
    if (fd < 0) die("cannot open %s: %s", path.c_str(), strerror(errno));
    std::string s;
    char buf[65536];
    ssize_t r;
    while ((r = read(fd, buf, sizeof buf)) > 0) s.append(buf, (size_t)r);
    close(fd);
    return s;
}

struct Work {
    const MFile* f;
    u64 cs, ce;
    u8 kind;  // 0 events, 1 clicks, 2 links
};
static void add_work(std::vector<Work>& w, const std::vector<MFile>& files, u8 kind, u64 step) {
    if (!USE_MMAP) step = 128 << 10;  // small pieces, so the read buffer stays in cache
    for (auto& f : files)
        for (u64 at = 0; at < f.size; at += step) w.push_back({&f, at, std::min(f.size, at + step), kind});
}

// The bytes a piece of work needs, as (buf, len) and the piece's range inside
// it. A mapped file is used in place. Otherwise the piece is read into the
// thread's buffer, from one byte before it (to see whether a line starts at its
// first byte) to the end of the last line that starts in it.
static void work_view(TCtx& t, const Work& w, const u8*& buf, u64& len, u64& cs, u64& ce) {
    const MFile& f = *w.f;
    if (f.p) {
        buf = f.p, len = f.size, cs = w.cs, ce = w.ce;
        return;
    }
    const u64 from = w.cs ? w.cs - 1 : 0;
    u64 slack = 4096;
    for (;;) {
        u64 to = std::min(f.size, w.ce + slack);
        u64 need = to - from;
        if (t.rcap < need + 256) {
            free(t.rbuf);
            t.rcap = ((need + 256 + need / 8) + 4095) & ~(u64)4095;
            t.rbuf = (u8*)aligned_alloc(4096, t.rcap);
        }
        u64 got = 0;
        while (got < need) {
            ssize_t r = pread(f.fd, t.rbuf + got, need - got, (off_t)(from + got));
            if (r < 0) {
                if (errno == EINTR) continue;
                die("read failed: %s", strerror(errno));
            }
            if (r == 0) die("a file shrank while it was read");
            got += (u64)r;
        }
        memset(t.rbuf + need, 0, 256);
        u64 tail = w.ce - 1 - from;  // the last line of the piece ends at or after this byte
        if (to == f.size || memchr(t.rbuf + tail, '\n', need - tail)) {
            buf = t.rbuf, len = need, cs = w.cs ? 1 : 0, ce = w.ce - from;
            return;
        }
        slack *= 16;
    }
}

// ---------------------------------------------------------------- lookups from files
struct PairRows {
    std::vector<std::pair<std::string, std::string>> rows;
    void row(const u8** s, const u8** e) {
        rows.emplace_back(std::string((const char*)s[0], e[0] - s[0]), std::string((const char*)s[1], e[1] - s[1]));
    }
};
static PairRows read_pairs(const std::string& path) {
    std::string raw = read_small(path);
    size_t n = raw.size();
    raw.append(128, '\0');
    PairRows pr;
    const u8* b = (const u8*)raw.data();
    size_t pos = 0;
    bool header = true;
    while (pos < n) {
        const u8* nl = (const u8*)memchr(b + pos, '\n', n - pos);
        size_t end = nl ? (size_t)(nl - b) : n;
        if (!header) slow_line<2, PairRows>(b + pos, b + end, pr);
        header = false;
        pos = end + 1;
    }
    return pr;
}
static void load_products(const std::string& dir) {
    PairRows pr = read_pairs(dir + "/products.csv");
    std::unordered_map<std::string, u32> cats;
    std::vector<std::pair<std::string, u32>> prods;
    for (auto& r : pr.rows) {
        if (r.first.empty()) continue;
        auto it = cats.find(r.second);
        u32 c;
        if (it == cats.end()) c = (u32)CAT_NAME.size(), cats.emplace(r.second, c), CAT_NAME.push_back(r.second);
        else c = it->second;
        prods.emplace_back(r.first, c);
    }
    NCAT = (u32)CAT_NAME.size();
    CAT_NAME.push_back("unknown");
    WIDE_CAT = NCAT + 1 > 256;
    std::vector<u32> order(NCAT + 1);
    for (u32 i = 0; i <= NCAT; i++) order[i] = i;
    std::sort(order.begin(), order.end(), [](u32 a, u32 b) { return CAT_NAME[a] < CAT_NAME[b]; });
    CAT_RANK.resize(NCAT + 1);
    for (u32 i = 0; i <= NCAT; i++) CAT_RANK[order[i]] = i;
    for (auto& p : prods) {
        u32 num;
        std::string padded = p.first + std::string(16, '\0');
        const u8* s = (const u8*)padded.data();
        if (p.first.size() >= 2 && s[0] == 'p' && canon_num(s + 1, p.first.size() - 1, num)) {
            if (num >= PROD_DIRECT.size()) PROD_DIRECT.resize((size_t)num + 1, NCAT);
            PROD_DIRECT[num] = p.second;
        } else {
            PROD_MAP.emplace(p.first, p.second);
        }
    }
}
static void load_campaigns(const std::string& dir) {
    PairRows pr = read_pairs(dir + "/campaigns.csv");
    for (auto& r : pr.rows) {
        if (r.first.empty()) continue;
        u32 idx = (u32)CAMP_NAME.size();
        u32 num;
        std::string padded = r.first + std::string(16, '\0');
        const u8* s = (const u8*)padded.data();
        if (r.first.size() >= 3 && s[0] == 'c' && s[1] == '_' && canon_num(s + 2, r.first.size() - 2, num)) {
            if (num >= CAMP_DIRECT.size()) CAMP_DIRECT.resize((size_t)num + 1, -1);
            if (CAMP_DIRECT[num] >= 0) continue;
            CAMP_DIRECT[num] = (i32)idx;
        } else {
            if (!CAMP_MAP.emplace(r.first, idx).second) continue;
        }
        CAMP_NAME.push_back(r.first);
        CAMP_CHANNEL.push_back(r.second);
    }
    NCAMP = (u32)CAMP_NAME.size();
    CAMP_NAME.push_back("organic");
    CAMP_CHANNEL.push_back("organic");
}
static i64 manifest_ts(const std::string& js, const char* key) {
    size_t k = js.find(std::string("\"") + key + "\"");
    if (k == std::string::npos) die("manifest.json has no %s", key);
    size_t colon = js.find(':', k);
    size_t q1 = js.find('"', colon + 1);
    size_t q2 = js.find('"', q1 + 1);
    if (colon == std::string::npos || q1 == std::string::npos || q2 == std::string::npos) die("bad manifest.json");
    std::string v = js.substr(q1 + 1, q2 - q1 - 1);
    std::string padded = v + std::string(64, '\0');
    i64 t = parse_ts((const u8*)padded.data(), v.size());
    if (t == BAD_TS) die("bad %s in manifest.json", key);
    return t;
}

// ---------------------------------------------------------------- row handlers
struct LinkH {
    TCtx& t;
    inline void row(const u8** s, const u8** e) {
        size_t la = (size_t)(e[0] - s[0]), lb = (size_t)(e[1] - s[1]);
        if (!la || !lb) return;
        u64 ka = id_key(s[0], la, 'u'), kb = id_key(s[1], lb, 'u');
        u32 a = tab_slot(ka, tab_home(ka), t.tc);
        if (ka == kb) return;
        u32 b = tab_slot(kb, tab_home(kb), t.tc);
        if (unlikely(g_overflow.load(std::memory_order_relaxed))) return;
        uf_union(a, b);
    }
};

static const int BATCH = 16;

struct EventH {
    TCtx& t;
    struct Item {
        u64 ekey, ukey, home;
        u32 ingest, ts, aux;
    } items[BATCH];
    int n = 0;
    explicit EventH(TCtx& t_) : t(t_) {}

    inline void emit(u64 ekey, u32 ingest, u32 person, u32 ts, u32 aux) {
        u32 p = (u32)(mix64(ekey) >> (64 - PEB));
        ERec* r = (ERec*)t.se.slot(p);
        r->ekey = ekey, r->ingest = ingest, r->person = person, r->ts = ts, r->aux = aux;
        t.se.commit(p);
    }
    inline void flush() {
        for (int i = 0; i < n; i++) {
            Item& it = items[i];
            u32 person = tab_person(tab_slot(it.ukey, it.home, t.tc));
            if (unlikely(STAGE == 4)) {
                t.n_surv += person & 1;
                continue;
            }
            emit(it.ekey, it.ingest, person, it.ts, it.aux);
        }
        n = 0;
    }
    inline void row(const u8** s, const u8** e) {
        size_t l0 = (size_t)(e[0] - s[0]);
        if (unlikely(!l0)) return;
        t.n_rows++;
        u64 ekey = id_key(s[0], l0, 'e');
        i64 isec = 0;
        bool ok = (e[3] - s[3] == 20) && s[3][19] == 'Z' && parse_dt19(s[3], isec);
        if (unlikely(!ok)) isec = INT64_MAX / 4096;
        i64 irel = isec - ING_BASE;
        u32 ingest = irel < 0 ? 0 : irel > 0xFFFFFFFFLL ? 0xFFFFFFFFu : (u32)irel;
        size_t l1 = (size_t)(e[1] - s[1]);
        i64 ts = parse_ts(s[2], (size_t)(e[2] - s[2]));
        ok &= l1 != 0;
        ok &= (ts >= WS) & (ts < WE);
        size_t l4 = (size_t)(e[4] - s[4]);
        u32 ty = 3;
        if (l4 == 4) {
            u32 w = load32(s[4]);
            ty = w == 0x77656976u ? 0 : w == 0x74726163u ? 1 : 3;
        } else if (l4 == 8 && load64(s[4]) == 0x6573616863727570ULL) {
            ty = 2;
        }
        ok &= ty != 3;
        size_t l5 = (size_t)(e[5] - s[5]);
        ok &= l5 != 0;
        ok &= ((i64)((u64)isec * 1000 - (u64)ts) <= DAYMS);
        u32 aux = 0;
        if (unlikely(ty == 2) && ok) {
            u64 price;
            if (parse_digits(s[6], (size_t)(e[6] - s[6]), price) && price - 1 < 10000000) {
                u32 cat = product_cat(s[5], l5);
                if (likely(!WIDE_CAT)) {
                    aux = ((u32)price << 8) | cat;
                } else {
                    t.wide.push_back(price | ((u64)cat << 32));
                    if (t.wide.size() >= (1u << 27)) die("too many purchases for wide categories");
                    aux = ((u32)t.tid << 27) | (u32)t.wide.size();
                }
            } else {
                ok = false;
            }
        }
        if (unlikely(STAGE == 3)) {
            t.n_ok += ok + (aux & 1) + (ekey & 1) + (ingest & 1);
            return;
        }
        if (unlikely(!ok)) {
            emit(ekey, ingest, INVALID, 0, 0);
            return;
        }
        t.n_ok++;
        u64 ukey = id_key(s[1], l1, 'u');
        u64 home = tab_home(ukey);
        __builtin_prefetch(&TAB[home]);
        Item& it = items[n];
        it.ekey = ekey, it.ukey = ukey, it.home = home, it.ingest = ingest, it.ts = (u32)(ts - WS), it.aux = aux;
        if (++n == BATCH) flush();
    }
};

struct ClickH {
    TCtx& t;
    struct Item {
        u64 ckey, ukey, home;
        u32 ts, camp;
    } items[BATCH];
    int n = 0;
    explicit ClickH(TCtx& t_) : t(t_) {}
    inline void flush() {
        for (int i = 0; i < n; i++) {
            Item& it = items[i];
            u32 person = tab_person(tab_slot(it.ukey, it.home, t.tc));
            u32 b = person >> LW;
            u64 local = person & ((1u << LW) - 1);
            Click* c = (Click*)t.sk.slot(b);
            c->key = (((local << 31) | it.ts) << CBITS) | it.camp;
            c->ckey = it.ckey;
            t.sk.commit(b);
        }
        n = 0;
    }
    inline void row(const u8** s, const u8** e) {
        size_t l0 = (size_t)(e[0] - s[0]), l1 = (size_t)(e[1] - s[1]);
        if (unlikely(!l0 || !l1)) return;
        i64 ts = parse_ts(s[3], (size_t)(e[3] - s[3]));
        if (unlikely(ts < CWS || ts >= WE)) return;  // BAD_TS is below every window
        i32 camp = campaign_idx(s[2], (size_t)(e[2] - s[2]));
        if (unlikely(camp < 0)) return;
        t.n_clicks++;
        u64 ukey = id_key(s[1], l1, 'u');
        u64 home = tab_home(ukey);
        __builtin_prefetch(&TAB[home]);
        Item& it = items[n];
        it.ckey = id_key(s[0], l0, 'k'), it.ukey = ukey, it.home = home, it.ts = (u32)(ts - CWS), it.camp = (u32)camp;
        if (++n == BATCH) flush();
    }
};

// ---------------------------------------------------------------- sorting
static const int RB = 11;
template <class R>
static R* radix_sort(R* a, R* b, size_t n, int lo, int hi) {
    if (n < 2) return a;
    if (n < 96) {
        std::sort(a, a + n, [](const R& x, const R& y) { return *(const u64*)&x < *(const u64*)&y; });
        return a;
    }
    int np = (hi - lo + RB - 1) / RB;
    if (np > 6) np = 6;
    static thread_local u32 hist[6][1 << RB];
    memset(hist, 0, sizeof(u32) * (size_t)np * (1 << RB));
    for (size_t i = 0; i < n; i++) {
        u64 k = *(const u64*)&a[i] >> lo;
        for (int p = 0; p < np; p++) hist[p][(k >> (p * RB)) & ((1 << RB) - 1)]++;
    }
    for (int p = 0; p < np; p++) {
        u32* h = hist[p];
        int sh = lo + p * RB;
        if (h[(*(const u64*)&a[0] >> sh) & ((1 << RB) - 1)] == n) continue;
        u32 sum = 0;
        for (int d = 0; d < (1 << RB); d++) {
            u32 c = h[d];
            h[d] = sum;
            sum += c;
        }
        for (size_t i = 0; i < n; i++) {
            u64 k = *(const u64*)&a[i];
            b[h[(k >> sh) & ((1 << RB) - 1)]++] = a[i];
        }
        std::swap(a, b);
    }
    return a;
}

// ---------------------------------------------------------------- phases
static Lists L_EREC, L_MAIN, L_PURCH, L_CLICK;

static inline void decode_aux(u32 aux, u32& price, u32& cat) {
    if (likely(!WIDE_CAT)) {
        price = aux >> 8, cat = aux & 255;
    } else {
        u64 v = TC[aux >> 27]->wide[(aux & ((1u << 27) - 1)) - 1];
        price = (u32)v, cat = (u32)(v >> 32);
    }
}

static void dedup_partition(TCtx& t, u32 part) {
    u32 c0 = L_EREC.start[part], c1 = L_EREC.start[part + 1];
    if (c0 == c1) return;
    const u32* ids = L_EREC.ids.data() + c0;
    u32 nch = c1 - c0;
    size_t n = 0;
    for (u32 i = 0; i < nch; i++) n += META[ids[i]].fill / sizeof(ERec);
    size_t S = 1024;
    while (S < 2 * n) S <<= 1;
    if (t.dkeys.size() < S) t.dkeys.resize(S), t.drefs.resize(S);
    u64* keys = t.dkeys.data();
    u32* refs = t.drefs.data();
    memset(keys, 0, S * 8);
    size_t mask = S - 1;
    auto rec = [&](u32 ref) -> ERec* { return (ERec*)(ARENA + (size_t)ids[ref >> 10] * CHUNK) + (ref & 1023); };
    for (u32 i = 0; i < nch; i++) {
        ERec* r = (ERec*)(ARENA + (size_t)ids[i] * CHUNK);
        u32 cnt = META[ids[i]].fill / sizeof(ERec);
        for (u32 j = 0; j < cnt; j++) {
            u64 k = r[j].ekey;
            size_t s = (size_t)mix64(k) & mask;
            for (;;) {
                u64 x = keys[s];
                if (x == 0) {
                    keys[s] = k, refs[s] = (i << 10) | j;
                    break;
                }
                if (x == k) {
                    ERec* old = rec(refs[s]);
                    if (r[j].ingest < old->ingest) old->person = DEAD, refs[s] = (i << 10) | j;
                    else r[j].person = (r[j].person == INVALID ? INVALID : DEAD);
                    break;
                }
                s = (s + 1) & mask;
            }
        }
    }
    u32 lmask = (1u << LW) - 1;
    (void)lmask;
    for (u32 i = 0; i < nch; i++) {
        ERec* r = (ERec*)(ARENA + (size_t)ids[i] * CHUNK);
        u32 cnt = META[ids[i]].fill / sizeof(ERec);
        for (u32 j = 0; j < cnt; j++) {
            u32 person = r[j].person;
            if (person >= DEAD) continue;
            u32 b = person >> LW;
            u64 key = ((u64)person << 31) | r[j].ts;
            *(u64*)t.sm.slot(b) = key;
            t.sm.commit(b);
            if (unlikely(r[j].aux)) {
                Purch* pu = (Purch*)t.sp.slot(b);
                pu->key = key, pu->aux = r[j].aux, pu->pad = 0;
                t.sp.commit(b);
            }
            t.n_surv++;
        }
    }
    for (u32 i = 0; i < nch; i++) {
        META[ids[i]].stream = ST_FREE, META[ids[i]].fill = 0;
        t.freelist.push_back(ids[i]);
    }
}

template <class R>
static size_t gather(const Lists& L, u32 b, std::vector<R>& out) {
    u32 c0 = L.start[b], c1 = L.start[b + 1];
    size_t bytes = 0;
    for (u32 i = c0; i < c1; i++) bytes += META[L.ids[i]].fill;
    size_t n = bytes / sizeof(R);
    if (out.size() < n) out.resize(n + n / 4 + 64);
    u8* o = (u8*)out.data();
    for (u32 i = c0; i < c1; i++) {
        u32 f = META[L.ids[i]].fill;
        memcpy(o, ARENA + (size_t)L.ids[i] * CHUNK, f);
        o += f;
    }
    return n;
}

static void process_bucket(TCtx& t, u32 b) {
    size_t n = gather(L_MAIN, b, t.A);
    if (!n) return;
    if (t.B.size() < t.A.size()) t.B.resize(t.A.size());
    const u64* K = radix_sort<u64>(t.A.data(), t.B.data(), n, 0, 31 + (int)LW);

    size_t m = gather(L_PURCH, b, t.PV);
    Purch* PR = t.PV.data();
    if (m > 1) std::sort(PR, PR + m, [](const Purch& x, const Purch& y) { return x.key < y.key; });

    size_t c = gather(L_CLICK, b, t.CA);
    if (t.CB2.size() < t.CA.size()) t.CB2.resize(t.CA.size());
    const Click* C = radix_sort<Click>(t.CA.data(), t.CB2.data(), c, (int)CBITS, (int)(CBITS + 31 + LW));

    const u32 lmask = (1u << LW) - 1, cmask = (1u << CBITS) - 1;
    const int csh = 31 + (int)CBITS;
    const u32 ncampx = NCAMP + 1;
    CampAcc* cd = t.cd.data();
    u32* wcnt = t.wcnt.data();
    u32* wpos = t.wpos.data();
    u32* wact = t.wact.data();
    i64* catsum = t.catsum.data();
    auto cts = [&](size_t i) -> u32 { return (u32)(C[i].key >> CBITS) & 0x7FFFFFFFu; };
    auto ccamp = [&](size_t i) -> u32 { return (u32)C[i].key & cmask; };

    size_t i = 0, ip = 0, ic = 0;
    while (i < n) {
        const u32 person = (u32)(K[i] >> 31);
        const u64 local = person & lmask;
        while (ic < c && (C[ic].key >> csh) < local) ic++;
        size_t lo = ic, hi = ic;
        while (ic < c && (C[ic].key >> csh) == local) ic++;
        const size_t cend = ic;
        u32 nact = 0;

        i64 cur_day = INT64_MIN;
        u32 d_sessions = 0, d_events = 0;
        i64 d_rev = 0;
        u32 ntouched = 0;
        auto flush_day = [&]() {
            i32 top = -1;
            if (ntouched) {
                u32 best = t.cattouched[0];
                for (u32 q = 1; q < ntouched; q++) {
                    u32 x = t.cattouched[q];
                    if (catsum[x] > catsum[best] || (catsum[x] == catsum[best] && CAT_RANK[x] < CAT_RANK[best])) best = x;
                }
                top = (i32)best;
                for (u32 q = 0; q < ntouched; q++) catsum[t.cattouched[q]] = 0;
                ntouched = 0;
            }
            t.ud.row(TAB[person].key, (i32)cur_day, d_sessions, d_events, d_rev, top);
            d_sessions = d_events = 0, d_rev = 0;
        };

        while (i < n && (u32)(K[i] >> 31) == person) {
            const u32 start = (u32)K[i] & 0x7FFFFFFFu;
            u32 prev = start, cnt = 1;
            i++;
            while (i < n && (u32)(K[i] >> 31) == person) {
                u32 x = (u32)K[i] & 0x7FFFFFFFu;
                if (x - prev > GAPMS) break;
                prev = x, cnt++, i++;
            }
            const i64 day = DAY0 + (i64)(((u64)start + WS_OFF) / (u64)DAYMS);
            if (day != cur_day) {
                if (cur_day != INT64_MIN) flush_day();
                cur_day = day;
            }
            i64 rev = 0;
            u32 npurch = 0;
            const u64 last_key = ((u64)person << 31) | prev;
            while (ip < m && PR[ip].key <= last_key) {
                u32 price, cat;
                decode_aux(PR[ip].aux, price, cat);
                rev += price;
                if (catsum[cat] == 0) t.cattouched[ntouched++] = cat;
                catsum[cat] += price;
                npurch++, ip++;
            }
            d_sessions++, d_events += cnt, d_rev += rev;
            t.n_sessions++;

            // Clicks are kept on a clock that starts 7 days before the window.
            const u32 s_click = start + (u32)WEEKMS;
            while (hi < cend && cts(hi) <= s_click) {
                u32 a = ccamp(hi);
                if (wcnt[a]++ == 0) wpos[a] = nact, wact[nact++] = a;
                hi++;
            }
            while (lo < hi && cts(lo) < start) {
                u32 a = ccamp(lo);
                if (--wcnt[a] == 0) {
                    u32 p = wpos[a], lastc = wact[--nact];
                    wact[p] = lastc, wpos[lastc] = p;
                }
                lo++;
            }
            u32 camp = NCAMP;
            if (hi > lo) {
                size_t best = hi - 1;
                const u32 tt = cts(best);
                for (size_t q = hi - 1; q-- > lo && cts(q) == tt;)
                    if (id_less(C[q].ckey, C[best].ckey, 'k')) best = q;
                camp = ccamp(best);
            }
            CampAcc* row = cd + (size_t)(day - DAY0) * ncampx;
            row[camp].sessions++;
            row[camp].purchasing += npurch > 0;
            row[camp].revenue += rev;
            for (u32 q = 0; q < nact; q++) row[wact[q]].assisted++;
        }
        flush_day();
        for (u32 q = 0; q < nact; q++) wcnt[wact[q]] = 0;
    }
}

// ---------------------------------------------------------------- run
static std::vector<MFile> F_EVENTS, F_CLICKS, F_LINKS;
static std::thread g_products_thread;  // products.csv loads while the links are joined
static u64 B_EVENTS, B_CLICKS, B_LINKS;

// Reserves zeroed memory. `fallback` is a smaller size to try when the kernel
// refuses the first one (strict overcommit); 0 means there is none.
static u64 map_or_die(void** out, u64 bytes, bool huge, u64 fallback = 0) {
    bytes = (bytes + (2u << 20) - 1) & ~((u64)(2u << 20) - 1);
    void* p = mmap(nullptr, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (p == MAP_FAILED && fallback) {
        bytes = (fallback + (2u << 20) - 1) & ~((u64)(2u << 20) - 1);
        p = mmap(nullptr, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    }
    if (p == MAP_FAILED) die("cannot reserve %llu MB", (unsigned long long)(bytes >> 20));
#ifdef MADV_HUGEPAGE
    if (huge && !getenv("SS_NOHUGE")) madvise(p, bytes, MADV_HUGEPAGE);
#endif
    *out = p;
    return bytes;
}

static bool run(u64 tab_slots) {
    g_overflow.store(false);
    g_tab_used.store(0);
    g_next_chunk.store(0);

    // Sizes. Every bound below is a worst case for the bytes on disk.
    u64 est_rows = B_EVENTS / 74 + 1;
    u32 cb = 1;
    while ((1ull << cb) < (u64)NCAMP + 1) cb++;
    CBITS = cb;
    if (CBITS > 26) die("too many campaigns");
    double per_slot = (double)est_rows / (double)tab_slots;
    int lw = 12;
    {
        double want = 14000.0 / std::max(per_slot, 0.001);
        lw = 0;
        while ((double)(1ull << (lw + 1)) <= want * 1.41 && lw < 13) lw++;  // nearest power of two
        if (lw < 6) lw = 6;
        if (lw > 33 - (int)CBITS) lw = 33 - (int)CBITS;
    }
    LW = (u32)lw;
    TABN = (tab_slots + (1ull << LW) - 1) >> LW << LW;
    if (TABN >= 0xFFFF0000ull) die("too many user IDs");
    PB = (u32)(TABN >> LW);
    TAB_LIMIT = TABN / 4 * 3;
    TAB_QUOTA = std::max<u64>(1, TABN / (16 * (u64)T));
    PEB = 4;
    while (PEB < 13 && (est_rows >> PEB) > 20000) PEB++;
    u32 PE = 1u << PEB;

    void* tabp;
    u64 tab_bytes = map_or_die(&tabp, TABN * sizeof(Slot), true);
    TAB = (Slot*)tabp;

    // Records per input byte, at worst: 24 bytes for an 8-byte event line, and
    // far less for the survivors and the clicks, which need valid fields.
    u64 arena_bytes = B_EVENTS * 9 / 2 + B_CLICKS * 2 + (u64)(PE + 3ull * PB) * (u64)T * CHUNK + (64u << 20);
    void* arenap;
    arena_bytes = map_or_die(&arenap, arena_bytes, true,
                             B_EVENTS + B_CLICKS + (u64)(PE + 3ull * PB) * (u64)T * CHUNK + (64u << 20));
    ARENA = (u8*)arenap;
    MAX_CHUNKS = (u32)std::min<u64>(arena_bytes / CHUNK, 0xFFFFFFF0u);
    void* metap;
    u64 meta_bytes = map_or_die(&metap, (u64)MAX_CHUNKS * sizeof(ChunkMeta), false);
    META = (ChunkMeta*)metap;

    if (getenv("SS_PRETOUCH")) {
        // For measuring: touch the memory first, then restart the clock, so the
        // times show the work without the cost of first-touch page faults.
#ifndef MADV_POPULATE_WRITE
#define MADV_POPULATE_WRITE 23
#endif
        madvise(tabp, tab_bytes, MADV_POPULATE_WRITE);
        madvise(arenap, std::min<u64>(arena_bytes, B_EVENTS * 3 / 2 + B_CLICKS + (256u << 20)), MADV_POPULATE_WRITE);
        T0 = now_s();
        lap("memory touched, clock restarted");
    }
    if (VERBOSE)
        fprintf(stderr, "threads %d, table %llu slots, %u buckets of %u, %u event partitions, %u campaign bits\n", T,
                (unsigned long long)TABN, PB, 1u << LW, PE, CBITS);

    TC.clear();
    for (int i = 0; i < T; i++) {
        TCtx* t = new TCtx();
        t->tid = i;
        t->sc.init();
        TC.push_back(t);
    }
    auto cleanup = [&]() {
        for (auto t : TC) {
            t->se.release(), t->sk.release(), t->sm.release(), t->sp.release();
            free(t->sc.cidx), free(t->sc.nidx), free(t->sc.qb);
            delete t;
        }
        TC.clear();
        munmap(tabp, tab_bytes), munmap(arenap, arena_bytes), munmap(metap, meta_bytes);
    };

    // ---- links
    {
        std::vector<Work> work;
        add_work(work, F_LINKS, 2, 1 << 20);
        std::atomic<size_t> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            LinkH h{t};
            for (;;) {
                size_t i = next.fetch_add(1);
                if (i >= work.size() || g_overflow.load()) break;
                const u8* buf;
                u64 len, cs, ce;
                work_view(t, work[i], buf, len, cs, ce);
                parse_range<2, LinkH>(buf, len, cs, ce, t.sc, h);
            }
        });
        if (g_overflow.load()) return cleanup(), false;
        lap("links parsed");
        // Point every linked ID straight at its root.
        std::atomic<u64> at{0};
        const u64 step = 1 << 16;
        run_threads([&](int) {
            for (;;) {
                u64 a = at.fetch_add(step);
                if (a >= TABN) break;
                u64 b = std::min(TABN, a + step);
                for (u64 i = a; i < b; i++)
                    if (TAB[i].parent) TAB[i].parent = uf_find_ro((u32)i) + 1;
            }
        });
    }
    lap("links joined");

    // ---- events and clicks
    if (g_products_thread.joinable()) g_products_thread.join();
    {
        std::vector<Work> work;
        add_work(work, F_EVENTS, 0, 4 << 20);
        add_work(work, F_CLICKS, 1, 4 << 20);
        std::atomic<size_t> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            t.se.init(PE, ST_EREC, &t);
            t.sk.init(PB, ST_CLICK, &t);
            EventH eh(t);
            ClickH ch(t);
            for (;;) {
                size_t i = next.fetch_add(1);
                if (i >= work.size() || g_overflow.load()) break;
                const Work& w = work[i];
                const u8* buf;
                u64 len, cs, ce;
                work_view(t, w, buf, len, cs, ce);
                if (w.kind == 0) {
                    parse_range<7, EventH>(buf, len, cs, ce, t.sc, eh);
                    eh.flush();
                } else {
                    parse_range<4, ClickH>(buf, len, cs, ce, t.sc, ch);
                    ch.flush();
                }
            }
            t.se.finish();
            t.sk.finish();
        });
        if (g_overflow.load()) return cleanup(), false;
    }
    lap("events and clicks parsed");

    // ---- dedup, then scatter the survivors by person
    {
        L_EREC = build_lists(ST_EREC, PE);
        std::atomic<u32> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            t.sm.init(PB, ST_MAIN, &t);
            t.sp.init(PB, ST_PURCH, &t);
            for (;;) {
                u32 p = next.fetch_add(1);
                if (p >= PE) break;
                dedup_partition(t, p);
            }
            t.sm.finish();
            t.sp.finish();
        });
    }
    lap("events deduplicated");

    // ---- sessions, attribution, user_daily
    {
        L_MAIN = build_lists(ST_MAIN, PB);
        L_PURCH = build_lists(ST_PURCH, PB);
        L_CLICK = build_lists(ST_CLICK, PB);
        std::vector<u32> order(PB);
        for (u32 b = 0; b < PB; b++) order[b] = b;
        std::sort(order.begin(), order.end(), [](u32 a, u32 b) { return L_MAIN.count(a) > L_MAIN.count(b); });
        std::atomic<u32> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            t.cd.assign((size_t)NDAYS * (NCAMP + 1), CampAcc{0, 0, 0, 0, 0});
            t.wcnt.assign(NCAMP + 1, 0), t.wpos.assign(NCAMP + 1, 0), t.wact.assign(NCAMP + 1, 0);
            t.catsum.assign(NCAT + 1, 0), t.cattouched.assign(NCAT + 1, 0);
            t.ud.init(tid);
            for (;;) {
                u32 k = next.fetch_add(1);
                if (k >= PB) break;
                if (!L_MAIN.count(order[k])) break;
                process_bucket(t, order[k]);
            }
            t.ud.close();
        });
    }
    lap("sessions done, user_daily written");

    // ---- campaign_daily
    {
        size_t cells = (size_t)NDAYS * (NCAMP + 1);
        std::vector<CampAcc>& acc = TC[0]->cd;
        for (int i = 1; i < T; i++) {
            const CampAcc* o = TC[i]->cd.data();
            for (size_t k = 0; k < cells; k++) {
                acc[k].sessions += o[k].sessions, acc[k].purchasing += o[k].purchasing;
                acc[k].assisted += o[k].assisted, acc[k].revenue += o[k].revenue;
            }
        }
        Buf cid, chan, day, ses, pur, rev, ast;
        u64 rows = 0;
        for (u32 d = 0; d < NDAYS; d++) {
            for (u32 c = 0; c <= NCAMP; c++) {
                const CampAcc& a = acc[(size_t)d * (NCAMP + 1) + c];
                if (!a.sessions && !a.assisted) continue;
                cid.u32v((u32)CAMP_NAME[c].size()), cid.put(CAMP_NAME[c].data(), CAMP_NAME[c].size());
                chan.u32v((u32)CAMP_CHANNEL[c].size()), chan.put(CAMP_CHANNEL[c].data(), CAMP_CHANNEL[c].size());
                day.u32v((u32)(i32)(DAY0 + d));
                ses.i64v(a.sessions), pur.i64v(a.purchasing), rev.i64v(a.revenue), ast.i64v(a.assisted);
                rows++;
            }
        }
        PqFile f;
        f.open(OUT_DIR + "/campaign_daily/part-000.parquet",
               {{"campaign_id", PQ_BYTES, 0, false}, {"channel", PQ_BYTES, 0, false}, {"day", PQ_INT32, 6, false},
                {"sessions", PQ_INT64, -1, false}, {"purchasing_sessions", PQ_INT64, -1, false},
                {"revenue_cents", PQ_INT64, -1, false}, {"assisted_sessions", PQ_INT64, -1, false}});
        if (rows) {
            PqPart parts[7] = {{cid.p, cid.n, nullptr}, {chan.p, chan.n, nullptr}, {day.p, day.n, nullptr},
                               {ses.p, ses.n, nullptr}, {pur.p, pur.n, nullptr}, {rev.p, rev.n, nullptr},
                               {ast.p, ast.n, nullptr}};
            f.row_group(rows, parts);
        }
        f.close();
        u64 ud_rows = 0;
        for (auto t : TC) ud_rows += t->ud.total;
        if (!ud_rows) {
            PqFile e;
            e.open(OUT_DIR + "/user_daily/part-000.parquet", user_daily_cols());
            e.close();
        }
        if (VERBOSE) {
            u64 r = 0, ok = 0, sv = 0, ck = 0, ss = 0;
            for (auto t : TC) r += t->n_rows, ok += t->n_ok, sv += t->n_surv, ck += t->n_clicks, ss += t->n_sessions;
            fprintf(stderr,
                    "event rows %llu, valid %llu, surviving %llu, clicks %llu, sessions %llu, user_daily rows %llu, "
                    "campaign_daily rows %llu, chunks %u, ids %llu+\n",
                    (unsigned long long)r, (unsigned long long)ok, (unsigned long long)sv, (unsigned long long)ck,
                    (unsigned long long)ss, (unsigned long long)ud_rows, (unsigned long long)rows, g_next_chunk.load(),
                    (unsigned long long)g_tab_used.load());
        }
    }
    lap("campaign_daily written");

    // Hand the memory back from every thread at once. Left alone, the kernel
    // frees it page by page on one core while the process exits.
    if (!getenv("SS_NOFREE")) {
        const u64 two = 2u << 20;
        u64 used = std::min<u64>(arena_bytes, ((u64)g_next_chunk.load() * CHUNK + two - 1) & ~(two - 1));
        run_threads([&](int tid) {
            auto slice = [&](void* base, u64 bytes) {
                u64 per = (bytes / (u64)T) & ~(two - 1);
                u64 a = per * (u64)tid, b = tid == T - 1 ? bytes : per * (u64)(tid + 1);
                if (b > a) madvise((u8*)base + a, b - a, MADV_DONTNEED);
            };
            slice(tabp, tab_bytes);
            slice(arenap, used);
        });
        lap("memory released");
    }
    return true;
}

#ifdef SS_PROBE
// A probe build (-DSS_PROBE). It prints what the scoring machine looks like and
// how long each step takes there, then leaves an empty campaign table on
// purpose: the dev check fails, the scorer hands the log back, and the run can
// never be scored. Never the default build.
static void probe_cat(const char* path, const char* only = nullptr, int max_lines = 6) {
    FILE* f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "== %s: cannot open\n", path);
        return;
    }
    char line[8192];
    int n = 0;
    while (n < max_lines && fgets(line, sizeof line, f)) {
        if (only && !strstr(line, only)) continue;
        size_t len = strlen(line);
        if (len && line[len - 1] == '\n') line[len - 1] = 0;
        fprintf(stderr, "== %s: %s\n", path, line);
        n++;
    }
    fclose(f);
}
static void probe_touch(size_t mb, int threads, bool huge) {
    size_t n = mb << 20;
    char* p = (char*)mmap(nullptr, n, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (p == MAP_FAILED) return;
    if (huge) madvise(p, n, MADV_HUGEPAGE);
    double t0 = now_s();
    std::vector<std::thread> th;
    for (int i = 0; i < threads; i++)
        th.emplace_back([=] {
            for (size_t x = n / threads * i, b = n / threads * (i + 1); x < b; x += 4096) p[x] = 1;
        });
    for (auto& t : th) t.join();
    double t1 = now_s();
    long thp = -1;
    if (FILE* f = fopen("/proc/self/smaps_rollup", "r")) {
        char line[256];
        while (fgets(line, sizeof line, f))
            if (!strncmp(line, "AnonHugePages:", 14)) thp = atol(line + 14) / 1024;
        fclose(f);
    }
    double t2 = now_s();
    munmap(p, n);
    double t3 = now_s();
    fprintf(stderr, "probe touch %zu MB, %d threads, madvise huge %d: %.1f ms (%.2f us per 4K), huge now %ld MB, unmap %.1f ms\n",
            mb, threads, (int)huge, (t1 - t0) * 1e3, (t1 - t0) * 1e6 / (double)(n / 4096), thp, (t3 - t2) * 1e3);
}
static void probe_clock(int threads) {
    const u64 N = 200000000ull;
    std::vector<std::thread> th;
    std::vector<double> secs((size_t)threads);
    for (int i = 0; i < threads; i++)
        th.emplace_back([&secs, i, N] {
            double t0 = now_s();
            u64 x = (u64)i + 1;
            for (u64 k = 0; k < N; k++) x = x * 6364136223846793005ull + 1442695040888963407ull;
            secs[(size_t)i] = now_s() - t0 + (x == 42 ? 1e-12 : 0);
        });
    for (auto& t : th) t.join();
    double worst = 0, best = 1e9;
    for (double s : secs) worst = std::max(worst, s), best = std::min(best, s);
    fprintf(stderr, "probe clock, %d threads: %.2f to %.2f GHz (4-cycle multiply-add chain)\n", threads,
            (double)N * 4 / worst / 1e9, (double)N * 4 / best / 1e9);
}
static void probe_env() {
    fprintf(stderr, "==== probe: the machine ====\n");
    probe_cat("/proc/version");
    probe_cat("/proc/cpuinfo", "model name", 1);
    probe_cat("/proc/cpuinfo", "flags", 1);
    probe_cat("/proc/cpuinfo", "cpu MHz", 16);
    probe_cat("/proc/cpuinfo", "cache size", 1);
    probe_cat("/sys/devices/system/cpu/cpu0/cache/index1/size");
    probe_cat("/sys/devices/system/cpu/cpu0/cache/index2/size");
    probe_cat("/sys/devices/system/cpu/cpu0/cache/index3/size");
    probe_cat("/sys/devices/system/cpu/cpu0/topology/thread_siblings_list");
    probe_cat("/sys/devices/system/cpu/online");
    probe_cat("/proc/self/status", "Cpus_allowed_list", 1);
    fprintf(stderr, "hardware_concurrency %u, threads %d, NCPU=%s, MEM_GB=%s\n", std::thread::hardware_concurrency(), T,
            getenv("NCPU") ? getenv("NCPU") : "", getenv("MEM_GB") ? getenv("MEM_GB") : "");
    probe_cat("/sys/kernel/mm/transparent_hugepage/enabled");
    probe_cat("/sys/kernel/mm/transparent_hugepage/defrag");
    probe_cat("/sys/kernel/mm/transparent_hugepage/khugepaged/defrag");
    probe_cat("/proc/sys/vm/overcommit_memory");
    probe_cat("/proc/meminfo", nullptr, 7);
    probe_cat("/proc/meminfo", "Huge", 8);
    probe_cat("/proc/meminfo", "Dirty", 1);
    probe_cat("/sys/fs/cgroup/memory.max");
    probe_cat("/sys/fs/cgroup/memory.high");
    probe_cat("/sys/fs/cgroup/cpu.max");
    probe_cat("/sys/fs/cgroup/cpuset.cpus.effective");
    probe_cat("/sys/fs/cgroup/memory/memory.limit_in_bytes");
    probe_cat("/sys/fs/cgroup/cpu/cpu.cfs_quota_us");
    probe_cat("/proc/self/mountinfo", " /data ", 2);
    probe_cat("/proc/self/mountinfo", " /output ", 2);
    probe_cat("/proc/self/mountinfo", " /scratch ", 2);
    probe_cat("/proc/self/mountinfo", " /tmp ", 2);
    probe_cat("/proc/self/mountinfo", " / ", 2);
    probe_cat("/proc/loadavg");

    // Was the input already in the page cache when the container started?
    const MFile* big = nullptr;
    u64 files = 0, cached = 0, pages = 0;
    for (auto* v : {&F_EVENTS, &F_CLICKS, &F_LINKS})
        for (auto& f : *v) {
            if (!big || f.size > big->size) big = &f;
            if (f.fd < 0) continue;
            void* m = mmap(nullptr, f.size, PROT_READ, MAP_SHARED, f.fd, 0);
            if (m == MAP_FAILED) continue;
            size_t np = (size_t)((f.size + 4095) / 4096);
            std::vector<unsigned char> vec(np);
            if (!mincore(m, f.size, vec.data()))
                for (unsigned char c : vec) cached += c & 1;
            pages += np, files++;
            munmap(m, f.size);
        }
    fprintf(stderr, "probe input: %llu files, %llu MB, %.1f%% of pages already in the page cache\n",
            (unsigned long long)files, (unsigned long long)(pages >> 8), pages ? 100.0 * (double)cached / (double)pages : 0.0);

    // Reading speed, the way the pipeline reads: 128 KB pieces of the largest file.
    if (big && big->fd >= 0) {
        u8* buf = (u8*)aligned_alloc(4096, 128 << 10);
        for (int pass = 0; pass < 2; pass++) {
            double t0 = now_s();
            u64 got = 0, lim = std::min<u64>(big->size, 1ull << 30);
            while (got < lim) {
                ssize_t r = pread(big->fd, buf, 128 << 10, (off_t)got);
                if (r <= 0) break;
                got += (u64)r;
            }
            double dt = now_s() - t0;
            fprintf(stderr, "probe read pass %d: %llu MB in %.1f ms, %.2f GB/s on one thread\n", pass,
                    (unsigned long long)(got >> 20), dt * 1e3, (double)got / dt / 1e9);
        }
        free(buf);
    }
    probe_touch(256, 1, false);
    probe_touch(256, T, false);
    probe_touch(256, 1, true);
    probe_touch(256, T, true);
    probe_clock(1);
    probe_clock(T / 2 > 0 ? T / 2 : 1);
    probe_clock(T);
}
#endif

int main() {
    T0 = now_s();
    VERBOSE = getenv("SS_VERBOSE") != nullptr;
#ifdef SS_PROBE
    VERBOSE = true;
#endif
    const char* e;
    std::string data = (e = getenv("DATA_DIR")) && *e ? e : "/data";
    OUT_DIR = (e = getenv("OUTPUT_DIR")) && *e ? e : "/output";
    int ncpu = (e = getenv("NCPU")) ? atoi(e) : 0;
    if (ncpu <= 0) ncpu = (int)std::thread::hardware_concurrency();
    T = std::max(1, std::min(ncpu, 32));
    if ((e = getenv("SS_THREADS")) && atoi(e) > 0) T = std::min(atoi(e), 32);

    init_calendar();
    std::string manifest = read_small(data + "/manifest.json");
    WS = manifest_ts(manifest, "window_start");
    WE = manifest_ts(manifest, "window_end");
    if (WE <= WS) die("window_end is not after window_start");
    if (WE - WS + WEEKMS >= (1LL << 31)) die("a window longer than 17 days is not supported");
    CWS = WS - WEEKMS;
    i64 ws_sec = WS >= 0 ? WS / 1000 : -((-WS + 999) / 1000);
    ING_BASE = ws_sec - (1LL << 31);
    DAY0 = WS >= 0 ? WS / DAYMS : -((-WS + DAYMS - 1) / DAYMS);
    WS_OFF = (u32)(WS - DAY0 * DAYMS);
    i64 last = WE - 1;
    i64 last_day = last >= 0 ? last / DAYMS : -((-last + DAYMS - 1) / DAYMS);
    NDAYS = (u32)(last_day - DAY0 + 1);

    g_products_thread = std::thread([data] { load_products(data); });
    load_campaigns(data);
    USE_MMAP = getenv("SS_MMAP") != nullptr;
    if ((e = getenv("SS_STAGE"))) STAGE = atoi(e);
    F_EVENTS = map_dir(data + "/events", B_EVENTS);
    F_CLICKS = map_dir(data + "/clicks", B_CLICKS);
    F_LINKS = map_dir(data + "/links", B_LINKS);
    mkdir(OUT_DIR.c_str(), 0777);
    mkdir((OUT_DIR + "/user_daily").c_str(), 0777);
    mkdir((OUT_DIR + "/campaign_daily").c_str(), 0777);
    lap("inputs mapped");

    u64 slots = (B_EVENTS + B_CLICKS) / 500 + B_LINKS / 10 + 4096;
    if ((e = getenv("SS_SLOTS")) && atoll(e) > 0) slots = (u64)atoll(e);  // testing: force the regrow path
#ifdef SS_PROBE
    probe_env();
    {
        // The pipeline itself, several times: all threads (first run, then
        // warm), half of them (one per core if siblings are paired), then one.
        const int full = T;
        const int plan[5] = {full, full, full, std::max(1, full / 2), 1};
        for (int r = 0; r < 5; r++) {
            T = plan[r];
            fprintf(stderr, "==== probe: pipeline run %d, %d threads ====\n", r, T);
            T0 = now_s();
            while (!run(slots)) slots *= 4;
            lap("done");
        }
        PqFile empty;
        empty.open(OUT_DIR + "/campaign_daily/part-000.parquet",
                   {{"campaign_id", PQ_BYTES, 0, false}, {"channel", PQ_BYTES, 0, false}, {"day", PQ_INT32, 6, false},
                    {"sessions", PQ_INT64, -1, false}, {"purchasing_sessions", PQ_INT64, -1, false},
                    {"revenue_cents", PQ_INT64, -1, false}, {"assisted_sessions", PQ_INT64, -1, false}});
        empty.close();
        fprintf(stderr, "==== probe: done, campaign_daily left empty on purpose ====\n");
        fflush(stderr);
        _exit(0);
    }
#endif
    while (!run(slots)) {
        if (VERBOSE) fprintf(stderr, "user table too small at %llu slots, retrying\n", (unsigned long long)slots);
        slots *= 4;
    }
    lap("done");
    fflush(stderr);
    _exit(0);
}
