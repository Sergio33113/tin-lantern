// Shopping Sessions pipeline. One native binary, no engine.
//
// Phases (all parallel over NCPU threads):
//   1. links   -> lock-free union-find inside the user table; the root of a
//                 person is always their byte-wise smallest ID.
//   2. parse   -> events become 24-byte records partitioned by hash(event_id);
//                 clicks become 16-byte records partitioned by person bucket.
//   3. dedup   -> each event partition is deduplicated in cache (smallest
//                 ingest_ts wins, then validity decides), survivors are
//                 scattered to person buckets.
//   4. buckets -> per bucket: radix sort by (person, ts), sessionize, credit
//                 and assist from the person's clicks, write user_daily rows.
//   5. merge the per-thread campaign tables and write campaign_daily.
//
// IDs are kept exact without storing strings: an ID of 2..9 bytes that starts
// with the expected letter (e/u/k) and holds only bytes 0x01..0x7F is packed
// into a u64 (the 8 bytes after the letter). Anything else goes through a
// mutex-protected interner and gets a key with bit 63 set.
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <algorithm>
#include <atomic>
#include <cerrno>
#include <csignal>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include <dirent.h>
#include <fcntl.h>
#include <sched.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#if defined(__x86_64__)
#include <immintrin.h>
#elif defined(__aarch64__)
#include <arm_neon.h>
#endif

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int32_t i32;
typedef int64_t i64;

// Present only in a build made with -fprofile-generate (see the Dockerfile and the end of main).
extern "C" void __gcov_dump(void) __attribute__((weak));

#define likely(x) __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)
// -DSS_INLINE_ROW puts each row handler inside the loop that cuts the lines (no call per row).
#ifdef SS_INLINE_ROW
#define ROW_INLINE __attribute__((always_inline))
#else
#define ROW_INLINE
#endif

static inline u64 load64(const u8* p) { u64 v; memcpy(&v, p, 8); return v; }
static inline u32 load32(const u8* p) { u32 v; memcpy(&v, p, 4); return v; }

[[noreturn]] static void die(const char* fmt, ...) __attribute__((format(printf, 1, 2)));
static void die(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "fatal: ");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
    _exit(1);
}

static double now_s() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}
static double T0;
static bool VERBOSE = false;
// Step timers inside the phases, printed with SS_VERBOSE. Thread time, summed over the threads.
static inline u64 ticks() {
    timespec ts;
    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
    return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}
// Profiling only (SS_STAGE): stop early in the parse. 1 scan, 2 split, 3 fields, 4 lookups, 0 everything.
// Only a build made with -DSS_PROBE or -DSS_STAGES has the switch. In the entry itself it is a
// constant, so the checks on it in the row loops cost nothing.
#if defined(SS_PROBE) || defined(SS_STAGES)
static int STAGE = 0;
#else
static const int STAGE = 0;
#endif
// The probe's benchmark keeps the step times instead of printing them.
static bool LAP_QUIET = false;
static double LAP_MS[16];
static int LAP_N = 0;
static void lap(const char* what) {
    if (!VERBOSE) return;
    if (LAP_QUIET) {
        if (LAP_N < 16) LAP_MS[LAP_N++] = (now_s() - T0) * 1e3;
        return;
    }
    rusage ru;
    getrusage(RUSAGE_SELF, &ru);
    long thp = -1, rss = -1;
    if (FILE* f = fopen("/proc/self/smaps_rollup", "r")) {
        char line[256];
        while (fgets(line, sizeof line, f)) {
            if (!strncmp(line, "AnonHugePages:", 14)) thp = atol(line + 14) / 1024;
            if (!strncmp(line, "Rss:", 4)) rss = atol(line + 4) / 1024;
        }
        fclose(f);
    }
    fprintf(stderr, "[%8.1f ms] %-32s user %6.0f ms, sys %6.0f ms, minflt %7ld, rss %5ld MB, thp %5ld MB\n",
            (now_s() - T0) * 1e3, what, ru.ru_utime.tv_sec * 1e3 + ru.ru_utime.tv_usec * 1e-3,
            ru.ru_stime.tv_sec * 1e3 + ru.ru_stime.tv_usec * 1e-3, ru.ru_minflt, rss, thp);
}

static inline u64 mix64(u64 x) {
    x ^= x >> 32;
    x *= 0xd6e8feb86659fd93ULL;
    x ^= x >> 32;
    x *= 0xd6e8feb86659fd93ULL;
    x ^= x >> 32;
    return x;
}

// One multiply. The IDs are packed text, so the top bytes are folded down first:
// every character then reaches the high bits of the product, the only bits used.
static inline u64 hash1(u64 x) { return (x ^ (x >> 29)) * 0x9E3779B97F4A7C15ULL; }

static inline u32 tz64(u64 x) {
#if defined(__BMI__)
    return (u32)_tzcnt_u64(x);
#else
    return x ? (u32)__builtin_ctzll(x) : 64;
#endif
}

// ---------------------------------------------------------------- constants
static const i64 DAYMS = 86400000;
static const i64 WEEKMS = 7 * DAYMS;
static const u32 GAPMS = 1800000;
static const u64 SLOW = 1ull << 63;
static const u32 INVALID = 0xFFFFFFFFu;  // well-formed row that fails validation
static const u32 DEAD = 0xFFFFFFFEu;     // lost the dedup
// Records go to the arena in chunks of 4 KB. Every thread keeps a chunk open for each
// partition and each person bucket of every stream, and at 16 KB those mostly empty open
// chunks were a third of the memory the run touched (1.15 GB at 20M events), all of it
// zeroed by the kernel on first touch. A chunk holds at most 1024 records (dedup's refs).
#ifndef SS_CHUNK
#define SS_CHUNK 4096
#endif
static const u32 CHUNK = SS_CHUNK;
static_assert(CHUNK >= 1024 && CHUNK / 24 <= 1024, "a chunk holds a 192-byte unit and at most 1024 event records");
static const u32 CHUNK_BATCH = 16384 / CHUNK * 4;  // chunks a thread takes from the arena at once
static const u32 NOCHUNK = 0xFFFFFFFFu;

enum : u8 { ST_FREE = 0, ST_EREC = 1, ST_MAIN = 2, ST_PURCH = 3, ST_CLICK = 4, ST_DENSE = 5 };

// ---------------------------------------------------------------- globals
static int T = 8;
static i64 WS, WE, CWS;  // event window and click window start, ms
static i64 ING_BASE;     // seconds; ingest is stored as u32 relative to this
static i64 DAY0;         // epoch day of the window start
static u32 WS_OFF;       // ms of the window start into its day
static u32 NDAYS;

static std::atomic<bool> g_overflow{false};

// ---------------------------------------------------------------- calendar
static i32 YEAR_START[10000];
static u8 YEAR_LEAP[10000];
static const u16 CUM[2][13] = {{0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334},
                               {0, 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335}};
static const u8 DIM[2][13] = {{0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
                              {0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}};

static i64 days_from_civil(i64 y, i64 m, i64 d) {
    y -= m <= 2;
    i64 era = (y >= 0 ? y : y - 399) / 400;
    i64 yoe = y - era * 400;
    i64 doy = (153 * ((m + 9) % 12) + 2) / 5 + d - 1;
    i64 doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + doe - 719468;
}
static void init_calendar() {
    for (int y = 0; y < 10000; y++) {
        YEAR_START[y] = (i32)days_from_civil(y, 1, 1);
        YEAR_LEAP[y] = (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)) ? 1 : 0;
    }
}
static void civil_from_days(i64 z, int& y, int& m, int& d) {
    z += 719468;
    i64 era = (z >= 0 ? z : z - 146096) / 146097;
    i64 doe = z - era * 146097;
    i64 yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    i64 yy = yoe + era * 400;
    i64 doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    i64 mp = (5 * doy + 2) / 153;
    d = (int)(doy - (153 * mp + 2) / 5 + 1);
    m = (int)(mp < 10 ? mp + 3 : mp - 9);
    y = (int)(yy + (m <= 2));
}

// ---------------------------------------------------------------- numbers
static const u64 M7 = 0x7F7F7F7F7F7F7F7FULL, H8 = 0x8080808080808080ULL;

static inline bool all_digits8(u64 w) {
    return ((w & 0xF0F0F0F0F0F0F0F0ULL) | (((w + 0x0606060606060606ULL) & 0xF0F0F0F0F0F0F0F0ULL) >> 4)) ==
           0x3333333333333333ULL;
}
static inline u32 parse8(u64 w) {
    w = (w & 0x0F0F0F0F0F0F0F0FULL) * 2561 >> 8;
    w = (w & 0x00FF00FF00FF00FFULL) * 6553601 >> 16;
    return (u32)((w & 0x0000FFFF0000FFFFULL) * 42949672960001ULL >> 32);
}
// The first n (1..8) chars at s as an 8-char block with leading '0's.
static inline u64 block8(const u8* s, size_t n) {
    u64 w = load64(s);
    if (n == 8) return w;
    int sh = (int)(8 - n) * 8;
    return (w << sh) | (0x3030303030303030ULL >> (64 - sh));
}
// Digits only, more than 16 of them: the rare case, kept out of line so the short
// cases below stay small enough to sit inside the row handlers.
__attribute__((noinline, cold)) static bool parse_digits_long(const u8* s, size_t n, u64& out) {
    for (size_t i = 0; i < n; i++)
        if ((u8)(s[i] - '0') > 9) return false;
    while (n > 1 && *s == '0') s++, n--;
    if (n > 18) { out = ~0ULL; return true; }
    u64 v = 0;
    for (size_t i = 0; i < n; i++) v = v * 10 + (s[i] - '0');
    out = v;
    return true;
}
// Digits only, any length >= 1. More than 18 significant digits saturates.
__attribute__((always_inline)) static inline bool parse_digits(const u8* s, size_t n, u64& out) {
    if (likely(n - 1 < 8)) {
        u64 w = block8(s, n);
        if (!all_digits8(w)) return false;
        out = parse8(w);
        return true;
    }
    if (n == 0) return false;
    if (likely(n <= 16)) {
        u64 lo = load64(s + n - 8), hi = block8(s, n - 8);
        if (!all_digits8(lo) || !all_digits8(hi)) return false;
        out = (u64)parse8(hi) * 100000000ULL + parse8(lo);
        return true;
    }
    return parse_digits_long(s, n, out);
}
// Digits with no leading zero (or the single digit 0), at most 7 of them.
static inline bool canon_num(const u8* s, size_t n, u32& out) {
    if (n - 1 >= 7) return false;
    u64 w = block8(s, n);
    if (!all_digits8(w)) return false;
    if (n > 1 && s[0] == '0') return false;
    out = parse8(w);
    return true;
}

// ---------------------------------------------------------------- timestamps
static const i64 BAD_TS = INT64_MIN;

// "YYYY-MM-DD" at p[0..10). Days since the epoch.
static bool parse_date10(const u8* p, i64& days) {
    u64 a = load64(p) ^ 0x2D30302D30303030ULL;
    u32 d0 = (u32)p[8] ^ 0x30, d1 = (u32)p[9] ^ 0x30;
    u64 bad = (((a & M7) + 0x7F76767F76767676ULL) | a) & H8;
    if (bad || d0 > 9 || d1 > 9) return false;
    u64 pa = a * 2561;
    u32 year = (u32)((pa >> 8) & 0xFF) * 100 + (u32)((pa >> 24) & 0xFF);
    u32 mon = (u32)(pa >> 48) & 0xFF;
    u32 day = d0 * 10 + d1;
    if (mon - 1 >= 12) return false;
    u32 leap = YEAR_LEAP[year];
    if (day - 1 >= DIM[leap][mon]) return false;
    days = (i64)YEAR_START[year] + CUM[leap][mon] + day - 1;
    return true;
}

// A dataset holds a few dozen dates, each millions of times. Every thread
// keeps the dates it has checked, by their ten bytes, with their midnight.
struct DateEnt {
    u64 a;     // "YYYY-MM-" as read
    u32 d2;    // "DD" as read
    u32 pad;
    i64 secs;  // the date's midnight
};
static thread_local DateEnt DATE_CACHE[64];

static inline bool parse_dt19_old(const u8* p, i64& secs);

// "YYYY-MM-DDTHH:MM:SS" at p[0..19). Seconds since the epoch.
__attribute__((always_inline)) static inline bool parse_dt19(const u8* p, i64& secs) {
    // "HH:MM:SS": digits within 2 9 : 5 9 : 5 9 and the two colons, then the hour itself.
    u64 x = load64(p + 11) ^ 0x30303A30303A3030ULL;
    u64 badt = (((x & M7) + 0x767A7F767A7F767DULL) | x) & H8;
    u64 pb = x * 2561;
    u32 hh = (u32)(pb >> 8) & 0xFF, mi = (u32)(pb >> 32) & 0xFF, ss = (u32)(pb >> 56);
    if (unlikely((badt | (u64)(p[10] ^ 'T') | (u64)(hh > 23)) != 0)) return false;
    u64 a = load64(p);
    u32 d2 = (u32)p[8] | ((u32)p[9] << 8);
    // The slot: two bits of the day's first digit and four of its second.
#if defined(__BMI2__)
    DateEnt& en = DATE_CACHE[_pext_u32(d2, 0x0F03u)];
#else
    DateEnt& en = DATE_CACHE[(d2 & 3) | ((d2 >> 6) & 0x3C)];
#endif
    i64 day_secs;
    if (likely(en.a == a && en.d2 == d2)) {
        day_secs = en.secs;
    } else {
        i64 days;
        if (!parse_date10(p, days)) return false;
        day_secs = days * 86400;
        en.a = a, en.d2 = d2, en.secs = day_secs;
    }
    secs = day_secs + (i64)(hh * 3600 + mi * 60 + ss);
    return true;
}

static inline bool parse_dt19_old(const u8* p, i64& secs) {
    u64 a = load64(p) ^ 0x2D30302D30303030ULL;
    u64 b = load64(p + 8) ^ 0x30303A3030543030ULL;
    u32 c = (load32(p + 16) ^ 0x0030303Au) & 0x00FFFFFFu;
    u64 bad = (((a & M7) + 0x7F76767F76767676ULL) | a | ((b & M7) + 0x76767F76767F7676ULL) | b) & H8;
    u32 badc = (((c & 0x7F7F7Fu) + 0x76767Fu) | c) & 0x808080u;
    if (unlikely(bad | badc)) return false;
    u64 pa = a * 2561, pb = b * 2561;
    u32 pc = (c >> 8) * 2561;
    u32 year = (u32)((pa >> 8) & 0xFF) * 100 + (u32)((pa >> 24) & 0xFF);
    u32 mon = (u32)(pa >> 48) & 0xFF;
    u32 day = (u32)(pb >> 8) & 0xFF, hh = (u32)(pb >> 32) & 0xFF, mi = (u32)(pb >> 56) & 0xFF;
    u32 ss = (pc >> 8) & 0xFF;
    if (unlikely(mon - 1 >= 12 || hh > 23 || mi > 59 || ss > 59)) return false;
    u32 leap = YEAR_LEAP[year];
    if (unlikely(day - 1 >= DIM[leap][mon])) return false;
    i64 days = (i64)YEAR_START[year] + CUM[leap][mon] + day - 1;
    secs = days * 86400 + hh * 3600 + mi * 60 + ss;
    return true;
}

// Any of the three forms, as epoch milliseconds, or BAD_TS. Inside the row handlers:
// as a call it cost a dozen instructions of entry and exit for every row.
__attribute__((always_inline)) static inline i64 parse_ts(const u8* p, size_t n) {
    if (n == 20 && p[19] == 'Z') {
        i64 s;
        return parse_dt19(p, s) ? s * 1000 : BAD_TS;
    }
    if (n == 25 && (p[19] == '+' || p[19] == '-')) {
        i64 s;
        if (!parse_dt19(p, s)) return BAD_TS;
        u64 d = (load64(p + 17) ^ 0x30303A3030000000ULL) & 0xFFFFFFFFFF000000ULL;
        if ((((d & M7) + 0x76767F7676000000ULL) | d) & H8) return BAD_TS;
        u64 pd = d * 2561;
        u32 oh = (u32)(pd >> 32) & 0xFF, om = (u32)(pd >> 56) & 0xFF;
        if (oh > 23 || om > 59) return BAD_TS;
        i64 off = oh * 3600 + om * 60;
        return (p[19] == '+' ? s - off : s + off) * 1000;
    }
    u64 v;
    if (likely(n - 9 < 8)) {  // 9 to 16 digits: epoch milliseconds have 13
        const u64 lo = load64(p + n - 8), hi = block8(p, n - 8);
        if (unlikely(!all_digits8(lo) || !all_digits8(hi))) return BAD_TS;
        v = (u64)parse8(hi) * 100000000ULL + parse8(lo);
    } else if (!parse_digits(p, n, v)) {
        return BAD_TS;
    }
    return v > (u64)INT64_MAX ? INT64_MAX : (i64)v;
}

// ---------------------------------------------------------------- interner
// IDs that do not fit the packed form. The strings are spread over many small
// maps by a hash, each with its own lock, so threads rarely wait on each other
// even when every ID in a dataset takes this path. A key is the map's number
// and the string's number inside it.
struct Interner {
    static const u32 STRIPES = 1024;
    struct Stripe {
        ~Stripe() {}
        std::mutex m;
        std::unordered_map<std::string, u32> map;
        std::deque<std::string> strs;
        char pad[64];
    };
    Stripe* stripes = new Stripe[STRIPES];
    u64 intern(const u8* s, size_t n) {
        u64 h = 0xcbf29ce484222325ULL;
        for (size_t i = 0; i < n; i++) h = (h ^ s[i]) * 0x100000001b3ULL;
        u32 si = (u32)(mix64(h) >> 54);
        Stripe& st = stripes[si];
        std::lock_guard<std::mutex> g(st.m);
        auto it = st.map.find(std::string((const char*)s, n));
        u32 id;
        if (it != st.map.end()) {
            id = it->second;
        } else {
            id = (u32)st.strs.size();
            st.strs.emplace_back((const char*)s, n);
            st.map.emplace(st.strs.back(), id);
        }
        return SLOW | ((u64)si << 32) | id;
    }
    std::string get(u64 key) {
        Stripe& st = stripes[(u32)(key >> 32) & (STRIPES - 1)];
        std::lock_guard<std::mutex> g(st.m);
        return st.strs[(u32)key];
    }
};
static Interner g_intern;

// The rare IDs go through a call that is kept out of line, so the packed path
// stays small enough to sit inside every row handler.
__attribute__((noinline, cold)) static u64 id_key_slow(const u8* s, size_t n) { return g_intern.intern(s, n); }
__attribute__((always_inline)) static inline u64 id_key(const u8* s, size_t n, u8 prefix) {
    if (likely(n - 2 < 8 && s[0] == prefix)) {
        const unsigned sh = 64 - 8 * ((unsigned)n - 1);  // 0..56
        const u64 m = ~0ULL >> sh;
        const u64 w = load64(s + 1) & m;
        const u64 z = w | ~m;
        if (likely((w & H8) == 0 && ((z - 0x0101010101010101ULL) & ~z & H8) == 0)) return w;
    }
    return id_key_slow(s, n);
}
// The ID a key stands for, written to out (at least 16 bytes). Returns its length
// when the key is packed; an interned key returns 0 and fills `slow`.
static inline size_t key_str_fast(u64 key, u8 prefix, u8* out) {
    out[0] = prefix;
    memcpy(out + 1, &key, 8);
    return 1 + (size_t)((71 - __builtin_clzll(key)) >> 3);
}
static std::string key_string(u64 key, u8 prefix) {
    if (key & SLOW) return g_intern.get(key);
    u8 b[16];
    size_t n = key_str_fast(key, prefix, b);
    return std::string((const char*)b, n);
}
// Byte-wise order of the IDs two keys stand for.
static inline bool id_less(u64 a, u64 b, u8 prefix) {
    if (likely(!((a | b) & SLOW))) return __builtin_bswap64(a) < __builtin_bswap64(b);
    return key_string(a, prefix) < key_string(b, prefix);
}

// ---------------------------------------------------------------- user table
struct Slot {
    u64 key;     // 0 = empty
    u32 parent;  // 0 = root, else parent slot + 1
    u32 pad;
};
static Slot* TAB;
static u64 TABN;
static u64 TAB_LIMIT, TAB_QUOTA;
static std::atomic<u64> g_tab_used{0};
static u32 LW;   // log2(slots per person bucket)
static u32 PB;   // person buckets
static u32 CBITS;  // bits of a campaign index
static u32 PEB;  // log2(event partitions)

static inline u64 tab_home(u64 key) { return (u64)(((unsigned __int128)hash1(key) * TABN) >> 64); }

struct TabCounter {
    u64 pending = 0;
    inline void inserted() {
        if (unlikely(++pending >= TAB_QUOTA)) {
            u64 total = g_tab_used.fetch_add(pending, std::memory_order_relaxed) + pending;
            pending = 0;
            if (total > TAB_LIMIT) g_overflow.store(true, std::memory_order_relaxed);
        }
    }
};

// The slot of a key, inserting it if it is new.
static inline u32 tab_slot(u64 key, u64 i, TabCounter& tc) {
    {
        // Nearly every key sits in its home slot or the next one. Which of the two is a
        // coin toss, so both are compared before the one branch that is almost always taken.
        const u64 i1 = i + 1 == TABN ? 0 : i + 1;
        const u64 k0 = __atomic_load_n(&TAB[i].key, __ATOMIC_RELAXED);
        const u64 k1 = __atomic_load_n(&TAB[i1].key, __ATOMIC_RELAXED);
        const bool miss0 = k0 != key;
        if (likely((!miss0) | ((k1 == key) & (k0 != 0)))) return (u32)(i ^ ((i ^ i1) & (0 - (u64)miss0)));
    }
    for (;;) {
        u64 k = __atomic_load_n(&TAB[i].key, __ATOMIC_RELAXED);
        if (k == key) return (u32)i;
        if (k == 0) {
            if (unlikely(g_overflow.load(std::memory_order_relaxed))) return 0;
            u64 expect = 0;
            if (__atomic_compare_exchange_n(&TAB[i].key, &expect, key, false, __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
                tc.inserted();
                return (u32)i;
            }
            if (expect == key) return (u32)i;
        }
        if (++i == TABN) i = 0;
    }
}
// Root or not is a coin toss per row, so the choice is made without a branch.
static inline u32 tab_person(u32 slot) {
    u32 p = __atomic_load_n(&TAB[slot].parent, __ATOMIC_RELAXED);
    u32 pick = 0u - (u32)(p != 0);  // all ones when the slot has a parent
    return slot ^ ((slot ^ (p - 1)) & pick);
}

static inline u32 uf_find(u32 x) {
    for (;;) {
        u32 p = __atomic_load_n(&TAB[x].parent, __ATOMIC_RELAXED);
        if (!p) return x;
        u32 gp = __atomic_load_n(&TAB[p - 1].parent, __ATOMIC_RELAXED);
        if (!gp) return p - 1;
        __atomic_store_n(&TAB[x].parent, gp, __ATOMIC_RELAXED);  // path halving
        x = gp - 1;
    }
}
static inline u32 uf_find_ro(u32 x) {
    for (;;) {
        u32 p = __atomic_load_n(&TAB[x].parent, __ATOMIC_RELAXED);
        if (!p) return x;
        x = p - 1;
    }
}
// Joins two slots. The root with the larger ID goes under the smaller one, so
// a root is always the smallest ID of its tree. The slot that stops being a root
// goes on `joined`: those are the only slots with a parent.
static inline void uf_union(u32 a, u32 b, std::vector<u32>& joined) {
    for (;;) {
        u32 ra = uf_find(a), rb = uf_find(b);
        if (ra == rb) return;
        u64 ka = __atomic_load_n(&TAB[ra].key, __ATOMIC_RELAXED), kb = __atomic_load_n(&TAB[rb].key, __ATOMIC_RELAXED);
        if (id_less(kb, ka, 'u')) std::swap(ra, rb);
        u32 expect = 0;
        if (__atomic_compare_exchange_n(&TAB[rb].parent, &expect, ra + 1, false, __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
            joined.push_back(rb);
            return;
        }
    }
}

// ---------------------------------------------------------------- lookups
static std::vector<std::string> CAT_NAME;  // index ncat = "unknown"
static std::vector<u32> CAT_RANK;          // byte-wise rank of the name
static u32 NCAT;                           // categories in the file; NCAT = unknown
static std::vector<u32> PROD_DIRECT;       // by number, for canonical p<digits>
static std::unordered_map<std::string, u32> PROD_MAP;
static bool WIDE_CAT = false;

static std::vector<std::string> CAMP_NAME, CAMP_CHANNEL;  // index NCAMP = organic
static u32 NCAMP;
static std::vector<i32> CAMP_DIRECT;
static std::unordered_map<std::string, u32> CAMP_MAP;

static inline u32 product_cat(const u8* s, size_t n) {
    u32 num;
    if (likely(n >= 2 && s[0] == 'p' && canon_num(s + 1, n - 1, num)))
        return num < PROD_DIRECT.size() ? PROD_DIRECT[num] : NCAT;
    auto it = PROD_MAP.find(std::string((const char*)s, n));
    return it == PROD_MAP.end() ? NCAT : it->second;
}
static inline i32 campaign_idx(const u8* s, size_t n) {
    u32 num;
    if (likely(n >= 3 && s[0] == 'c' && s[1] == '_' && canon_num(s + 2, n - 2, num)))
        return num < CAMP_DIRECT.size() ? CAMP_DIRECT[num] : -1;
    auto it = CAMP_MAP.find(std::string((const char*)s, n));
    return it == CAMP_MAP.end() ? -1 : (i32)it->second;
}

// ---------------------------------------------------------------- scanner
#ifndef SS_WIN
#define SS_WIN 32768
#endif
static const u32 WIN = SS_WIN;  // bytes scanned before their lines are parsed
struct Scan {
    u32* cidx;
    u32* nidx;
    u64* qb;
    u32 nc, nn;
    // The tagged index (scan_tagged): every separator's position and a flag byte.
    // spos[-1] and sflg[-1] stand for the newline before the window.
    u32* spos_raw;
    u8* sflg_raw;
    u32* spos;
    u8* sflg;
    u32 ns;
    static const u32 QCAP = 128;  // rows held per timestamp form before they are handed over
    u32* rowq;
    void init() {
        cidx = (u32*)malloc((WIN + 128) * 4);
        nidx = (u32*)malloc((WIN + 128) * 4);
        qb = (u64*)malloc((WIN / 64 + 2) * 8);
        spos_raw = (u32*)malloc((WIN + 160) * 4);
        sflg_raw = (u8*)malloc(WIN + 160);
        spos = spos_raw + 16, sflg = sflg_raw + 16;
        rowq = (u32*)aligned_alloc(64, 3 * QCAP * 16 * 4);
    }
    void release() { free(cidx), free(nidx), free(qb), free(spos_raw), free(sflg_raw), free(rowq); }
};
static bool OLDSPLIT = false;  // SS_OLDSPLIT: the comma and newline indexes instead of the tagged one
// Measured on x86: queueing the rows by timestamp form gains nothing (0.4%, inside the
// noise), so rows go to the handler in file order unless SS_QUEUE is set.
static bool NOQUEUE = true;

static inline void emit_bits(u32*& out, u64 bits, u32 base) {
    constexpr int first_positions = 7;
    u32 cnt = (u32)__builtin_popcountll(bits);
    u32* o = out;
    for (int i = 0; i < first_positions; i++) {
        o[i] = base + tz64(bits);
        bits &= bits - 1;
    }
    if (unlikely(cnt > first_positions)) {
        for (u32 i = first_positions; i < cnt; i++) {
            o[i] = base + tz64(bits);
            bits &= bits - 1;
        }
    }
    out += cnt;
}
static inline void emit_bits_few(u32*& out, u64 bits, u32 base) {
    u32 cnt = (u32)__builtin_popcountll(bits);
    u32* o = out;
    o[0] = base + tz64(bits);
    bits &= bits - 1;
    o[1] = base + tz64(bits);
    bits &= bits - 1;
    if (unlikely(cnt > 2)) {
        for (u32 i = 2; i < cnt; i++) {
            o[i] = base + tz64(bits);
            bits &= bits - 1;
        }
    }
    out += cnt;
}

// Comma, newline and quote masks of the 64 bytes at p.
static inline void masks64(const u8* p, u64& cm, u64& nm, u64& qm) {
#if defined(__AVX2__)
    __m256i a = _mm256_loadu_si256((const __m256i*)p), b = _mm256_loadu_si256((const __m256i*)(p + 32));
    const __m256i vc = _mm256_set1_epi8(','), vn = _mm256_set1_epi8('\n'), vq = _mm256_set1_epi8('"');
    cm = (u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(a, vc)) |
         ((u64)(u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(b, vc)) << 32);
    nm = (u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(a, vn)) |
         ((u64)(u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(b, vn)) << 32);
    qm = (u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(a, vq)) |
         ((u64)(u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(b, vq)) << 32);
#elif defined(__aarch64__)
    static const u8 bitv[16] = {1, 2, 4, 8, 16, 32, 64, 128, 1, 2, 4, 8, 16, 32, 64, 128};
    const uint8x16_t bm = vld1q_u8(bitv);
    uint8x16_t v0 = vld1q_u8(p), v1 = vld1q_u8(p + 16), v2 = vld1q_u8(p + 32), v3 = vld1q_u8(p + 48);
    auto mm = [&](u8 ch) -> u64 {
        const uint8x16_t c = vdupq_n_u8(ch);
        uint8x16_t t0 = vandq_u8(vceqq_u8(v0, c), bm), t1 = vandq_u8(vceqq_u8(v1, c), bm);
        uint8x16_t t2 = vandq_u8(vceqq_u8(v2, c), bm), t3 = vandq_u8(vceqq_u8(v3, c), bm);
        uint8x16_t s0 = vpaddq_u8(t0, t1), s1 = vpaddq_u8(t2, t3);
        s0 = vpaddq_u8(s0, s1);
        s0 = vpaddq_u8(s0, s0);
        return vgetq_lane_u64(vreinterpretq_u64_u8(s0), 0);
    };
    cm = mm(',');
    nm = mm('\n');
    qm = mm('"');
#else
    cm = nm = qm = 0;
    for (int i = 0; i < 64; i++) {
        u8 ch = p[i];
        cm |= (u64)(ch == ',') << i;
        nm |= (u64)(ch == '\n') << i;
        qm |= (u64)(ch == '"') << i;
    }
#endif
}

// Indexes the commas and newlines of base[0..len) and keeps a quote bitmap.
// Reads up to 63 bytes past len: every input has zero padding after it.
static inline void scan_window(const u8* base, u32 len, Scan& sc) {
    u32* co = sc.cidx;
    u32* no = sc.nidx;
    u32 nblk = (len + 63) >> 6;
    for (u32 b = 0; b < nblk; b++) {
        u64 cm, nm, qm;
        masks64(base + ((size_t)b << 6), cm, nm, qm);
        if (unlikely(b == nblk - 1) && (len & 63)) {
            u64 keep = (1ULL << (len & 63)) - 1;
            cm &= keep, nm &= keep, qm &= keep;
        }
        sc.qb[b] = qm;
        emit_bits(co, cm, b << 6);
        emit_bits_few(no, nm, b << 6);
    }
    sc.nc = (u32)(co - sc.cidx);
    sc.nn = (u32)(no - sc.nidx);
    for (int i = 0; i < 16; i++) co[i] = 0xFFFFFFFFu;
}

// ---- the tagged index
// One entry per separator (comma or newline) of the window, in order: its
// position and a flag byte. The flags let a line be cut into fields without
// looking at its bytes again:
//   FQA   the byte after the separator is a quote: the next field opens with one
//   FQB   the byte before it is a quote: the field it ends closes with one
//   FNL   the separator is a newline
//   FBAD  a quote that touches no separator lies in the field it ends
// No value holds a comma or a newline, so every separator bounds a field, and a
// line is well quoted exactly when no field has FBAD, each field's opening
// flag equals its closing flag, and a quoted field has two bytes or more.
static const u8 FQA = 1, FQB = 2, FNL = 4, FBAD = 8;

static inline void emit_flags(u8* out, u64 sep, u64 qa, u64 qb, u64 nm, u64 bad, u32 cnt) {
#if defined(__BMI2__)
    u64 fa = _pext_u64(qa, sep), fb = _pext_u64(qb, sep), fn = _pext_u64(nm, sep);
    u64 fx = bad ? _pext_u64(bad, sep) : 0;
    for (u32 k = 0;; k += 8) {
        u64 bytes = _pdep_u64(fa >> k, 0x0101010101010101ULL) | _pdep_u64(fb >> k, 0x0202020202020202ULL) |
                    _pdep_u64(fn >> k, 0x0404040404040404ULL);
        if (unlikely(fx)) bytes |= _pdep_u64(fx >> k, 0x0808080808080808ULL);
        memcpy(out + k, &bytes, 8);
        if (likely(k + 8 >= cnt)) break;
    }
#else
    u64 first = 0;
    memcpy(out, &first, 8);  // the callers read whole words of flags
    for (u32 k = 0; sep; k++, sep &= sep - 1) {
        u32 p = tz64(sep);
        out[k] = (u8)(((qa >> p) & 1) | (((qb >> p) & 1) << 1) | (((nm >> p) & 1) << 2) | (((bad >> p) & 1) << 3));
    }
    (void)cnt;
#endif
}

// Builds the tagged index of base[0..len). A line starts at base[0].
// Reads up to 63 bytes past len: every input has zero padding after it.
static inline void scan_tagged(const u8* base, u32 len, Scan& sc) {
    u32* po = sc.spos;
    u8* fo = sc.sflg;
    const u32 nblk = (len + 63) >> 6;
    const u64 tail = (len & 63) ? (1ULL << (len & 63)) - 1 : ~0ULL;
    u64 cm, nm, qm, cm1 = 0, nm1 = 0, qm1 = 0;
    masks64(base, cm, nm, qm);
    if (nblk == 1) cm &= tail, nm &= tail, qm &= tail;
    sc.spos[-1] = 0xFFFFFFFFu;  // plus one is the first byte of the window
    sc.sflg[-1] = (u8)(FNL | (qm & 1 ? FQA : 0));
    u64 q_before = 0;    // the last byte of the block before was a quote
    u64 sep_before = 1;  // ... was a separator: the newline before the window
    u64 pend_bad = 0;    // a quote touching no separator, waiting for the separator that ends its field
    u32 nn = 0;
    for (u32 b = 0; b < nblk; b++) {
        if (b + 1 < nblk) {
            masks64(base + ((size_t)(b + 1) << 6), cm1, nm1, qm1);
            if (b + 2 == nblk) cm1 &= tail, nm1 &= tail, qm1 &= tail;
        } else {
            cm1 = nm1 = qm1 = 0;
        }
        const u64 sep = cm | nm;
        const u64 qa = sep & ((qm >> 1) | (qm1 << 63));
        const u64 qb = sep & ((qm << 1) | q_before);
        const u64 touching = ((sep << 1) | sep_before) | ((sep >> 1) | ((cm1 | nm1) << 63));
        const u64 inner = qm & ~touching;
        u64 bad = 0;
        if (unlikely((inner | pend_bad) != 0)) {
            u64 s = sep, done = 0;  // done: every bit up to the last separator handled
            bool pend = pend_bad != 0;
            while (s) {
                u32 p = tz64(s);
                u64 upto = (2ULL << p) - 1;
                if (pend || (inner & upto & ~done)) bad |= 1ULL << p;
                pend = false, done = upto;
                s &= s - 1;
            }
            pend_bad = (pend || (inner & ~done)) ? 1 : 0;
        }
        const u32 cnt = (u32)__builtin_popcountll(sep);
        emit_flags(fo, sep, qa, qb, nm, bad, cnt);
        fo += cnt;
        emit_bits(po, sep, b << 6);
        nn += (u32)__builtin_popcountll(nm);
        q_before = qm >> 63, sep_before = sep >> 63;
        cm = cm1, nm = nm1, qm = qm1;
    }
    sc.ns = (u32)(po - sc.spos);
    sc.nn = nn;
    for (int i = 0; i < 16; i++) po[i] = 0xFFFFFFFFu;
    memset(fo, 0, 16);
}

// Field offsets of one row, starts in [0..8) and ends in [8..16), to pointers, then the handler.
template <class H>
static inline void call_row(const u8* base, const u32* q, H& h) {
    alignas(32) const u8* s[8];
    alignas(32) const u8* e[8];
#if defined(__AVX2__)
    const __m256i vb = _mm256_set1_epi64x((long long)(uintptr_t)base);
    const __m256i S = _mm256_loadu_si256((const __m256i*)q), E = _mm256_loadu_si256((const __m256i*)(q + 8));
    _mm256_store_si256((__m256i*)s, _mm256_add_epi64(vb, _mm256_cvtepu32_epi64(_mm256_castsi256_si128(S))));
    _mm256_store_si256((__m256i*)(s + 4), _mm256_add_epi64(vb, _mm256_cvtepu32_epi64(_mm256_extracti128_si256(S, 1))));
    _mm256_store_si256((__m256i*)e, _mm256_add_epi64(vb, _mm256_cvtepu32_epi64(_mm256_castsi256_si128(E))));
    _mm256_store_si256((__m256i*)(e + 4), _mm256_add_epi64(vb, _mm256_cvtepu32_epi64(_mm256_extracti128_si256(E, 1))));
#else
    for (int k = 0; k < 8; k++) s[k] = base + q[k], e[k] = base + q[8 + k];
#endif
    h.row(s, e);
}

// Cuts the lines of a tagged window into fields and calls h.row for each
// well-formed one. Stops at the first line that starts at or after `limit` or
// is not complete in the window. Returns where that line starts.
//
// A handler with a timestamp names its field in H::CLS. The three forms of a
// timestamp come in no order, and a branch on them is wrong for half the rows,
// so the rows are queued by the length of that field (20, 25, anything else)
// and each queue is handed over in one go. Row order means nothing to the
// handlers. A handler with CLS < 0 gets its rows straight away.
template <int NF, class H>
static inline u32 split_tagged(const u8* base, u64 limit, Scan& sc, H& h, bool rows) {
    const u32* P = sc.spos;
    const u8* F = sc.sflg;
    const u32 ns = sc.ns;
    // Flag words hold lanes 0..7 for separators i-1..i+6: lane 0 is the newline
    // before the line, lanes 1..NF its own separators.
    const u64 LANES = NF == 7 ? ~0ULL : (1ULL << (8 * (NF + 1))) - 1;
    const u64 NLM = 0x0404040404040404ULL & LANES;
    const u64 NLEXP = 0x04ULL | (0x04ULL << (8 * NF));
    const u64 QPAIR = 0x0101010101010101ULL & (LANES >> 8);  // lanes 0..NF-1
    const u64 BADM = 0x0808080808080808ULL & LANES & ~0xFFULL;  // lanes 1..NF
    const int CLS = H::CLS;
    const bool queued = CLS >= 0 && !NOQUEUE;
    u32* const Q = sc.rowq;
    u32 qn[3] = {0, 0, 0};
    auto replay = [&](u32 c) {
        const u32* q = Q + (size_t)c * (Scan::QCAP * 16);
        for (u32 r = 0; r < qn[c]; r++, q += 16) call_row(base, q, h);
        qn[c] = 0;
    };
    u32 i = 0, ls = 0;
    while (i < ns) {
        if (unlikely(ls >= limit)) break;
        const u64 f = load64(F + i - 1);
        if (likely((f & NLM) == NLEXP)) {
            // NF fields. Field k opens after separator lane k and ends at lane k+1.
            u64 bad = (((f >> 9) ^ f) & QPAIR) | (f & BADM);
            alignas(32) u32 se[16];
#if defined(__AVX2__)
            const __m256i one = _mm256_set1_epi32(1);
            __m256i p0 = _mm256_loadu_si256((const __m256i*)(P + i - 1));
            __m256i p1 = _mm256_loadu_si256((const __m256i*)(P + i));
            __m256i f0 = _mm256_cvtepu8_epi32(_mm_loadl_epi64((const __m128i*)(F + i - 1)));
            __m256i f1 = _mm256_cvtepu8_epi32(_mm_loadl_epi64((const __m128i*)(F + i)));
            __m256i S = _mm256_add_epi32(_mm256_add_epi32(p0, one), _mm256_and_si256(f0, one));
            __m256i E = _mm256_sub_epi32(p1, _mm256_and_si256(_mm256_srli_epi32(f1, 1), one));
            // A quoted field of one byte: its start passes its end.
            bad |= (u32)_mm256_movemask_ps(_mm256_castsi256_ps(_mm256_cmpgt_epi32(S, E))) & ((1u << NF) - 1);
            _mm256_store_si256((__m256i*)se, S);
            _mm256_store_si256((__m256i*)(se + 8), E);
#else
            const u32* Pm = P + i - 1;  // entry -1 of the first line is the newline before the window
            const u8* Fm = F + i - 1;
            for (int k = 0; k < 8; k++) se[k] = se[8 + k] = 0;
            for (int k = 0; k < NF; k++) {
                u32 S = Pm[k] + 1 + (Fm[k] & 1);
                u32 E = Pm[k + 1] - ((Fm[k + 1] >> 1) & 1);
                bad |= (i32)S > (i32)E;
                se[k] = S, se[8 + k] = E;
            }
#endif
            ls = P[i + NF - 1] + 1, i += NF;
            if (unlikely(bad)) continue;
            if (unlikely(!rows)) continue;
            if (queued) {
                const u32 len = se[8 + (CLS < 0 ? 0 : CLS)] - se[CLS < 0 ? 0 : CLS];
                const u32 c = (u32)(len != 20) + (u32)((len != 20) & (len != 25));
                memcpy(Q + (size_t)c * (Scan::QCAP * 16) + (size_t)qn[c] * 16, se, 64);
                if (unlikely(++qn[c] == Scan::QCAP)) replay(c);
            } else {
                call_row(base, se, h);
            }
        } else {
            // Not NF fields: drop the line. Its newline is the first one in lanes 1..7, or further on.
            const u64 m = f & 0x0404040404040400ULL;
            if (m) {
                u32 k = tz64(m) >> 3;  // 1..7
                i += k;
                ls = P[i - 1] + 1;
            } else {
                u32 j = i + 7;
                while (j < ns && !(F[j] & FNL)) j++;
                if (j >= ns) break;  // the line is not complete in this window
                ls = P[j] + 1, i = j + 1;
            }
        }
    }
    if (queued)
        for (u32 c = 0; c < 3; c++)
            if (qn[c]) replay(c);
    return ls;
}

static inline u32 count_quotes(const u64* qb, u32 a, u32 b) {  // [a, b), b > a
    u32 wa = a >> 6, wb = (b - 1) >> 6;
    u64 ma = ~0ULL << (a & 63), mb = ~0ULL >> (63 - ((b - 1) & 63));
    if (likely(wa == wb)) return (u32)__builtin_popcountll(qb[wa] & ma & mb);
    u32 n = (u32)__builtin_popcountll(qb[wa] & ma) + (u32)__builtin_popcountll(qb[wb] & mb);
    for (u32 w = wa + 1; w < wb; w++) n += (u32)__builtin_popcountll(qb[w]);
    return n;
}

// One line by the plain rules, for the rare lines the window scan cannot take
// (longer than a window, or the last line of a file with no newline).
template <int NF, class H>
static void slow_line(const u8* lb, const u8* le, H& h) {
    const u8* s[NF];
    const u8* e[NF];
    int nf = 0;
    const u8* fs = lb;
    for (const u8* p = lb;; p++) {
        if (p == le || *p == ',') {
            if (nf == NF) return;
            s[nf] = fs, e[nf] = p, nf++;
            if (p == le) break;
            fs = p + 1;
        }
    }
    if (nf != NF) return;
    for (int k = 0; k < NF; k++) {
        size_t nq = 0;
        for (const u8* p = s[k]; p < e[k]; p++) nq += *p == '"';
        if (!nq) continue;
        if (nq != 2 || e[k] - s[k] < 2 || *s[k] != '"' || e[k][-1] != '"') return;
        s[k]++, e[k]--;
    }
    h.row(s, e);
}

// ---- one pass per line (SS_FUSED=1 on, SS_FUSED=0 off; off by default until it is timed on x86)
// The separators of a line are found in the 128 bytes at its start and its fields are cut
// right there: no index of a whole window in between. A line longer than that, and the last
// line of a file with no newline, go to slow_line. Reads up to 128 bytes past the line start:
// every input has zero padding after it, and zero bytes are neither separators nor quotes.
#ifndef SS_FUSED_DEFAULT
#define SS_FUSED_DEFAULT 0  // -DSS_FUSED_DEFAULT=1 turns it on in the build itself (and in its profile run)
#endif
static bool FUSED = SS_FUSED_DEFAULT != 0;

static inline u64 low_bits(u64 x, u32 n) {  // the bits of x below bit n; all of x when n >= 64
#if defined(__BMI2__)
    return _bzhi_u64(x, n);
#else
    return n >= 64 ? x : x & ((1ULL << n) - 1);
#endif
}

template <int NF, class H>
static void fused_range(const u8* buf, u64 fsz, u64 pos, u64 ce, H& h) {
    while (pos < ce) {
        const u8* r = buf + pos;
        u64 cm0, nm0, qm0, cm1, nm1, qm1;
        masks64(r, cm0, nm0, qm0);
        masks64(r + 64, cm1, nm1, qm1);
        if (unlikely((nm0 | nm1) == 0)) {
            const u64 avail = fsz - pos;
            u64 lend = fsz;
            if (avail > 128) {
                const u8* nl = (const u8*)memchr(r + 128, '\n', avail - 128);
                if (nl) lend = (u64)(nl - buf);
            }
            slow_line<NF, H>(r, buf + lend, h);
            pos = lend + 1;
            continue;
        }
        // The line ends at its first newline. Which word holds it is picked without a branch.
        const u32 t0 = tz64(nm0), t1 = tz64(nm1);
        const u32 eol = nm0 ? t0 : 64 + t1;
        const u32 e1 = eol > 64 ? eol - 64 : 0;  // how much of the second word belongs to the line
        const u64 c0 = low_bits(cm0, eol), c1 = low_bits(cm1, e1);
        const u64 q0 = low_bits(qm0, eol), q1 = low_bits(qm1, e1);
        pos += (u64)eol + 1;
        if (unlikely(STAGE == 1)) continue;
        const u32 n0 = (u32)__builtin_popcountll(c0);
        if (unlikely(n0 + (u32)__builtin_popcountll(c1) != (u32)(NF - 1))) continue;  // not NF fields
        // The commas of the first word, then those of the second written over the unused tail.
        u32 cp[2 * NF];
        {
            u64 b = c0;
            for (int k = 0; k < NF - 1; k++) cp[k] = tz64(b), b &= b - 1;
        }
        {
            u64 b = c1;
            for (int k = 0; k < NF - 1; k++) cp[n0 + k] = 64 + tz64(b), b &= b - 1;
        }
        const u8* s[NF];
        const u8* e[NF];
        s[0] = r;
        for (int k = 0; k < NF - 1; k++) e[k] = r + cp[k], s[k + 1] = r + cp[k] + 1;
        e[NF - 1] = r + eol;
        const u32 nq = (u32)__builtin_popcountll(q0) + (u32)__builtin_popcountll(q1);
        if (nq) {
            // Quotes are fine only as the first and last byte of a field, so the wrapped fields
            // must account for every quote in the line.
            u32 nw = 0;
            for (int f = 0; f < NF; f++) {
                u32 w = (e[f] - s[f] >= 2) & (*s[f] == '"') & (e[f][-1] == '"');
                s[f] += w, e[f] -= w, nw += w;
            }
            if (unlikely(2 * nw != nq)) continue;
        }
        if (likely(STAGE != 2)) h.row(s, e);
    }
}

// Calls h.row(starts, ends) for every well-formed line that starts in
// [cs, ce) of the file. The first line of the file is its header.
template <int NF, class H>
static void parse_range(const u8* buf, u64 fsz, u64 cs, u64 ce, Scan& sc, H& h) {
    u64 pos;
    {
        u64 from = cs ? cs - 1 : 0;
        if (from >= fsz) return;
        const u8* nl = (const u8*)memchr(buf + from, '\n', fsz - from);
        if (!nl) return;
        pos = (u64)(nl - buf) + 1;
    }
    if (ce > fsz) ce = fsz;
    if (FUSED) {
        fused_range<NF, H>(buf, fsz, pos, ce, h);
        return;
    }
    while (pos < ce) {
        u32 wlen = (u32)std::min<u64>(WIN, fsz - pos);
        const u8* base = buf + pos;
        if (likely(!OLDSPLIT)) scan_tagged(base, wlen, sc);
        else scan_window(base, wlen, sc);
        if (unlikely(sc.nn == 0)) {
            u64 lend = fsz;
            if (pos + wlen < fsz) {
                const u8* nl = (const u8*)memchr(base + wlen, '\n', fsz - pos - wlen);
                if (nl) lend = (u64)(nl - buf);
            }
            slow_line<NF, H>(base, buf + lend, h);
            pos = lend + 1;
            continue;
        }
        if (likely(!OLDSPLIT)) {
            if (unlikely(STAGE == 1)) {
                u32 j = sc.ns;
                while (!(sc.sflg[j - 1] & FNL)) j--;
                pos += sc.spos[j - 1] + 1;
                continue;
            }
            pos += split_tagged<NF, H>(base, ce - pos, sc, h, STAGE != 2);
            continue;
        }
        if (unlikely(STAGE == 1)) {
            pos += sc.nidx[sc.nn - 1] + 1;
            continue;
        }
        const u32* ci = sc.cidx;
        u64 limit = ce - pos;
        u32 ls = 0, c = 0;
        const u32 nn = sc.nn;
        for (u32 k = 0; k < nn; k++) {
            if (unlikely(ls >= limit)) break;
            u32 nl = sc.nidx[k];
            if (likely(ci[c + NF - 2] < nl && ci[c + NF - 1] > nl)) {
                const u8* s[NF];
                const u8* e[NF];
                u32 fs = ls;
                for (int f = 0; f < NF - 1; f++) {
                    s[f] = base + fs;
                    e[f] = base + ci[c + f];
                    fs = ci[c + f] + 1;
                }
                s[NF - 1] = base + fs;
                e[NF - 1] = base + nl;
                c += NF - 1;
                u32 nq = count_quotes(sc.qb, ls, nl);
                if (nq) {
                    u32 nw = 0;
                    for (int f = 0; f < NF; f++) {
                        u32 w = (e[f] - s[f] >= 2) & (*s[f] == '"') & (e[f][-1] == '"');
                        s[f] += w, e[f] -= w, nw += w;
                    }
                    if (unlikely(2 * nw != nq)) {
                        ls = nl + 1;
                        continue;
                    }
                }
                if (likely(STAGE != 2)) h.row(s, e);
            } else {
                while (ci[c] < nl) c++;
            }
            ls = nl + 1;
        }
        pos += ls;
    }
}

// ---------------------------------------------------------------- dense event numbers
// The generator writes an event ID as 'e' + base36(scramble(n, key)): n numbers the events
// from 0, and scramble is a bijection on 40 bits (multiply, xor the key, xor-shift, multiply)
// whose key changes with every data set. dense_infer finds the key at startup from a sample
// of lines. An ID in the canonical spelling (lowercase base 36, no leading zero, below 2^40)
// then has a number, and two different IDs never share one whatever the key, since base 36
// and scramble are both one to one. An ID whose number is below DLIMIT is deduplicated by
// that number in a table without hashing. Every other ID (case variants, padding, or all of
// them when no key is found) takes the hashed path, so the outputs never depend on the key.
static const u64 M40 = (1ull << 40) - 1;
static const u64 SM1 = 0x9E3779B97F4Bull, SM2 = 0xD6E8FEB86659ull;
static constexpr u64 inv40(u64 a) {  // Newton's iteration doubles the correct low bits each step
    u64 x = a;
    for (int i = 0; i < 6; i++) x *= 2 - a * x;
    return x & M40;
}
static constexpr u64 SM1I = inv40(SM1), SM2I = inv40(SM2);
static_assert(((SM1 * SM1I) & M40) == 1 && ((SM2 * SM2I) & M40) == 1, "inverses modulo 2^40");
// unmix40(scramble(n, key)) = (n * SM1 mod 2^40) xor key, for every key.
static inline u64 unmix40(u64 x) {
    const u64 y = (x * SM2I) & M40;
    return y ^ (y >> 17) ^ (y >> 34);
}
static u64 DKEY = 0;    // the event key dense_infer found
static u64 DLIMIT = 0;  // event numbers below this take the dense path; 0: the path is off
static u32 DLSH = 15;   // log2 of the numbers in one dense partition
static u32 PD = 0;      // dense partitions
static bool NODENSE = false;  // SS_NODENSE: never look for the key

// The base-36 value of the 1 to 8 characters after an ID's 'e' when they are spelled the
// canonical way, else ~0. raw: the 8 bytes after the 'e', which may run past the ID.
static inline u64 base36_canon(u64 raw, u32 l) {
    const u32 sh = 64 - 8 * l;
    const u64 v = (raw << sh) | low_bits(0x3030303030303030ull, sh);  // right-aligned, '0' in front
    const bool lead0 = ((raw & 0xFF) == '0') & (l > 1);
#if defined(__SSE4_1__)
    const __m128i x = _mm_cvtsi64_si128((long long)v);
    const __m128i d = _mm_sub_epi8(x, _mm_set1_epi8('0'));
    const __m128i a = _mm_sub_epi8(x, _mm_set1_epi8('a'));
    const __m128i isd = _mm_cmpeq_epi8(_mm_min_epu8(d, _mm_set1_epi8(9)), d);
    const __m128i isa = _mm_cmpeq_epi8(_mm_min_epu8(a, _mm_set1_epi8(25)), a);
    const u32 okm = (u32)_mm_movemask_epi8(_mm_or_si128(isd, isa)) & 0xFF;
    const __m128i val = _mm_blendv_epi8(_mm_add_epi8(a, _mm_set1_epi8(10)), d, isd);
    const __m128i p2 = _mm_maddubs_epi16(val, _mm_set1_epi16(0x0124));       // pairs: 36 * first + second
    const __m128i p4 = _mm_madd_epi16(p2, _mm_set1_epi32(0x00010510));      // quads: 1296 * first + second
    const u64 q = (u64)_mm_cvtsi128_si64(p4);
    const u64 xv = (q & 0xFFFFFFFFull) * 1679616ull + (q >> 32);
    if (unlikely((okm != 0xFF) | lead0 | (xv > M40))) return ~0ull;
    return xv;
#else
    u64 xv = 0;
    for (u32 i = 0; i < 8; i++) {
        const u32 c = (u32)(v >> (8 * i)) & 0xFF;
        u32 dv;
        if (c - '0' < 10) dv = c - '0';
        else if (c - 'a' < 26) dv = c - 'a' + 10;
        else return ~0ull;
        xv = xv * 36 + dv;
    }
    if (lead0 || xv > M40) return ~0ull;
    return xv;
#endif
}
// The number of an event ID under DKEY when it is spelled the canonical way, else ~0. The 8
// bytes after the 'e' may run past the ID: every input is padded.
static inline u64 dense_num(const u8* s, size_t n) {
    if (unlikely(n - 2 >= 8 || s[0] != 'e')) return ~0ull;
    const u64 x = base36_canon(load64(s + 1), (u32)n - 1);
    if (unlikely(x == ~0ull)) return ~0ull;
    return ((unmix40(x) ^ DKEY) * SM1I) & M40;
}
#if defined(__AVX2__)
static inline __m256i mul64c(__m256i x, u64 c) {  // x * c mod 2^64, from 32-bit products (AVX2 has no 64-bit one)
    const __m256i lo = _mm256_set1_epi64x((long long)(c & 0xFFFFFFFFu)), hi = _mm256_set1_epi64x((long long)(c >> 32));
    const __m256i cross = _mm256_add_epi64(_mm256_mul_epu32(_mm256_srli_epi64(x, 32), lo), _mm256_mul_epu32(x, hi));
    return _mm256_add_epi64(_mm256_mul_epu32(x, lo), _mm256_slli_epi64(cross, 32));
}
#endif
// dense_num of 4 IDs at once: raw[k] holds the 8 bytes after the first of ID k, len[k] its
// length when that first byte is 'e', else 0. out[k]: the number, or ~0.
static inline void dense_num4(const u64* raw, const u64* len, u64* out) {
#if defined(__AVX2__)
    const __m256i ones = _mm256_set1_epi64x(-1), m40 = _mm256_set1_epi64x((long long)M40);
    const __m256i r = _mm256_load_si256((const __m256i*)raw), l = _mm256_load_si256((const __m256i*)len);
    const __m256i lenok = _mm256_and_si256(_mm256_cmpgt_epi64(l, _mm256_set1_epi64x(1)), _mm256_cmpgt_epi64(_mm256_set1_epi64x(10), l));
    const __m256i sh = _mm256_sub_epi64(_mm256_set1_epi64x(72), _mm256_slli_epi64(l, 3));  // shifts of 64 or more give 0
    const __m256i keep = _mm256_sllv_epi64(ones, sh);
    const __m256i v = _mm256_or_si256(_mm256_sllv_epi64(r, sh), _mm256_andnot_si256(keep, _mm256_set1_epi8('0')));
    const __m256i d = _mm256_sub_epi8(v, _mm256_set1_epi8('0'));
    const __m256i a = _mm256_sub_epi8(v, _mm256_set1_epi8('a'));
    const __m256i isd = _mm256_cmpeq_epi8(_mm256_min_epu8(d, _mm256_set1_epi8(9)), d);
    const __m256i isa = _mm256_cmpeq_epi8(_mm256_min_epu8(a, _mm256_set1_epi8(25)), a);
    const __m256i chars = _mm256_cmpeq_epi64(_mm256_or_si256(isd, isa), ones);
    const __m256i val = _mm256_blendv_epi8(_mm256_add_epi8(a, _mm256_set1_epi8(10)), d, isd);
    const __m256i p2 = _mm256_maddubs_epi16(val, _mm256_set1_epi16(0x0124));
    const __m256i p4 = _mm256_madd_epi16(p2, _mm256_set1_epi32(0x00010510));
    const __m256i x = _mm256_add_epi64(_mm256_mul_epu32(p4, _mm256_set1_epi64x(1679616)), _mm256_srli_epi64(p4, 32));
    const __m256i lead0 = _mm256_and_si256(_mm256_cmpeq_epi64(_mm256_and_si256(r, _mm256_set1_epi64x(0xFF)), _mm256_set1_epi64x('0')),
                                           _mm256_cmpgt_epi64(l, _mm256_set1_epi64x(2)));
    const __m256i bad = _mm256_or_si256(_mm256_andnot_si256(_mm256_and_si256(chars, lenok), ones),
                                        _mm256_or_si256(lead0, _mm256_cmpgt_epi64(x, m40)));
    __m256i y = _mm256_and_si256(mul64c(x, SM2I), m40);
    y = _mm256_xor_si256(y, _mm256_xor_si256(_mm256_srli_epi64(y, 17), _mm256_srli_epi64(y, 34)));
    const __m256i num = _mm256_and_si256(mul64c(_mm256_xor_si256(y, _mm256_set1_epi64x((long long)DKEY)), SM1I), m40);
    _mm256_store_si256((__m256i*)out, _mm256_or_si256(num, bad));
#else
    for (int k = 0; k < 4; k++) {
        const u64 x = len[k] - 2 < 8 ? base36_canon(raw[k], (u32)len[k] - 1) : ~0ull;
        out[k] = x == ~0ull ? ~0ull : ((unmix40(x) ^ DKEY) * SM1I) & M40;
    }
#endif
}

// ---------------------------------------------------------------- arena
struct ChunkMeta {
    u32 part;
    u16 fill;  // bytes used
    u8 stream;
    u8 pad;
    u32 seq;  // thread << 26 | the thread's count: the order a thread took its chunks
};
static u8* ARENA;
static ChunkMeta* META;
static std::atomic<u32> g_next_chunk{0};
static u32 MAX_CHUNKS;

static inline void nt_copy(u8* dst, const u8* src, u32 n) {  // n is a multiple of 64
#if defined(__AVX2__)
    for (u32 i = 0; i < n; i += 32) _mm256_stream_si256((__m256i*)(dst + i), _mm256_load_si256((const __m256i*)(src + i)));
#else
    memcpy(dst, src, n);
#endif
}
static inline void nt_done() {
#if defined(__x86_64__)
    _mm_sfence();
#endif
}

struct TCtx;
static u32 alloc_chunk(TCtx* t);
// A thread's staging buffers and dedup table are reached at random for every record. On
// 4 KB pages that was about 250 pages a thread at 20M, and the first-level TLB holds 64; on
// one 2 MB page of the thread's own it is one entry. The page is taken a phase at a time:
// the parse (events, clicks), then the dedup (survivors, purchases, the table).
static const size_t HOT_BYTES = 2u << 20;
static void* hot_take(TCtx* t, size_t bytes);  // nullptr when it does not fit

// Appends fixed-size records to P partitions through small staging buffers.
template <int REC, int UB>
struct Scatter {
    static constexpr int UR = UB / REC;
    static constexpr u32 CAP = (CHUNK / UB) * UB;
    struct Dst {
        u8* cur;
        u32 left;
        u32 chunk;
    };
    u32 P = 0;
    u8 stream = 0;
    TCtx* t = nullptr;
    u8* stage = nullptr;
    u8* fill = nullptr;
    Dst* dst = nullptr;
    bool hot = false;

    void init(u32 P_, u8 stream_, TCtx* t_) {
        P = P_, stream = stream_, t = t_;
        const size_t sb = (size_t)P * UB, fb = ((size_t)P + 63) & ~(size_t)63;
        u8* h = (u8*)hot_take(t_, sb + fb + sizeof(Dst) * P);
        hot = h != nullptr;
        if (hot) {
            stage = h, fill = h + sb, dst = (Dst*)(h + sb + fb);
            memset(fill, 0, P);
        } else {
            stage = (u8*)aligned_alloc(64, sb);
            fill = (u8*)calloc(P, 1);
            dst = (Dst*)malloc(sizeof(Dst) * P);
        }
        for (u32 p = 0; p < P; p++) dst[p] = {nullptr, 0, NOCHUNK};
    }
    void release() {
        if (!hot) free(stage), free(fill), free(dst);
        stage = fill = nullptr, dst = nullptr, hot = false;
    }
    inline u8* slot(u32 p) { return stage + (size_t)p * UB + (size_t)fill[p] * REC; }
    inline void commit(u32 p) {
        if (unlikely(++fill[p] == UR)) flush(p);
    }
    // Room for two records in the same unit, so they stay side by side in the chunk: a
    // unit is never split. The slot left over holds a record of zeros.
    inline void room2(u32 p) {
        if (unlikely(fill[p] == UR - 1)) {
            memset(slot(p), 0, REC);
            commit(p);
        }
    }
    void newchunk(u32 p) {
        Dst& d = dst[p];
        if (d.chunk != NOCHUNK) META[d.chunk].fill = (u16)CAP;
        u32 id = alloc_chunk(t);
        META[id].part = p, META[id].fill = 0, META[id].stream = stream;
        d.cur = ARENA + (size_t)id * CHUNK, d.left = CAP, d.chunk = id;
    }
    inline void flush(u32 p) {
        Dst& d = dst[p];
        if (unlikely(d.left == 0)) newchunk(p);
        nt_copy(d.cur, stage + (size_t)p * UB, UB);
        d.cur += UB, d.left -= UB;
        fill[p] = 0;
    }
    void finish() {
        for (u32 p = 0; p < P; p++) {
            Dst& d = dst[p];
            if (fill[p]) {
                if (d.left == 0) newchunk(p);
                u32 nb = (u32)fill[p] * REC;
                memcpy(d.cur, stage + (size_t)p * UB, nb);
                d.cur += nb, d.left = 0;  // a partly filled unit ends the chunk
                fill[p] = 0;
            }
            if (d.chunk != NOCHUNK) {
                META[d.chunk].fill = (u16)(d.cur - (ARENA + (size_t)d.chunk * CHUNK));
                d = {nullptr, 0, NOCHUNK};
            }
        }
        nt_done();
    }
};

struct ERec {
    u64 ekey;
    u32 ingest;
    u32 person;
    u32 ts;
    u32 aux;
};
// An event with a dense number (see dense_num): w0 = ingest << 32 | kind << 30 | the number's
// low DLSH bits, w1 = person << 31 | ts, the key the person buckets sort by. A purchase's
// price and category (aux) are in the low half of the next record's w1, a record of kind 0.
// A record of zeros is padding.
struct DRec {
    u64 w0, w1;
};
enum : u32 { DK_SKIP = 0, DK_INVALID = 1, DK_PLAIN = 2, DK_PURCHASE = 3 };
static const u64 DK_MASK = 3ull << 30;
struct Purch {
    u64 key;
    u32 aux;
    u32 pad;
};
struct Click {
    u64 key;
    u64 ckey;
};

struct Lists {
    std::vector<u32> start, ids;
    u32 count(u32 p) const { return start[p + 1] - start[p]; }
};
static Lists build_lists(u8 stream, u32 P) {
    Lists L;
    u32 nch = g_next_chunk.load();
    L.start.assign(P + 2, 0);
    for (u32 i = 0; i < nch; i++)
        if (META[i].stream == stream && META[i].fill) L.start[META[i].part + 2]++;
    for (u32 p = 0; p < P; p++) L.start[p + 2] += L.start[p + 1];
    L.ids.resize(L.start[P + 1]);
    for (u32 i = 0; i < nch; i++)
        if (META[i].stream == stream && META[i].fill) L.ids[L.start[META[i].part + 1]++] = i;
    L.start.pop_back();
    return L;
}

// ---------------------------------------------------------------- parquet
struct Buf {
    u8* p = nullptr;
    size_t n = 0, cap = 0;
    inline void ensure(size_t extra) {
        if (unlikely(n + extra > cap)) {
            cap = std::max(cap * 2, n + extra + 4096);
            p = (u8*)realloc(p, cap);
        }
    }
    inline void put(const void* s, size_t len) {
        ensure(len);
        memcpy(p + n, s, len);
        n += len;
    }
    inline void u8v(u8 v) { ensure(1), p[n++] = v; }
    inline void u32v(u32 v) { put(&v, 4); }
    inline void i64v(i64 v) { put(&v, 8); }
    void varint(u64 v) {
        while (v >= 0x80) u8v((u8)(v | 0x80)), v >>= 7;
        u8v((u8)v);
    }
    void zz(i64 v) { varint(((u64)v << 1) ^ (u64)(v >> 63)); }
};

struct Thrift {
    Buf& b;
    int last = 0;
    std::vector<int> stack;
    explicit Thrift(Buf& b_) : b(b_) {}
    void fh(int id, int type) {
        int d = id - last;
        if (d > 0 && d <= 15) b.u8v((u8)((d << 4) | type));
        else b.u8v((u8)type), b.zz(id);
        last = id;
    }
    void i32f(int id, i32 v) { fh(id, 5), b.zz(v); }
    void i64f(int id, i64 v) { fh(id, 6), b.zz(v); }
    void strf(int id, const std::string& s) { fh(id, 8), b.varint(s.size()), b.put(s.data(), s.size()); }
    void listf(int id, int etype, size_t n) {
        fh(id, 9);
        if (n < 15) b.u8v((u8)((n << 4) | etype));
        else b.u8v((u8)(0xF0 | etype)), b.varint(n);
    }
    void open() { stack.push_back(last), last = 0; }
    void openf(int id) { fh(id, 12), open(); }
    void close() { b.u8v(0), last = stack.back(), stack.pop_back(); }
};

enum { PQ_INT32 = 1, PQ_INT64 = 2, PQ_BYTES = 6 };
struct PqCol {
    std::string name;
    int type;
    int conv;  // -1 none, 0 UTF8, 6 DATE
    bool optional;
};
struct PqPart {
    const u8* data;
    size_t len;
    const u8* defbits;  // optional columns: one bit per row, set when not null
};
struct PqFile {
    int fd = -1;
    u64 off = 0, nrows = 0;
    std::vector<PqCol> cols;
    struct CC {
        u64 page_off, size;
    };
    struct RG {
        u64 rows, bytes;
        std::vector<CC> cc;
    };
    std::vector<RG> rgs;

    static void write_all(int fd, iovec* iov, int cnt) {
        while (cnt) {
            ssize_t w = writev(fd, iov, std::min(cnt, 512));
            if (w < 0) {
                if (errno == EINTR) continue;
                die("write failed: %s", strerror(errno));
            }
            size_t left = (size_t)w;
            while (cnt && left >= iov->iov_len) left -= iov->iov_len, iov++, cnt--;
            if (cnt && left) iov->iov_base = (u8*)iov->iov_base + left, iov->iov_len -= left;
        }
    }
    void open(const std::string& path, std::vector<PqCol> c) {
        cols = std::move(c);
        fd = ::open(path.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0666);
        if (fd < 0) die("cannot create %s: %s", path.c_str(), strerror(errno));
        iovec v = {(void*)"PAR1", 4};
        write_all(fd, &v, 1);
        off = 4;
    }
    void row_group(u64 rows, const PqPart* parts) {
        size_t nc = cols.size();
        std::vector<Buf> hdr(nc), lvl(nc);
        std::vector<iovec> iov;
        RG rg;
        rg.rows = rows, rg.bytes = 0;
        u64 at = off;
        for (size_t i = 0; i < nc; i++) {
            size_t body = parts[i].len;
            if (cols[i].optional) {
                size_t nbytes = (size_t)((rows + 7) / 8);
                Buf rle;
                rle.varint(((u64)nbytes << 1) | 1);
                lvl[i].u32v((u32)(rle.n + nbytes));
                lvl[i].put(rle.p, rle.n);
                lvl[i].put(parts[i].defbits, nbytes);
                free(rle.p);
                body += lvl[i].n;
            }
            Thrift t(hdr[i]);
            t.i32f(1, 0);
            t.i32f(2, (i32)body);
            t.i32f(3, (i32)body);
            t.openf(5);
            t.i32f(1, (i32)rows);
            t.i32f(2, 0);
            t.i32f(3, 3);
            t.i32f(4, 3);
            t.close();
            hdr[i].u8v(0);
            u64 size = hdr[i].n + body;
            rg.cc.push_back({at, size});
            rg.bytes += size;
            at += size;
            iov.push_back({hdr[i].p, hdr[i].n});
            if (lvl[i].n) iov.push_back({lvl[i].p, lvl[i].n});
            if (parts[i].len) iov.push_back({(void*)parts[i].data, parts[i].len});
        }
        write_all(fd, iov.data(), (int)iov.size());
        for (size_t i = 0; i < nc; i++) free(hdr[i].p), free(lvl[i].p);
        off = at;
        nrows += rows;
        rgs.push_back(std::move(rg));
    }
    void close() {
        Buf f;
        Thrift t(f);
        t.i32f(1, 1);
        t.listf(2, 12, cols.size() + 1);
        t.open();
        t.strf(4, "schema");
        t.i32f(5, (i32)cols.size());
        t.close();
        for (auto& c : cols) {
            t.open();
            t.i32f(1, c.type);
            t.i32f(3, c.optional ? 1 : 0);
            t.strf(4, c.name);
            if (c.conv >= 0) {
                t.i32f(6, c.conv);
                t.openf(10);
                t.openf(c.conv == 0 ? 1 : 6);
                t.close();
                t.close();
            }
            t.close();
        }
        t.i64f(3, (i64)nrows);
        t.listf(4, 12, rgs.size());
        for (auto& rg : rgs) {
            t.open();
            t.listf(1, 12, cols.size());
            for (size_t i = 0; i < cols.size(); i++) {
                t.open();
                t.i64f(2, (i64)rg.cc[i].page_off);
                t.openf(3);
                t.i32f(1, cols[i].type);
                t.listf(2, 5, 2);
                f.zz(0), f.zz(3);
                t.listf(3, 8, 1);
                f.varint(cols[i].name.size()), f.put(cols[i].name.data(), cols[i].name.size());
                t.i32f(4, 0);
                t.i64f(5, (i64)rg.rows);
                t.i64f(6, (i64)rg.cc[i].size);
                t.i64f(7, (i64)rg.cc[i].size);
                t.i64f(9, (i64)rg.cc[i].page_off);
                t.close();
                t.close();
            }
            t.i64f(2, (i64)rg.bytes);
            t.i64f(3, (i64)rg.rows);
            t.close();
        }
        t.strf(6, "shopping-sessions native");
        f.u8v(0);
        u32 flen = (u32)f.n;
        f.u32v(flen);
        f.put("PAR1", 4);
        iovec v = {f.p, f.n};
        write_all(fd, &v, 1);
        free(f.p);
        ::close(fd);
        fd = -1;
    }
};

static std::string OUT_DIR;

static std::vector<PqCol> user_daily_cols() {
    return {{"user_id", PQ_BYTES, 0, false},  {"day", PQ_INT32, 6, false},          {"sessions", PQ_INT32, -1, false},
            {"events", PQ_INT32, -1, false},  {"revenue_cents", PQ_INT64, -1, false}, {"top_category", PQ_BYTES, 0, true}};
}

static const u32 RG_ROWS = 1 << 17;
struct UDWriter {
    PqFile f;
    bool opened = false;
    int tid = 0;
    Buf uid, day, ses, evs, rev, cat;
    std::vector<u8> defbits;
    u32 rows = 0;
    u64 total = 0;
    void init(int tid_) {
        tid = tid_;
        defbits.assign(RG_ROWS / 8 + 8, 0);
    }
    void flush() {
        if (!rows) return;
        if (!opened) {
            char name[64];
            snprintf(name, sizeof name, "/user_daily/part-%03d.parquet", tid);
            f.open(OUT_DIR + name, user_daily_cols());
            opened = true;
        }
        PqPart parts[6] = {{uid.p, uid.n, nullptr}, {day.p, day.n, nullptr}, {ses.p, ses.n, nullptr},
                           {evs.p, evs.n, nullptr}, {rev.p, rev.n, nullptr}, {cat.p, cat.n, defbits.data()}};
        f.row_group(rows, parts);
        total += rows;
        uid.n = day.n = ses.n = evs.n = rev.n = cat.n = 0;
        memset(defbits.data(), 0, defbits.size());
        rows = 0;
    }
    inline void row(u64 ukey, i32 d, u32 sessions, u32 events, i64 revenue, i32 topcat) {
        if (likely(!(ukey & SLOW))) {
            uid.ensure(16);
            u8* o = uid.p + uid.n;
            size_t len = key_str_fast(ukey, 'u', o + 4);
            u32 l32 = (u32)len;
            memcpy(o, &l32, 4);
            uid.n += 4 + len;
        } else {
            std::string s = g_intern.get(ukey);
            uid.u32v((u32)s.size());
            uid.put(s.data(), s.size());
        }
        day.put(&d, 4);
        ses.put(&sessions, 4);
        evs.put(&events, 4);
        rev.put(&revenue, 8);
        if (topcat >= 0) {
            const std::string& c = CAT_NAME[topcat];
            cat.u32v((u32)c.size());
            cat.put(c.data(), c.size());
            defbits[rows >> 3] |= (u8)(1u << (rows & 7));
        }
        if (++rows == RG_ROWS) flush();
    }
    void close() {
        flush();
        if (opened) f.close();
    }
};

// ---------------------------------------------------------------- threads
// A session adds to its own campaign's cell and to the assisted count of every campaign
// clicked in the 7 days before it, so the assisted counts are kept apart. At 14 days and
// 2,000 campaigns that is 112 KB a thread next to 16-byte cells (448 KB), where 24-byte cells
// took 672 KB, and the scorer's 1 MB L2 is shared by two threads.
struct CampAcc {
    u32 sessions, purchasing;
    i64 revenue;
};

struct Seg {  // a run of one person's events in a chunk (group_persons)
    const u64* p;
    u32 len, who;
};
struct TCtx {
    int tid = 0;
    Scan sc;
    u8* rbuf = nullptr;  // read buffer
    u64 rcap = 0;
    TabCounter tc;
    std::vector<u32> joined;  // slots this thread's unions put under another
    std::vector<u32> freelist;
    u32 cnext = 0, cend = 0;  // chunks taken from the arena and not handed out yet
    Scatter<24, 192> se;  // events by event partition
    Scatter<16, 192> sd;  // events with a dense number, by dense partition
    Scatter<16, 64> sk;   // clicks by person bucket
    Scatter<8, 64> sm;    // surviving events by person bucket
    Scatter<16, 64> sp;   // surviving purchases by person bucket
    std::vector<u64> wide;  // purchases when a category does not fit 8 bits
    // dedup
    std::vector<u64> dtab;
    u64* dtab_hot = nullptr;  // the rest of the hot page, in the dedup
    size_t dtab_cap = 0;      // its slots
    u32* dt = nullptr;        // the dense table: 2^DLSH entries, on the hot page or in dtv
    std::vector<u32> dtv;
    u8* hot = nullptr;        // HOT_BYTES, 2 MB-aligned, inside hot_map
    void* hot_map = nullptr;
    size_t hot_used = 0;
    // buckets
    std::vector<u64> A, B;
    std::vector<u32> pend;  // where each person's events end in A (group_persons)
    std::vector<u64> dkey;  // the winners' keys by number (dedup_dense, NORDER)
    std::vector<u32> cord;  // a bucket's chunks in the order they were written (group_persons)
    std::vector<Seg> segs;        // its runs of one person (group_persons)
    std::vector<u32> fixl;         // the persons to sort (group_persons)
    std::vector<u8> pfix;
    u32 cseq = 0;
    std::vector<Purch> PV;
    std::vector<Click> CA, CB2;
    std::vector<CampAcc> cd;
    std::vector<u32> assist;  // assisted sessions by day and campaign
    std::vector<u32> wcnt, wpos, wact;
    std::vector<i64> catsum;
    std::vector<u32> cattouched;
    UDWriter ud;
    u64 n_rows = 0, n_ok = 0, n_surv = 0, n_clicks = 0, n_sessions = 0, n_dense = 0;
    u64 tk[8] = {0, 0, 0, 0, 0, 0, 0, 0};  // dedup: table, scatter; buckets: gather, sort, purchases, clicks, walk
};
static std::vector<TCtx*> TC;

static u32 alloc_chunk(TCtx* t) {
    u32 id;
    if (!t->freelist.empty()) {
        id = t->freelist.back();
        t->freelist.pop_back();
    } else {
        if (unlikely(t->cnext == t->cend)) {
            u32 c = g_next_chunk.fetch_add(CHUNK_BATCH, std::memory_order_relaxed);
            if (unlikely((u64)c + CHUNK_BATCH > MAX_CHUNKS)) die("record arena exhausted");
            t->cnext = c, t->cend = c + CHUNK_BATCH;
        }
        id = t->cnext++;
    }
    META[id].seq = (u32)t->tid << 26 | (t->cseq++ & ((1u << 26) - 1));
    return id;
}

// SS_PIN: thread i stays on the i-th CPU this process may use, cores first and their second
// hyperthreads after. Off unless asked for: the scheduler usually does as well by itself.
static bool PIN = false;
static std::vector<int> PIN_CPUS;
static void pin_init() {
    cpu_set_t set;
    if (sched_getaffinity(0, sizeof set, &set)) return;
    std::vector<std::pair<long, int>> first, rest;  // (core, cpu)
    std::vector<long> seen;
    for (int c = 0; c < CPU_SETSIZE; c++) {
        if (!CPU_ISSET(c, &set)) continue;
        long core = c;
        char path[96];
        snprintf(path, sizeof path, "/sys/devices/system/cpu/cpu%d/topology/core_id", c);
        if (FILE* f = fopen(path, "r")) {
            if (fscanf(f, "%ld", &core) != 1) core = c;
            fclose(f);
        }
        bool again = std::find(seen.begin(), seen.end(), core) != seen.end();
        if (!again) seen.push_back(core);
        (again ? rest : first).push_back({core, c});
    }
    PIN_CPUS.clear();
    for (auto& p : first) PIN_CPUS.push_back(p.second);
    for (auto& p : rest) PIN_CPUS.push_back(p.second);
}
static inline void pin_thread(int i) {
    if (!PIN || PIN_CPUS.empty()) return;
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(PIN_CPUS[(size_t)i % PIN_CPUS.size()], &set);
    sched_setaffinity(0, sizeof set, &set);
}

template <class F>
static void run_threads(F&& f) {
    std::vector<std::thread> th;
    for (int i = 1; i < T; i++)
        th.emplace_back([&f, i] {
            pin_thread(i);
            f(i);
        });
    pin_thread(0);
    f(0);
    for (auto& t : th) t.join();
}

// ---------------------------------------------------------------- inputs
struct MFile {
    const u8* p = nullptr;  // set when the file is memory-mapped (SS_MMAP=1)
    u64 size = 0;
    int fd = -1;  // otherwise it is read in pieces from this descriptor
};
static const u64 PADB = 1 << 16;
static bool USE_MMAP = false;
// How a mapped file is used (SS_MMAP=n). 1: each piece is dropped from the page
// tables by the thread that parsed it, so no file page is left to unmap when the
// process exits. 2: the same, and each piece is first faulted in with one call.
static int MMAP_MODE = 0;
static bool COPY_SLOW = false;  // the startup copy test (in main) found reading slow, so the input is mapped
#ifndef MADV_POPULATE_READ
#define MADV_POPULATE_READ 22
#endif
#ifndef MADV_POPULATE_WRITE
#define MADV_POPULATE_WRITE 23
#endif

static MFile map_file(const std::string& path) {
    MFile m;
    int fd = open(path.c_str(), O_RDONLY | O_CLOEXEC);
    if (fd < 0) die("cannot open %s: %s", path.c_str(), strerror(errno));
    struct stat st;
    if (fstat(fd, &st)) die("cannot stat %s", path.c_str());
    m.size = (u64)st.st_size;
    if (m.size && !USE_MMAP) {
        posix_fadvise(fd, 0, 0, POSIX_FADV_SEQUENTIAL);
        m.fd = fd;
        return m;
    }
    if (m.size) {
        u64 rounded = (m.size + 4095) & ~4095ULL;
        u8* r = (u8*)mmap(nullptr, rounded + PADB, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
        if (r == MAP_FAILED) die("mmap failed for %s", path.c_str());
        if (mmap(r, m.size, PROT_READ, MAP_PRIVATE | MAP_FIXED, fd, 0) == MAP_FAILED)
            die("cannot map %s: %s", path.c_str(), strerror(errno));
        m.p = r;
    }
    close(fd);
    return m;
}
// Maps a file that was opened for reading (see the copy test in main).
static void map_open_file(MFile& m) {
    if (m.fd < 0 || !m.size) return;
    u64 rounded = (m.size + 4095) & ~4095ULL;
    u8* r = (u8*)mmap(nullptr, rounded + PADB, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (r == MAP_FAILED) die("mmap failed for an input file");
    if (mmap(r, m.size, PROT_READ, MAP_PRIVATE | MAP_FIXED, m.fd, 0) == MAP_FAILED) die("cannot map an input file: %s", strerror(errno));
    m.p = r;
    close(m.fd);
    m.fd = -1;
}
static std::vector<MFile> map_dir(const std::string& dir, u64& total) {
    std::vector<std::string> names;
    if (DIR* d = opendir(dir.c_str())) {
        while (dirent* e = readdir(d)) {
            std::string n = e->d_name;
            if (n.size() > 4 && n.compare(n.size() - 4, 4, ".csv") == 0) names.push_back(n);
        }
        closedir(d);
    }
    std::sort(names.begin(), names.end());
    std::vector<MFile> out;
    for (auto& n : names) {
        std::string path = dir + "/" + n;
        struct stat st;
        if (stat(path.c_str(), &st) || !S_ISREG(st.st_mode)) continue;
        MFile m = map_file(path);
        total += m.size;
        if (m.size) out.push_back(m);
    }
    return out;
}
static std::string read_small(const std::string& path) {
    int fd = open(path.c_str(), O_RDONLY);
    if (fd < 0) die("cannot open %s: %s", path.c_str(), strerror(errno));
    std::string s;
    char buf[65536];
    ssize_t r;
    while ((r = read(fd, buf, sizeof buf)) > 0) s.append(buf, (size_t)r);
    close(fd);
    return s;
}

struct Work {
    const MFile* f;
    u64 cs, ce;
    u8 kind;  // 0 events, 1 clicks, 2 links
};
static inline void piece_populate(const Work& w) {
    if (MMAP_MODE != 2 || !w.f->p) return;
    u64 a = w.cs & ~4095ULL, b = (std::min(w.f->size, w.ce) + 4095) & ~4095ULL;
    if (b > a) madvise((void*)(w.f->p + a), b - a, MADV_POPULATE_READ);
}
static inline void piece_drop(const Work& w) {
    if (!w.f->p) return;
    // Only the pages that lie wholly inside the piece: its neighbours read the edges.
    // The pages stay in the page cache, so a neighbour reading across an edge only takes a fault.
    u64 a = (w.cs + 4095) & ~4095ULL, b = std::min(w.f->size, w.ce) & ~4095ULL;
    if (b > a) madvise((void*)(w.f->p + a), b - a, MADV_DONTNEED);
}
static void add_work(std::vector<Work>& w, const std::vector<MFile>& files, u8 kind, u64 step) {
    if (!USE_MMAP) step = 128 << 10;  // small pieces, so the read buffer stays in cache
    for (auto& f : files)
        for (u64 at = 0; at < f.size; at += step) w.push_back({&f, at, std::min(f.size, at + step), kind});
}

// The bytes a piece of work needs, as (buf, len) and the piece's range inside
// it. A mapped file is used in place. Otherwise the piece is read into the
// thread's buffer, from one byte before it (to see whether a line starts at its
// first byte) to the end of the last line that starts in it.
static bool NOSKEW = false;
static void work_view(TCtx& t, const Work& w, const u8*& buf, u64& len, u64& cs, u64& ce) {
    const MFile& f = *w.f;
    if (f.p) {
        buf = f.p, len = f.size, cs = w.cs, ce = w.ce;
        return;
    }
    const u64 from = w.cs ? w.cs - 1 : 0;
    // The data lands at the same offset inside a page as it has in the file. A piece
    // starts one byte before a page boundary, and with a page-aligned buffer the kernel
    // would copy every page to an address one byte off: measured three times slower in
    // the kernel on AMD Zen 3 and Zen 4. SS_NOSKEW: the buffer's first byte, as before.
    const u64 skew = NOSKEW ? 0 : (from & 4095);
    u64 slack = 4096;
    for (;;) {
        u64 to = std::min(f.size, w.ce + slack);
        u64 need = to - from;
        if (t.rcap < need + skew + 256) {
            free(t.rbuf);
            t.rcap = ((need + 4096 + 256 + need / 8) + 4095) & ~(u64)4095;
            t.rbuf = (u8*)aligned_alloc(4096, t.rcap);
        }
        u8* const dst = t.rbuf + skew;
        u64 got = 0;
        while (got < need) {
            ssize_t r = pread(f.fd, dst + got, need - got, (off_t)(from + got));
            if (r < 0) {
                if (errno == EINTR) continue;
                die("read failed: %s", strerror(errno));
            }
            if (r == 0) die("a file shrank while it was read");
            got += (u64)r;
        }
        memset(dst + need, 0, 256);
        u64 tail = w.ce - 1 - from;  // the last line of the piece ends at or after this byte
        if (to == f.size || memchr(dst + tail, '\n', need - tail)) {
            buf = dst, len = need, cs = w.cs ? 1 : 0, ce = w.ce - from;
            return;
        }
        slack *= 16;
    }
}

// ---------------------------------------------------------------- lookups from files
struct PairRows {
    std::vector<std::pair<std::string, std::string>> rows;
    void row(const u8** s, const u8** e) {
        rows.emplace_back(std::string((const char*)s[0], e[0] - s[0]), std::string((const char*)s[1], e[1] - s[1]));
    }
};
static PairRows read_pairs(const std::string& path) {
    std::string raw = read_small(path);
    size_t n = raw.size();
    raw.append(128, '\0');
    PairRows pr;
    const u8* b = (const u8*)raw.data();
    size_t pos = 0;
    bool header = true;
    while (pos < n) {
        const u8* nl = (const u8*)memchr(b + pos, '\n', n - pos);
        size_t end = nl ? (size_t)(nl - b) : n;
        if (!header) slow_line<2, PairRows>(b + pos, b + end, pr);
        header = false;
        pos = end + 1;
    }
    return pr;
}
static void load_products(const std::string& dir) {
    PairRows pr = read_pairs(dir + "/products.csv");
    std::unordered_map<std::string, u32> cats;
    std::vector<std::pair<std::string, u32>> prods;
    for (auto& r : pr.rows) {
        if (r.first.empty()) continue;
        auto it = cats.find(r.second);
        u32 c;
        if (it == cats.end()) c = (u32)CAT_NAME.size(), cats.emplace(r.second, c), CAT_NAME.push_back(r.second);
        else c = it->second;
        prods.emplace_back(r.first, c);
    }
    NCAT = (u32)CAT_NAME.size();
    CAT_NAME.push_back("unknown");
    WIDE_CAT = NCAT + 1 > 256;
    std::vector<u32> order(NCAT + 1);
    for (u32 i = 0; i <= NCAT; i++) order[i] = i;
    std::sort(order.begin(), order.end(), [](u32 a, u32 b) { return CAT_NAME[a] < CAT_NAME[b]; });
    CAT_RANK.resize(NCAT + 1);
    for (u32 i = 0; i <= NCAT; i++) CAT_RANK[order[i]] = i;
    for (auto& p : prods) {
        u32 num;
        std::string padded = p.first + std::string(16, '\0');
        const u8* s = (const u8*)padded.data();
        if (p.first.size() >= 2 && s[0] == 'p' && canon_num(s + 1, p.first.size() - 1, num)) {
            if (num >= PROD_DIRECT.size()) PROD_DIRECT.resize((size_t)num + 1, NCAT);
            PROD_DIRECT[num] = p.second;
        } else {
            PROD_MAP.emplace(p.first, p.second);
        }
    }
}
static void load_campaigns(const std::string& dir) {
    PairRows pr = read_pairs(dir + "/campaigns.csv");
    for (auto& r : pr.rows) {
        if (r.first.empty()) continue;
        u32 idx = (u32)CAMP_NAME.size();
        u32 num;
        std::string padded = r.first + std::string(16, '\0');
        const u8* s = (const u8*)padded.data();
        if (r.first.size() >= 3 && s[0] == 'c' && s[1] == '_' && canon_num(s + 2, r.first.size() - 2, num)) {
            if (num >= CAMP_DIRECT.size()) CAMP_DIRECT.resize((size_t)num + 1, -1);
            if (CAMP_DIRECT[num] >= 0) continue;
            CAMP_DIRECT[num] = (i32)idx;
        } else {
            if (!CAMP_MAP.emplace(r.first, idx).second) continue;
        }
        CAMP_NAME.push_back(r.first);
        CAMP_CHANNEL.push_back(r.second);
    }
    NCAMP = (u32)CAMP_NAME.size();
    CAMP_NAME.push_back("organic");
    CAMP_CHANNEL.push_back("organic");
}
static i64 manifest_ts(const std::string& js, const char* key) {
    size_t k = js.find(std::string("\"") + key + "\"");
    if (k == std::string::npos) die("manifest.json has no %s", key);
    size_t colon = js.find(':', k);
    size_t q1 = js.find('"', colon + 1);
    size_t q2 = js.find('"', q1 + 1);
    if (colon == std::string::npos || q1 == std::string::npos || q2 == std::string::npos) die("bad manifest.json");
    std::string v = js.substr(q1 + 1, q2 - q1 - 1);
    std::string padded = v + std::string(64, '\0');
    i64 t = parse_ts((const u8*)padded.data(), v.size());
    if (t == BAD_TS) die("bad %s in manifest.json", key);
    return t;
}

// ---------------------------------------------------------------- row handlers
static const int BATCH = 32;  // rows a handler prefetches before it joins them: 32 keeps more table misses in flight than 16

// Links are looked up in batches too: the table is far larger than the cache,
// so each line's two slots, and then the two slots' parents, are fetched while
// the lines before them are still being joined.
struct LinkH {
    static constexpr int CLS = -1;
    TCtx& t;
    struct Item {
        u64 ka, kb, ha, hb;
    } items[BATCH];
    int n = 0;
    explicit LinkH(TCtx& t_) : t(t_) {}
    inline void flush() {
        u32 sa[BATCH], sb[BATCH];
        for (int i = 0; i < n; i++) {
            Item& it = items[i];
            sa[i] = tab_slot(it.ka, it.ha, t.tc);
            sb[i] = it.ka == it.kb ? sa[i] : tab_slot(it.kb, it.hb, t.tc);
        }
        if (unlikely(g_overflow.load(std::memory_order_relaxed))) {
            n = 0;
            return;
        }
        for (int i = 0; i < n; i++) {
            u32 pa = __atomic_load_n(&TAB[sa[i]].parent, __ATOMIC_RELAXED);
            u32 pb = __atomic_load_n(&TAB[sb[i]].parent, __ATOMIC_RELAXED);
            if (pa) __builtin_prefetch(&TAB[pa - 1]);
            if (pb) __builtin_prefetch(&TAB[pb - 1]);
        }
        for (int i = 0; i < n; i++)
            if (sa[i] != sb[i]) uf_union(sa[i], sb[i], t.joined);
        n = 0;
    }
    ROW_INLINE inline void row(const u8** s, const u8** e) {
        size_t la = (size_t)(e[0] - s[0]), lb = (size_t)(e[1] - s[1]);
        if (!la || !lb) return;
        Item& it = items[n];
        it.ka = id_key(s[0], la, 'u'), it.kb = id_key(s[1], lb, 'u');
        it.ha = tab_home(it.ka), it.hb = tab_home(it.kb);
        __builtin_prefetch(&TAB[it.ha], 1);
        __builtin_prefetch(&TAB[it.ha + 1], 1);
        __builtin_prefetch(&TAB[it.hb], 1);
        __builtin_prefetch(&TAB[it.hb + 1], 1);
        if (++n == BATCH) flush();
    }
};

struct EventH {
    static constexpr int CLS = 2;  // ts
    TCtx& t;
    struct Item {
        u64 ukey, home;
        const u8* id;  // the event ID, read again for its hashed key when its number is not dense
        u32 ingest, ts, aux, len;
    } items[BATCH];
    // The dense numbers are decoded in flush, 4 at a time: the 8 bytes after each ID's first,
    // and its length when that first byte is 'e' (else 0, which no number has).
    static_assert(BATCH % 4 == 0, "dense_num4 decodes 4 at a time");
    alignas(32) u64 draw[BATCH], dlen[BATCH], ddn[BATCH];
    int n = 0;
    explicit EventH(TCtx& t_) : t(t_) {
        memset(draw, 0, sizeof draw);
        memset(dlen, 0, sizeof dlen);
    }

    inline void emit(u64 ekey, u32 ingest, u32 person, u32 ts, u32 aux) {
        u32 p = (u32)(hash1(ekey) >> (64 - PEB));
        ERec* r = (ERec*)t.se.slot(p);
        r->ekey = ekey, r->ingest = ingest, r->person = person, r->ts = ts, r->aux = aux;
        t.se.commit(p);
    }
    inline void emit_dense(u64 num, u32 ingest, u32 kind, u64 w1) {
        const u32 p = (u32)(num >> DLSH);
        DRec* r = (DRec*)t.sd.slot(p);
        r->w0 = ((u64)ingest << 32) | ((u64)kind << 30) | (num & ((1u << DLSH) - 1));
        r->w1 = w1;
        t.sd.commit(p);
    }
    inline void emit_dense_purchase(u64 num, u32 ingest, u64 w1, u32 aux) {
        const u32 p = (u32)(num >> DLSH);
        t.sd.room2(p);
        DRec* r = (DRec*)t.sd.slot(p);
        r[0].w0 = ((u64)ingest << 32) | ((u64)DK_PURCHASE << 30) | (num & ((1u << DLSH) - 1));
        r[0].w1 = w1;
        r[1].w0 = 0, r[1].w1 = aux;
        t.sd.fill[p]++;  // room2 left two slots, so only the second can fill the unit
        t.sd.commit(p);
    }
    inline void flush() {
        const u64 lim = DLIMIT;
        if (lim)
            for (int i = 0; i < n; i += 4) dense_num4(draw + i, dlen + i, ddn + i);
        for (int i = 0; i < n; i++) {
            Item& it = items[i];
            u32 person = tab_person(tab_slot(it.ukey, it.home, t.tc));
            if (unlikely(STAGE == 4)) {
                t.n_surv += person & 1;
                continue;
            }
            const u64 dn = lim ? ddn[i] : ~0ull;
            if (likely(dn < lim)) {
                const u64 w1 = ((u64)person << 31) | it.ts;
                if (unlikely(it.aux)) emit_dense_purchase(dn, it.ingest, w1, it.aux);
                else emit_dense(dn, it.ingest, DK_PLAIN, w1);
            } else {
                emit(id_key(it.id, it.len, 'e'), it.ingest, person, it.ts, it.aux);
            }
        }
        n = 0;
    }
    ROW_INLINE inline void row(const u8** s, const u8** e) {
        size_t l0 = (size_t)(e[0] - s[0]);
        if (unlikely(!l0)) return;
        t.n_rows++;
        i64 isec = 0;
        bool ok = (e[3] - s[3] == 20) && s[3][19] == 'Z' && parse_dt19(s[3], isec);
        if (unlikely(!ok)) isec = INT64_MAX / 4096;
        i64 irel = isec - ING_BASE;
        u32 ingest = irel < 0 ? 0 : irel > 0xFFFFFFFFLL ? 0xFFFFFFFFu : (u32)irel;
        size_t l1 = (size_t)(e[1] - s[1]);
        i64 ts = parse_ts(s[2], (size_t)(e[2] - s[2]));
        ok &= l1 != 0;
        ok &= (ts >= WS) & (ts < WE);
        size_t l4 = (size_t)(e[4] - s[4]);
        // view or cart is a coin toss per row and only "one of the two" matters, so it is one
        // flag without a branch. The loads may run past a short field: every input is padded.
        const u32 w4 = load32(s[4]);
        const bool viewcart = (l4 == 4) & ((w4 == 0x77656976u) | (w4 == 0x74726163u));
        const bool purchase = (l4 == 8) & (load64(s[4]) == 0x6573616863727570ULL);
        ok &= viewcart | purchase;
        size_t l5 = (size_t)(e[5] - s[5]);
        ok &= l5 != 0;
        ok &= ((i64)((u64)isec * 1000 - (u64)ts) <= DAYMS);
        u32 aux = 0;
        if (unlikely(purchase) && ok) {
            u64 price;
            if (parse_digits(s[6], (size_t)(e[6] - s[6]), price) && price - 1 < 10000000) {
                u32 cat = product_cat(s[5], l5);
                if (likely(!WIDE_CAT)) {
                    aux = ((u32)price << 8) | cat;
                } else {
                    t.wide.push_back(price | ((u64)cat << 32));
                    if (t.wide.size() >= (1u << 27)) die("too many purchases for wide categories");
                    aux = ((u32)t.tid << 27) | (u32)t.wide.size();
                }
            } else {
                ok = false;
            }
        }
        if (unlikely(STAGE == 3)) {
            t.n_ok += ok + (aux & 1) + (id_key(s[0], l0, 'e') & 1) + (ingest & 1);
            return;
        }
        if (unlikely(!ok)) {
            const u64 dn = DLIMIT ? dense_num(s[0], l0) : ~0ull;
            if (dn < DLIMIT) emit_dense(dn, ingest, DK_INVALID, 0);
            else emit(id_key(s[0], l0, 'e'), ingest, INVALID, 0, 0);
            return;
        }
        t.n_ok++;
        u64 ukey = id_key(s[1], l1, 'u');
        u64 home = tab_home(ukey);
        __builtin_prefetch(&TAB[home]);
        __builtin_prefetch(&TAB[home + 1]);  // the next slot is on another cache line one time in four
        Item& it = items[n];
        it.ukey = ukey, it.home = home, it.id = s[0], it.len = (u32)l0;
        it.ingest = ingest, it.ts = (u32)(ts - WS), it.aux = aux;
        draw[n] = load64(s[0] + 1);
        dlen[n] = s[0][0] == 'e' ? l0 : 0;
        if (++n == BATCH) flush();
    }
};

struct ClickH {
    static constexpr int CLS = 3;  // ts
    TCtx& t;
    struct Item {
        u64 ckey, ukey, home;
        u32 ts, camp;
    } items[BATCH];
    int n = 0;
    explicit ClickH(TCtx& t_) : t(t_) {}
    inline void flush() {
        for (int i = 0; i < n; i++) {
            Item& it = items[i];
            u32 person = tab_person(tab_slot(it.ukey, it.home, t.tc));
            u32 b = person >> LW;
            u64 local = person & ((1u << LW) - 1);
            Click* c = (Click*)t.sk.slot(b);
            c->key = (((local << 31) | it.ts) << CBITS) | it.camp;
            c->ckey = it.ckey;
            t.sk.commit(b);
        }
        n = 0;
    }
    ROW_INLINE inline void row(const u8** s, const u8** e) {
        size_t l0 = (size_t)(e[0] - s[0]), l1 = (size_t)(e[1] - s[1]);
        if (unlikely(!l0 || !l1)) return;
        i64 ts = parse_ts(s[3], (size_t)(e[3] - s[3]));
        if (unlikely(ts < CWS || ts >= WE)) return;  // BAD_TS is below every window
        i32 camp = campaign_idx(s[2], (size_t)(e[2] - s[2]));
        if (unlikely(camp < 0)) return;
        t.n_clicks++;
        u64 ukey = id_key(s[1], l1, 'u');
        u64 home = tab_home(ukey);
        __builtin_prefetch(&TAB[home]);
        __builtin_prefetch(&TAB[home + 1]);  // the next slot is on another cache line one time in four
        Item& it = items[n];
        it.ckey = id_key(s[0], l0, 'k'), it.ukey = ukey, it.home = home, it.ts = (u32)(ts - CWS), it.camp = (u32)camp;
        if (++n == BATCH) flush();
    }
};

// ---------------------------------------------------------------- sorting
static const int RB = 11;
template <class R>
static R* radix_sort(R* a, R* b, size_t n, int lo, int hi) {
    if (n < 2) return a;
    if (n < 96) {
        std::sort(a, a + n, [](const R& x, const R& y) { return *(const u64*)&x < *(const u64*)&y; });
        return a;
    }
    int np = (hi - lo + RB - 1) / RB;
    if (np > 6) np = 6;
    static thread_local u32 hist[6][1 << RB];
    memset(hist, 0, sizeof(u32) * (size_t)np * (1 << RB));
    const u64 DM = (1 << RB) - 1;
    if (likely(np == 4)) {
        // Events and clicks both sort on 37 to 44 bits, so four passes is the usual case. Written
        // out, the count takes half the instructions of the loop over the passes below.
        u32 *h0 = hist[0], *h1 = hist[1], *h2 = hist[2], *h3 = hist[3];
        for (size_t i = 0; i < n; i++) {
            const u64 k = *(const u64*)&a[i] >> lo;
            h0[k & DM]++, h1[(k >> RB) & DM]++, h2[(k >> (2 * RB)) & DM]++, h3[(k >> (3 * RB)) & DM]++;
        }
    } else {
        for (size_t i = 0; i < n; i++) {
            u64 k = *(const u64*)&a[i] >> lo;
            for (int p = 0; p < np; p++) hist[p][(k >> (p * RB)) & DM]++;
        }
    }
    for (int p = 0; p < np; p++) {
        u32* h = hist[p];
        int sh = lo + p * RB;
        if (h[(*(const u64*)&a[0] >> sh) & ((1 << RB) - 1)] == n) continue;
        u32 sum = 0;
        for (int d = 0; d < (1 << RB); d++) {
            u32 c = h[d];
            h[d] = sum;
            sum += c;
        }
        for (size_t i = 0; i < n; i++) {
            u64 k = *(const u64*)&a[i];
            b[h[(k >> sh) & ((1 << RB) - 1)]++] = a[i];
        }
        std::swap(a, b);
    }
    return a;
}

// A session needs its events grouped, not ordered. Slots of 2^20 ms (17.5 minutes) are
// shorter than the 30-minute gap, so the events of one slot always share a session, and
// only the step from one slot's latest event to the next slot's earliest can end one.
// Sorting by (person, slot) takes two passes of 12 bits where (person, ms) took four of 11.
// Measured on x86: the sort gets 43% cheaper and the walk over unsorted slots pays it
// all back, so the events are sorted by millisecond unless SS_SLOTSORT is set.
static bool FULLSORT = true;
static const int SLOTB = 20;
static u64* sort_slots(u64* a, u64* b, size_t n) {
    if (n < 2) return a;
    if (n < 96) {
        std::sort(a, a + n, [](u64 x, u64 y) { return (x >> SLOTB) < (y >> SLOTB); });
        return a;
    }
    static thread_local u32 h0[4096], h1[4096];
    memset(h0, 0, sizeof h0), memset(h1, 0, sizeof h1);
    for (size_t i = 0; i < n; i++) {
        u64 k = a[i] >> SLOTB;
        h0[k & 4095]++, h1[(k >> 12) & 4095]++;
    }
    u32 s0 = 0, s1 = 0;
    for (int d = 0; d < 4096; d++) {
        u32 c0 = h0[d], c1 = h1[d];
        h0[d] = s0, h1[d] = s1;
        s0 += c0, s1 += c1;
    }
    for (size_t i = 0; i < n; i++) {
        u64 k = a[i];
        b[h0[(k >> SLOTB) & 4095]++] = k;
    }
    for (size_t i = 0; i < n; i++) {
        u64 k = b[i];
        a[h1[(k >> (SLOTB + 12)) & 4095]++] = k;
    }
    return a;
}

// ---------------------------------------------------------------- phases
static Lists L_EREC, L_DENSE, L_MAIN, L_PURCH, L_CLICK;

static inline void decode_aux(u32 aux, u32& price, u32& cat) {
    if (likely(!WIDE_CAT)) {
        price = aux >> 8, cat = aux & 255;
    } else {
        u64 v = TC[aux >> 27]->wide[(aux & ((1u << 27) - 1)) - 1];
        price = (u32)v, cat = (u32)(v >> 32);
    }
}

static void dedup_partition(TCtx& t, u32 part) {
    u32 c0 = L_EREC.start[part], c1 = L_EREC.start[part + 1];
    if (c0 == c1) return;
    const u32* ids = L_EREC.ids.data() + c0;
    u32 nch = c1 - c0;
    size_t n = 0;
    for (u32 i = 0; i < nch; i++) n += META[ids[i]].fill / sizeof(ERec);
    size_t S = 1024;
    while (S < 2 * n) S <<= 1;
    u64* tab;
    if (S <= t.dtab_cap) {
        tab = t.dtab_hot;
    } else {
        if (t.dtab.size() < S) t.dtab.resize(S);
        tab = t.dtab.data();
    }
    // One 8-byte entry a slot: 32 bits of a second hash of the event's key above the
    // reference to its record plus one (0 = empty). A slot is one cache line where the
    // key and the reference in two arrays were two, and the table takes 2/3 of the room.
    // Equal hashes are checked against the record's own key, so a collision costs a read.
    memset(tab, 0, S * 8);
    size_t mask = S - 1;
    const int dshift = 64 - __builtin_ctzll((u64)S);
    auto rec = [&](u32 ref) -> ERec* { return (ERec*)(ARENA + (size_t)ids[ref >> 10] * CHUNK) + (ref & 1023); };
    u64 tk0 = VERBOSE ? ticks() : 0;
    for (u32 i = 0; i < nch; i++) {
        ERec* r = (ERec*)(ARENA + (size_t)ids[i] * CHUNK);
        u32 cnt = META[ids[i]].fill / sizeof(ERec);
        // The records come from memory, and the next chunk is elsewhere in the arena, where
        // the hardware prefetcher does not follow: it is fetched one record's width at a time.
        const u8* nx = ARENA + (size_t)ids[i + 1 < nch ? i + 1 : i] * CHUNK;
        for (u32 j = 0; j < cnt; j++) {
            _mm_prefetch((const char*)nx + j * sizeof(ERec), _MM_HINT_T0);
            u64 k = r[j].ekey;
            size_t s = (size_t)((hash1(k) << PEB) >> dshift);  // the bits below the ones that chose the partition
            const u32 f = (u32)((k * 0xD6E8FEB86659FD93ULL) >> 32);
            const u64 e = ((u64)f << 32) | (((u64)i << 10) | j) + 1;
            {
                // Nearly every event is new and lands in its home slot or the next one. Which
                // of the two is a coin toss, so both are looked at before the one branch that
                // is almost always taken, and the slot is picked without a branch.
                const size_t s1 = (s + 1) & mask;
                const u64 x0 = tab[s], x1 = tab[s1];
                if (likely(((u32)(x0 >> 32) != f) & ((u32)(x1 >> 32) != f) & ((x0 == 0) | (x1 == 0)))) {
                    const size_t at = s1 ^ ((s ^ s1) & (0 - (size_t)(x0 == 0)));  // s when it is free
                    tab[at] = e;
                    continue;
                }
            }
            for (;;) {
                u64 x = tab[s];
                if (x == 0) {
                    tab[s] = e;
                    break;
                }
                if ((u32)(x >> 32) == f) {
                    ERec* old = rec((u32)x - 1);
                    if (old->ekey == k) {
                        if (r[j].ingest < old->ingest) old->person = DEAD, tab[s] = e;
                        else r[j].person = (r[j].person == INVALID ? INVALID : DEAD);
                        break;
                    }
                }
                s = (s + 1) & mask;
            }
        }
    }
    u32 lmask = (1u << LW) - 1;
    (void)lmask;
    u64 tk1 = VERBOSE ? ticks() : 0;
    for (u32 i = 0; i < nch; i++) {
        ERec* r = (ERec*)(ARENA + (size_t)ids[i] * CHUNK);
        u32 cnt = META[ids[i]].fill / sizeof(ERec);
        const u8* nx = ARENA + (size_t)ids[i + 1 < nch ? i + 1 : i] * CHUNK;  // a 1 MB L2 no longer holds them
        for (u32 j = 0; j < cnt; j++) {
            _mm_prefetch((const char*)nx + j * sizeof(ERec), _MM_HINT_T0);
            u32 person = r[j].person;
            if (person >= DEAD) continue;
            u32 b = person >> LW;
            u64 key = ((u64)person << 31) | r[j].ts;
            *(u64*)t.sm.slot(b) = key;
            t.sm.commit(b);
            if (unlikely(r[j].aux)) {
                Purch* pu = (Purch*)t.sp.slot(b);
                pu->key = key, pu->aux = r[j].aux, pu->pad = 0;
                t.sp.commit(b);
            }
            t.n_surv++;
        }
    }
    for (u32 i = 0; i < nch; i++) {
        META[ids[i]].stream = ST_FREE, META[ids[i]].fill = 0;
        t.freelist.push_back(ids[i]);
    }
    if (VERBOSE) t.tk[0] += tk1 - tk0, t.tk[1] += ticks() - tk1;
}

// One dense partition: its numbers index a table of 2^DLSH references (128 KB at DLSH 15)
// directly, with no hash, no probing and no key to compare. Same rule as above: the copy
// with the smallest ingest wins, and the first one read when they tie (ties are identical).
static bool NORDER = true;  // SS_NONORDER: the winners in the order they were read
static bool NKEYS = true;   // SS_NOKEYS: NORDER reads each winner's record for its key
static void dedup_dense(TCtx& t, u32 part) {
    const u32 c0 = L_DENSE.start[part], c1 = L_DENSE.start[part + 1];
    if (c0 == c1) return;
    const u32* ids = L_DENSE.ids.data() + c0;
    const u32 nch = c1 - c0;
    static_assert(CHUNK / sizeof(DRec) <= 256, "a reference holds 8 bits of record index");
    u32* tab = t.dt;
    memset(tab, 0, sizeof(u32) << DLSH);
    const u32 lmask = (1u << DLSH) - 1;
    auto rec = [&](u32 ref) -> DRec* { return (DRec*)(ARENA + (size_t)ids[ref >> 8] * CHUNK) + (ref & 255); };
    u64 tk0 = VERBOSE ? ticks() : 0, rows = 0;
    // NORDER with the keys kept beside the table: a winner's kind is in the reference's top
    // two bits and its key in dk, so the number-order pass reads both in order and goes back
    // to the record only for a purchase's price.
    const bool keyed = NORDER && NKEYS && nch < (1u << 22);
    static const u32 RMASK = (1u << 30) - 1;
    if (keyed && t.dkey.size() < (1u << DLSH)) t.dkey.resize(1u << DLSH);
    u64* dk = t.dkey.data();
    if (keyed)
    for (u32 i = 0; i < nch; i++) {
        const DRec* r = (const DRec*)(ARENA + (size_t)ids[i] * CHUNK);
        const u32 cnt = META[ids[i]].fill / sizeof(DRec);
        const u8* nx = ARENA + (size_t)ids[i + 1 < nch ? i + 1 : i] * CHUNK;
        for (u32 j = 0; j < cnt; j++) {
            _mm_prefetch((const char*)nx + j * sizeof(DRec), _MM_HINT_T0);
            const u64 w0 = r[j].w0;
            const u32 kind = (u32)(w0 >> 30) & 3;
            if (unlikely(!kind)) continue;  // padding or a purchase's price
            rows++;
            const u32 l = (u32)w0 & lmask, ref = (i << 8 | j) | kind << 30;  // never 0: kind > 0
            const u32 x = tab[l];
            if (likely(!x)) {
                tab[l] = ref, dk[l] = r[j].w1;
                continue;
            }
            if ((w0 >> 32) < (rec(x & RMASK)->w0 >> 32)) tab[l] = ref, dk[l] = r[j].w1;
        }
    }
    else
    for (u32 i = 0; i < nch; i++) {
        DRec* r = (DRec*)(ARENA + (size_t)ids[i] * CHUNK);
        const u32 cnt = META[ids[i]].fill / sizeof(DRec);
        const u8* nx = ARENA + (size_t)ids[i + 1 < nch ? i + 1 : i] * CHUNK;
        for (u32 j = 0; j < cnt; j++) {
            _mm_prefetch((const char*)nx + j * sizeof(DRec), _MM_HINT_T0);
            const u64 w0 = r[j].w0;
            if (unlikely(!(w0 & DK_MASK))) continue;  // padding or a purchase's price
            rows++;
            const u32 l = (u32)w0 & lmask, ref = ((i << 8) | j) + 1;
            const u32 x = tab[l];
            if (likely(!x)) {
                tab[l] = ref;
                continue;
            }
            DRec* old = rec(x - 1);
            if ((w0 >> 32) < (old->w0 >> 32)) old->w0 &= ~DK_MASK, tab[l] = ref;
            else r[j].w0 = w0 & ~DK_MASK;
        }
    }
    t.n_dense += rows;
    u64 tk1 = VERBOSE ? ticks() : 0;
    if (keyed) {
        const u32 nl = 1u << DLSH;
        for (u32 l = 0; l < nl; l++) {
            const u32 x = tab[l];
            if (x < ((u32)DK_PLAIN << 30)) continue;  // no copy, or the winner is invalid
            const u64 key = dk[l];
            const u32 b = (u32)(key >> (31 + LW));
            *(u64*)t.sm.slot(b) = key;
            t.sm.commit(b);
            if (unlikely(x >= ((u32)DK_PURCHASE << 30))) {
                Purch* pu = (Purch*)t.sp.slot(b);
                pu->key = key, pu->aux = (u32)rec(x & RMASK)[1].w1, pu->pad = 0;
                t.sp.commit(b);
            }
            t.n_surv++;
        }
    } else if (NORDER) {
        // The winners in number order: one person's events have consecutive numbers in time
        // order, so each person's run reaches its bucket already sorted (group_persons).
        const u32 nl = 1u << DLSH;
        for (u32 l = 0; l < nl; l++) {
            const u32 x = tab[l];
            if (l + 16 < nl && tab[l + 16]) _mm_prefetch((const char*)rec(tab[l + 16] - 1), _MM_HINT_T0);
            if (!x) continue;
            const DRec* r = rec(x - 1);
            const u32 kind = (u32)(r->w0 >> 30) & 3;
            if (kind < DK_PLAIN) continue;
            const u64 key = r->w1;
            const u32 b = (u32)(key >> (31 + LW));
            *(u64*)t.sm.slot(b) = key;
            t.sm.commit(b);
            if (unlikely(kind == DK_PURCHASE)) {
                Purch* pu = (Purch*)t.sp.slot(b);
                pu->key = key, pu->aux = (u32)r[1].w1, pu->pad = 0;
                t.sp.commit(b);
            }
            t.n_surv++;
        }
    } else
    for (u32 i = 0; i < nch; i++) {
        const DRec* r = (const DRec*)(ARENA + (size_t)ids[i] * CHUNK);
        const u32 cnt = META[ids[i]].fill / sizeof(DRec);
        const u8* nx = ARENA + (size_t)ids[i + 1 < nch ? i + 1 : i] * CHUNK;
        for (u32 j = 0; j < cnt; j++) {
            _mm_prefetch((const char*)nx + j * sizeof(DRec), _MM_HINT_T0);
            const u32 kind = (u32)(r[j].w0 >> 30) & 3;
            if (kind < DK_PLAIN) continue;  // padding, a price, invalid, or a copy that lost
            const u64 key = r[j].w1;
            const u32 b = (u32)(key >> (31 + LW));
            *(u64*)t.sm.slot(b) = key;
            t.sm.commit(b);
            if (unlikely(kind == DK_PURCHASE)) {
                Purch* pu = (Purch*)t.sp.slot(b);
                pu->key = key, pu->aux = (u32)r[j + 1].w1, pu->pad = 0;
                t.sp.commit(b);
            }
            t.n_surv++;
        }
    }
    for (u32 i = 0; i < nch; i++) {
        META[ids[i]].stream = ST_FREE, META[ids[i]].fill = 0;
        t.freelist.push_back(ids[i]);
    }
    if (VERBOSE) t.tk[0] += tk1 - tk0, t.tk[1] += ticks() - tk1;
}

template <class R>
static size_t gather(const Lists& L, u32 b, std::vector<R>& out) {
    u32 c0 = L.start[b], c1 = L.start[b + 1];
    size_t bytes = 0;
    for (u32 i = c0; i < c1; i++) bytes += META[L.ids[i]].fill;
    size_t n = bytes / sizeof(R);
    if (out.size() < n) out.resize(n + n / 4 + 64);
    u8* o = (u8*)out.data();
    for (u32 i = c0; i < c1; i++) {
        u32 f = META[L.ids[i]].fill;
        memcpy(o, ARENA + (size_t)L.ids[i] * CHUNK, f);
        o += f;
    }
    return n;
}

// A bucket's events in (person, ts) order without a full sort. The bucket's chunks are read
// in the order each thread wrote them, so a person's events come in runs: one pass finds the
// runs and whether each is in order, a counting pass by person places them, and only a person
// with two runs or a run out of order is sorted, by insertion or, when long, by radix. The order
// is exact for any input; it is cheap when the dense dedup emits each person's events in time
// order (NORDER), as the generator numbers them.
static bool PERSONSORT = true;  // SS_RADIXSORT: the gather and the 4-pass radix sort instead
static bool CHUNKIDORDER = false;  // SS_CHUNKIDORDER: chunks in id order, not write order
static const size_t RUN_RADIX = 192;
static size_t group_persons(TCtx& t, u32 b) {
    const u32 nc = L_MAIN.start[b + 1] - L_MAIN.start[b];
    if (t.cord.size() < nc) t.cord.resize(nc + 64);
    u32* ids = t.cord.data();
    memcpy(ids, L_MAIN.ids.data() + L_MAIN.start[b], sizeof(u32) * nc);
    if (!CHUNKIDORDER)
        for (u32 i = 1; i < nc; i++) {
            const u32 x = ids[i], q = META[x].seq;
            u32 j = i;
            for (; j > 0 && META[ids[j - 1]].seq > q; j--) ids[j] = ids[j - 1];
            ids[j] = x;
        }
    size_t n = 0;
    for (u32 i = 0; i < nc; i++) n += META[ids[i]].fill / sizeof(u64);
    if (!n) return 0;
    if (t.A.size() < n) t.A.resize(n + n / 4 + 64);
    const u32 np = 1u << LW, lmask = np - 1;
    if (t.pend.size() < np) t.pend.resize(np), t.pfix.resize(np);
    u32* pos = t.pend.data();
    u8* fix = t.pfix.data();
    memset(pos, 0, sizeof(u32) * np);
    t.segs.clear();
    t.fixl.clear();
    for (u32 i = 0; i < nc; i++) {
        const u64* r = (const u64*)(ARENA + (size_t)ids[i] * CHUNK);
        const u32 m = META[ids[i]].fill / sizeof(u64);
        u32 j = 0;
        while (j < m) {
            const u64 k0 = r[j], who = k0 >> 31;
            u64 prev = k0;
            bool desc = false;
            u32 e = j + 1;
            for (; e < m; e++) {
                const u64 k = r[e];
                if ((k >> 31) != who) break;
                desc |= k < prev;
                prev = k;
            }
            const u32 p = (u32)who & lmask;
            if ((pos[p] || desc) && !fix[p]) fix[p] = 1, t.fixl.push_back(p);
            pos[p] += e - j;
            t.segs.push_back({r + j, e - j, p});
            j = e;
        }
    }
    u32 sum = 0;
    for (u32 p = 0; p < np; p++) {
        const u32 c = pos[p];
        pos[p] = sum;
        sum += c;
    }
    u64* A = t.A.data();
    for (const Seg& g : t.segs) {
        u64* o = A + pos[g.who];
        for (u32 j = 0; j < g.len; j++) o[j] = g.p[j];
        pos[g.who] += g.len;
    }
    u64 tk = VERBOSE ? ticks() : 0;
    for (u32 p : t.fixl) {
        fix[p] = 0;
        const u32 s = p ? pos[p - 1] : 0, e = pos[p];
        u64* a = A + s;
        const size_t len = e - s;
        size_t i = 1;
        while (i < len && a[i - 1] <= a[i]) i++;
        if (i == len) continue;
        if (len >= RUN_RADIX) {
            if (t.B.size() < len) t.B.resize(len + len / 4 + 64);
            const u64* o = radix_sort<u64>(a, t.B.data(), len, 0, 31);
            if (o != a) memcpy(a, o, len * sizeof(u64));
        } else {
            for (; i < len; i++) {
                const u64 x = a[i];
                size_t j = i;
                for (; j > 0 && a[j - 1] > x; j--) a[j] = a[j - 1];
                a[j] = x;
            }
        }
    }
    if (VERBOSE) t.tk[3] += ticks() - tk, t.tk[2] -= ticks() - tk;
    return n;
}

static void process_bucket(TCtx& t, u32 b) {
    u64 tk0 = VERBOSE ? ticks() : 0;
    const bool slots = !FULLSORT && 31 + (int)LW <= SLOTB + 24;
    const bool grouped = PERSONSORT && !slots;
    size_t n = grouped ? group_persons(t, b) : gather(L_MAIN, b, t.A);
    if (!n) return;
    u64 tk1 = VERBOSE ? ticks() : 0;
    const u64* K;
    if (grouped) {
        K = t.A.data();
    } else {
        if (t.B.size() < t.A.size()) t.B.resize(t.A.size());
        K = slots ? sort_slots(t.A.data(), t.B.data(), n) : radix_sort<u64>(t.A.data(), t.B.data(), n, 0, 31 + (int)LW);
    }
    u64 tk2 = VERBOSE ? ticks() : 0;

    size_t m = gather(L_PURCH, b, t.PV);
    Purch* PR = t.PV.data();
    if (m > 1) std::sort(PR, PR + m, [](const Purch& x, const Purch& y) { return x.key < y.key; });

    u64 tk3 = VERBOSE ? ticks() : 0;
    size_t c = gather(L_CLICK, b, t.CA);
    if (t.CB2.size() < t.CA.size()) t.CB2.resize(t.CA.size());
    const Click* C = radix_sort<Click>(t.CA.data(), t.CB2.data(), c, (int)CBITS, (int)(CBITS + 31 + LW));

    const u32 lmask = (1u << LW) - 1, cmask = (1u << CBITS) - 1;
    const int csh = 31 + (int)CBITS;
    const u32 ncampx = NCAMP + 1;
    CampAcc* cd = t.cd.data();
    u32* assist = t.assist.data();
    u32* wcnt = t.wcnt.data();
    u32* wpos = t.wpos.data();
    u32* wact = t.wact.data();
    i64* catsum = t.catsum.data();
    auto cts = [&](size_t i) -> u32 { return (u32)(C[i].key >> CBITS) & 0x7FFFFFFFu; };
    auto ccamp = [&](size_t i) -> u32 { return (u32)C[i].key & cmask; };

    u64 tk4 = VERBOSE ? ticks() : 0;
    size_t i = 0, ip = 0, ic = 0;
    while (i < n) {
        const u32 person = (u32)(K[i] >> 31);
        const u64 local = person & lmask;
        while (ic < c && (C[ic].key >> csh) < local) ic++;
        size_t lo = ic, hi = ic;
        while (ic < c && (C[ic].key >> csh) == local) ic++;
        const size_t cend = ic;
        u32 nact = 0;

        i64 cur_day = INT64_MIN;
        u32 d_sessions = 0, d_events = 0;
        i64 d_rev = 0;
        u32 ntouched = 0;
        auto flush_day = [&]() {
            i32 top = -1;
            if (ntouched) {
                u32 best = t.cattouched[0];
                for (u32 q = 1; q < ntouched; q++) {
                    u32 x = t.cattouched[q];
                    if (catsum[x] > catsum[best] || (catsum[x] == catsum[best] && CAT_RANK[x] < CAT_RANK[best])) best = x;
                }
                top = (i32)best;
                for (u32 q = 0; q < ntouched; q++) catsum[t.cattouched[q]] = 0;
                ntouched = 0;
            }
            t.ud.row(TAB[person].key, (i32)cur_day, d_sessions, d_events, d_rev, top);
            d_sessions = d_events = 0, d_rev = 0;
        };

        while (i < n && (u32)(K[i] >> 31) == person) {
            u32 start = (u32)K[i] & 0x7FFFFFFFu;
            u32 prev = start, cnt = 1;
            if (likely(slots)) {
                // The session's first slot: its earliest event starts the session.
                const u64 g0 = K[i] >> SLOTB;
                i++;
                while (i < n && (K[i] >> SLOTB) == g0) {
                    u32 x = (u32)K[i] & 0x7FFFFFFFu;
                    start = std::min(start, x), prev = std::max(prev, x), cnt++, i++;
                }
                // Later slots join while their earliest event is within the gap of the latest so far.
                while (i < n && (u32)(K[i] >> 31) == person) {
                    const u64 g = K[i] >> SLOTB;
                    u32 mn = (u32)K[i] & 0x7FFFFFFFu, mx = mn;
                    size_t j = i + 1;
                    while (j < n && (K[j] >> SLOTB) == g) {
                        u32 x = (u32)K[j] & 0x7FFFFFFFu;
                        mn = std::min(mn, x), mx = std::max(mx, x), j++;
                    }
                    if (mn - prev > GAPMS) break;  // this slot opens the next session
                    cnt += (u32)(j - i), prev = mx, i = j;
                }
            } else {
                i++;
                while (i < n && (u32)(K[i] >> 31) == person) {
                    u32 x = (u32)K[i] & 0x7FFFFFFFu;
                    if (x - prev > GAPMS) break;
                    prev = x, cnt++, i++;
                }
            }
            const i64 day = DAY0 + (i64)(((u64)start + WS_OFF) / (u64)DAYMS);
            if (day != cur_day) {
                if (cur_day != INT64_MIN) flush_day();
                cur_day = day;
            }
            i64 rev = 0;
            u32 npurch = 0;
            const u64 last_key = ((u64)person << 31) | prev;
            while (ip < m && PR[ip].key <= last_key) {
                u32 price, cat;
                decode_aux(PR[ip].aux, price, cat);
                rev += price;
                if (catsum[cat] == 0) t.cattouched[ntouched++] = cat;
                catsum[cat] += price;
                npurch++, ip++;
            }
            d_sessions++, d_events += cnt, d_rev += rev;
            t.n_sessions++;

            // Clicks are kept on a clock that starts 7 days before the window.
            const u32 s_click = start + (u32)WEEKMS;
            while (hi < cend && cts(hi) <= s_click) {
                u32 a = ccamp(hi);
                if (wcnt[a]++ == 0) wpos[a] = nact, wact[nact++] = a;
                hi++;
            }
            while (lo < hi && cts(lo) < start) {
                u32 a = ccamp(lo);
                if (--wcnt[a] == 0) {
                    u32 p = wpos[a], lastc = wact[--nact];
                    wact[p] = lastc, wpos[lastc] = p;
                }
                lo++;
            }
            u32 camp = NCAMP;
            if (hi > lo) {
                size_t best = hi - 1;
                const u32 tt = cts(best);
                for (size_t q = hi - 1; q-- > lo && cts(q) == tt;)
                    if (id_less(C[q].ckey, C[best].ckey, 'k')) best = q;
                camp = ccamp(best);
            }
            CampAcc* row = cd + (size_t)(day - DAY0) * ncampx;
            row[camp].sessions++;
            row[camp].purchasing += npurch > 0;
            row[camp].revenue += rev;
            u32* arow = assist + (size_t)(day - DAY0) * ncampx;
            for (u32 q = 0; q < nact; q++) arow[wact[q]]++;
        }
        flush_day();
        for (u32 q = 0; q < nact; q++) wcnt[wact[q]] = 0;
    }
    if (VERBOSE) {
        u64 tk5 = ticks();
        t.tk[2] += tk1 - tk0, t.tk[3] += tk2 - tk1, t.tk[4] += tk3 - tk2, t.tk[5] += tk4 - tk3, t.tk[6] += tk5 - tk4;
    }
}

// ---------------------------------------------------------------- run
static std::vector<MFile> F_EVENTS, F_CLICKS, F_LINKS;
static std::thread g_products_thread;  // products.csv loads while the links are joined
static u64 B_EVENTS, B_CLICKS, B_LINKS;

// Huge pages. 0: ask where they are cheap (huge_pages_cheap below), 1: never (SS_NOHUGE),
// 2: always (SS_HUGE). The probe's benchmark sets this for each run.
static int HUGE_MODE = 0;
#ifdef SS_PROBE
static bool PROBE_CHILD = false;  // a benchmark run in its own process: it exits like the real entry
#endif
static int FORCE_PEB = 0;    // SS_PEB: log2 of the event partitions, 4 to 13
#ifndef SS_PART_ROWS
#define SS_PART_ROWS 40000  // the most events a partition may get by the estimate (see run)
#endif

// ---- huge pages, only where they are cheap
// With transparent huge pages set to "madvise", asking for them also lets the
// kernel compact memory inside the page fault. Where memory is fragmented that
// costs milliseconds for every 2 MB (measured: 4 ms each on one cloud machine,
// 0.1 ms on others), far more than huge pages save. So before asking, look at
// how much memory is free in blocks of 2 MB or more, and time a few real faults.
static bool HUGE_OK = true;
static u64 mono_ns() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}
// Bytes free in blocks of 2 MB and larger. False when the kernel does not say.
static bool free_big_bytes(u64& total) {
    FILE* f = fopen("/proc/buddyinfo", "r");
    if (!f) return false;
    char line[2048];
    bool any = false;
    total = 0;
    while (fgets(line, sizeof line, f)) {
        char* p = strstr(line, "zone");
        if (!p) continue;
        p += 4;
        while (*p == ' ') p++;
        while (*p && *p != ' ') p++;  // the zone's name
        for (int order = 0;; order++) {
            char* end;
            unsigned long long v = strtoull(p, &end, 10);
            if (end == p) break;
            if (order >= 9) total += (u64)v << (order + 12);
            p = end, any = true;
        }
    }
    fclose(f);
    return any;
}
static bool huge_pages_cheap(u64 need) {
    u64 big = 0;
    const bool known = free_big_bytes(big);
    const size_t two = 2u << 20, n = 8 * two;
    int slow = 0;
    u64 worst = 0;
    u8* p = (u8*)mmap(nullptr, n + two, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (p != MAP_FAILED) {
        u8* a = (u8*)(((uintptr_t)p + two - 1) & ~(uintptr_t)(two - 1));
#ifdef MADV_HUGEPAGE
        madvise(a, n, MADV_HUGEPAGE);
#endif
        for (int i = 0; i < 8; i++) {
            u64 t0 = mono_ns();
            *(volatile u8*)(a + (size_t)i * two) = 1;
            u64 dt = mono_ns() - t0;
            slow += dt > 1000000, worst = std::max(worst, dt);
        }
        munmap(p, n + two);
    }
    const bool ok = slow < 2 && (!known || big >= need + need / 4);
    if (VERBOSE)
        fprintf(stderr, "huge pages: %s (free in 2 MB blocks %s%llu MB, need about %llu MB, slow test faults %d of 8, worst %.2f ms)\n",
                ok ? "asked for" : "not asked for", known ? "" : "unknown ", (unsigned long long)(big >> 20),
                (unsigned long long)(need >> 20), slow, (double)worst * 1e-6);
    return ok;
}

// Reserves zeroed memory. `fallback` is a smaller size to try when the kernel
// refuses the first one (strict overcommit); 0 means there is none.
static u64 map_or_die(void** out, u64 bytes, bool huge, u64 fallback = 0) {
    bytes = (bytes + (2u << 20) - 1) & ~((u64)(2u << 20) - 1);
    void* p = mmap(nullptr, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (p == MAP_FAILED && fallback) {
        bytes = (fallback + (2u << 20) - 1) & ~((u64)(2u << 20) - 1);
        p = mmap(nullptr, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    }
    if (p == MAP_FAILED) die("cannot reserve %llu MB", (unsigned long long)(bytes >> 20));
#ifdef MADV_HUGEPAGE
    if (huge && (HUGE_MODE == 2 || (HUGE_MODE == 0 && HUGE_OK))) madvise(p, bytes, MADV_HUGEPAGE);
#endif
    *out = p;
    return bytes;
}

static void* hot_take(TCtx* t, size_t bytes) {
    bytes = (bytes + 63) & ~(size_t)63;
    if (!t->hot) {
        // Twice the size, so a 2 MB-aligned page fits whatever address the kernel picks.
        void* p = mmap(nullptr, 2 * HOT_BYTES, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
        if (p == MAP_FAILED) return nullptr;
        t->hot_map = p;
        t->hot = (u8*)(((uintptr_t)p + HOT_BYTES - 1) & ~(uintptr_t)(HOT_BYTES - 1));
#ifdef MADV_HUGEPAGE
        if (HUGE_MODE == 2 || (HUGE_MODE == 0 && HUGE_OK)) madvise(t->hot, HOT_BYTES, MADV_HUGEPAGE);
#endif
    }
    if (t->hot_used + bytes > HOT_BYTES) return nullptr;
    void* r = t->hot + t->hot_used;
    t->hot_used += bytes;
    return r;
}

// ---- the event key (see dense event numbers)
// The events are numbered from 0 to about the number of rows, so the key is the one under
// which every sampled ID has a number below R, that count with room to spare. A wrong key
// passes a sample one time in 2^40/R (over 10000 for a billion rows), so none passes 24 of
// them. The search runs over the number v of the first sample: v gives a key, and the key
// gives the second sample's number, which must be below R too. With the 40 bits held at
// the top of the word, a candidate costs one xor, one multiply and one compare.
static std::vector<u64> DS_W;  // unmix40 of the sampled IDs, distinct
static u64 DS_R = 0;           // the bound; 0: no search
static std::atomic<int> DS_FOUND{0};
static u64 DS_KEY = 0;
static double DS_MS = 0;
static std::thread g_dense_thread;
static bool DS_ON = false;  // main started the search (run reads only this before it waits)

// The most rows the event bytes could hold (lines of 24 bytes or more), with the same room.
static u64 dense_rcap() {
    const u64 r = B_EVENTS / 24 + 1;
    return r + r / 8 + 4096;
}
static void dense_try(u64 v) {
    const u64 k = (DS_W[0] ^ (v * SM1)) & M40;
    for (u64 x : DS_W)
        if ((((x ^ k) * SM1I) & M40) >= DS_R) return;
    int z = 0;
    if (DS_FOUND.compare_exchange_strong(z, 1)) DS_KEY = k;
}
static void dense_scan(u64 a, u64 b) {
    const u64 RL = DS_R << 24, d = (DS_W[0] ^ DS_W[1]) << 24, st = SM1 << 24, inv = SM1I;
    u64 y = (a * SM1) << 24;
    for (u64 v = a; v < b;) {
        if (DS_FOUND.load(std::memory_order_relaxed)) return;
        const u64 e = std::min(b, v + 65536);
        for (; v + 4 <= e; v += 4, y += 4 * st) {
            const u64 z0 = (d ^ y) * inv, z1 = (d ^ (y + st)) * inv;
            const u64 z2 = (d ^ (y + 2 * st)) * inv, z3 = (d ^ (y + 3 * st)) * inv;
            if (unlikely((z0 < RL) | (z1 < RL) | (z2 < RL) | (z3 < RL)))
                for (u64 q = 0; q < 4; q++) dense_try(v + q);
        }
        for (; v < e; v++, y += st)
            if (unlikely(((d ^ y) * inv) < RL)) dense_try(v);
    }
}
// Samples 12 lines from each of the 16 largest event files, each one the line after the one
// at an offset (the line hit at an offset is more likely a long one; the next is not), and
// sets DS_W and DS_R. Then searches for the key with `nth` threads.
static void dense_infer(int nth) {
    const u64 t0 = mono_ns();
    std::vector<const MFile*> fs;
    for (auto& f : F_EVENTS) fs.push_back(&f);
    std::sort(fs.begin(), fs.end(), [](const MFile* a, const MFile* b) { return a->size > b->size; });
    if (fs.size() > 16) fs.resize(16);
    std::vector<u64> w;
    u64 nl = 0, lsum = 0;
    alignas(64) u8 buf[512 + 64];
    for (const MFile* f : fs)
        for (u64 k = 1; k <= 12; k++) {
            const u64 at = f->size / 13 * k;
            size_t got = 0;
            if (f->p) {
                got = (size_t)std::min<u64>(512, f->size - at);
                memcpy(buf, f->p + at, got);
            } else {
                const ssize_t r = pread(f->fd, buf, 512, (off_t)at);
                if (r <= 0) continue;
                got = (size_t)r;
            }
            memset(buf + got, 0, 64);
            const u8* n0 = (const u8*)memchr(buf, '\n', got);
            if (!n0) continue;
            const u8* ls = n0 + 1;
            const u8* le = (const u8*)memchr(ls, '\n', (size_t)(buf + got - ls));
            if (!le) continue;
            nl++, lsum += (u64)(le - ls) + 1;
            const u8* fe = (const u8*)memchr(ls, ',', (size_t)(le - ls));
            if (!fe) continue;
            const u8* fb = ls;
            if (fe - fb >= 2 && fb[0] == '"' && fe[-1] == '"') fb++, fe--;
            const size_t l = (size_t)(fe - fb);
            if (l - 2 >= 8 || fb[0] != 'e') continue;
            const u64 x = base36_canon(load64(fb + 1), (u32)l - 1);
            if (x != ~0ull) w.push_back(unmix40(x));
        }
    std::sort(w.begin(), w.end());
    w.erase(std::unique(w.begin(), w.end()), w.end());  // the search needs two different samples
    if (w.size() < 24 || !lsum) return;
    const u64 rows = B_EVENTS * nl / lsum + 1;
    const u64 R = std::min(rows + rows / 8 + 4096, dense_rcap());
    if (R >= (1ull << 38)) return;
    DS_W = std::move(w), DS_R = R;
    if (nth <= 1) {
        dense_scan(0, R);
    } else {
        std::vector<std::thread> th;
        for (int i = 1; i < nth; i++) th.emplace_back(dense_scan, R * (u64)i / (u64)nth, R * (u64)(i + 1) / (u64)nth);
        dense_scan(0, R / (u64)nth);
        for (auto& x : th) x.join();
    }
    DS_MS = (double)(mono_ns() - t0) / 1e6;
}
// Waits for the search, and turns the dense path on when it found the key.
static void dense_settle() {
    if (g_dense_thread.joinable()) g_dense_thread.join();
    DLIMIT = 0;
    if (!DS_FOUND.load()) return;
    DKEY = DS_KEY;
    DLIMIT = (DS_R + (1ull << DLSH) - 1) >> DLSH << DLSH;
}

static bool run(u64 tab_slots) {
    g_overflow.store(false);
    g_tab_used.store(0);
    g_next_chunk.store(0);

    // Sizes. Every bound below is a worst case for the bytes on disk.
    u64 est_rows = B_EVENTS / 74 + 1;
    u32 cb = 1;
    while ((1ull << cb) < (u64)NCAMP + 1) cb++;
    CBITS = cb;
    if (CBITS > 26) die("too many campaigns");
    double per_slot = (double)est_rows / (double)tab_slots;
    int lw = 12;
    {
        double want = 14000.0 / std::max(per_slot, 0.001);
        lw = 0;
        while ((double)(1ull << (lw + 1)) <= want * 1.41 && lw < 13) lw++;  // nearest power of two
        if (lw < 6) lw = 6;
        if (lw > 33 - (int)CBITS) lw = 33 - (int)CBITS;
    }
    LW = (u32)lw;
    TABN = (tab_slots + (1ull << LW) - 1) >> LW << LW;
    if (TABN >= 0xFFFF0000ull) die("too many user IDs");
    PB = (u32)(TABN >> LW);
    TAB_LIMIT = TABN / 4 * 3;
    TAB_QUOTA = std::max<u64>(1, TABN / (16 * (u64)T));
    // Up to about 40,000 events a partition: each thread stages 192 bytes for every partition,
    // and with 2048 of them at 20M events (two threads a core) that crowded the scorer's 1 MB L2.
    // Half as many partitions measured 4% faster there (probe v3, 897 against 935 ms).
    // With dense numbers, only the few IDs spelled another way take the hashed partitions.
    // The key search may still run (it ends before the events are parsed), so the arena has
    // room for the open chunks of both ways.
    auto event_partitions = [&](u64 hashed_rows) {
        u32 b = 4;
        while (b < 13 && (hashed_rows >> b) > SS_PART_ROWS) b++;
        if (FORCE_PEB >= 4 && FORCE_PEB <= 13) b = (u32)FORCE_PEB;
        return b;
    };
    PEB = event_partitions(est_rows);
    const u64 PE_MAX = 1ull << PEB;
    const u64 PD_MAX = DS_ON ? (dense_rcap() + (1ull << DLSH) - 1) >> DLSH : 0;

    void* tabp;
    u64 tab_bytes = map_or_die(&tabp, TABN * sizeof(Slot), true);
    TAB = (Slot*)tabp;

    // Records per input byte, at worst: 24 bytes for an 8-byte event line, and
    // far less for the survivors and the clicks, which need valid fields.
    u64 arena_bytes = B_EVENTS * 9 / 2 + B_CLICKS * 2 + (PE_MAX + PD_MAX + 3ull * PB) * (u64)T * CHUNK + (64u << 20);
    void* arenap;
    arena_bytes = map_or_die(&arenap, arena_bytes, true,
                             B_EVENTS + B_CLICKS + (PE_MAX + PD_MAX + 3ull * PB) * (u64)T * CHUNK + (64u << 20));
    ARENA = (u8*)arenap;
    MAX_CHUNKS = (u32)std::min<u64>(arena_bytes / CHUNK, 0xFFFFFFF0u);
    void* metap;
    u64 meta_bytes = map_or_die(&metap, (u64)MAX_CHUNKS * sizeof(ChunkMeta), false);
    META = (ChunkMeta*)metap;

    if (getenv("SS_PRETOUCH")) {
        // For measuring: touch the memory first, then restart the clock, so the
        // times show the work without the cost of first-touch page faults.
#ifndef MADV_POPULATE_WRITE
#define MADV_POPULATE_WRITE 23
#endif
        madvise(tabp, tab_bytes, MADV_POPULATE_WRITE);
        madvise(arenap, std::min<u64>(arena_bytes, B_EVENTS * 3 / 2 + B_CLICKS + (256u << 20)), MADV_POPULATE_WRITE);
        T0 = now_s();
        lap("memory touched, clock restarted");
    }
    if (VERBOSE && !LAP_QUIET)
        fprintf(stderr, "threads %d, table %llu slots, %u buckets of %u, %u campaign bits\n", T, (unsigned long long)TABN, PB,
                1u << LW, CBITS);

    TC.clear();
    for (int i = 0; i < T; i++) {
        TCtx* t = new TCtx();
        t->tid = i;
        t->sc.init();
        TC.push_back(t);
    }
    auto cleanup = [&]() {
        for (auto t : TC) {
            t->se.release(), t->sd.release(), t->sk.release(), t->sm.release(), t->sp.release();
            t->sc.release();
            if (t->hot_map) munmap(t->hot_map, 2 * HOT_BYTES);
            delete t;
        }
        TC.clear();
        munmap(tabp, tab_bytes), munmap(arenap, arena_bytes), munmap(metap, meta_bytes);
    };

    // ---- links
    {
        std::vector<Work> work;
        add_work(work, F_LINKS, 2, 1 << 20);
        std::atomic<size_t> next{0};
        std::atomic<int> faulted{0};
        const bool tab_huge = HUGE_MODE == 2 || (HUGE_MODE == 0 && HUGE_OK);  // as map_or_die decided
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            if (!tab_huge) {
                // A slot is read before it is written, so each 4 KB page of the table took two
                // faults, and the second (a copy of the zero page) stopped every other thread to
                // flush its TLB: 2.3% of the CPU at 20M, and the links took 88 ms instead of 60.
                // So the threads fault the table in for writing first, a slice each. With huge
                // pages that is 45 faults at 20M, and faulting in first measured 6 ms slower.
                const u64 step = 2u << 20, per = (tab_bytes / T + step - 1) / step * step;
                const u64 a = std::min(tab_bytes, (u64)tid * per), b = std::min(tab_bytes, a + per);
                if (b > a) madvise((u8*)tabp + a, b - a, MADV_POPULATE_WRITE);
                faulted.fetch_add(1);
                while (faulted.load() < T) std::this_thread::yield();
            }
            LinkH h(t);
            for (;;) {
                size_t i = next.fetch_add(1);
                if (i >= work.size() || g_overflow.load()) break;
                const u8* buf;
                u64 len, cs, ce;
                work_view(t, work[i], buf, len, cs, ce);
                piece_populate(work[i]);
                parse_range<2, LinkH>(buf, len, cs, ce, t.sc, h);
                h.flush();
                piece_drop(work[i]);
            }
        });
        if (g_overflow.load()) return cleanup(), false;
        lap("links parsed");
        // Point every linked ID straight at its root. Only the slots a union put under another
        // have a parent, and each thread walks the ones its own unions made: at 20M that is
        // under 900K slots, where a scan of the whole table read 90 MB (about 12 ms).
        run_threads([&](int tid) {
            const std::vector<u32>& v = TC[tid]->joined;
            const size_t n = v.size();
            // Other threads walk through these slots at the same time. Old parent or new,
            // both lead to the same root; the atomic store only makes that sharing explicit.
            // The table is far larger than the cache: the slot 16 ahead is fetched early,
            // and its parent once that slot is 8 ahead.
            for (size_t i = 0; i < n; i++) {
                if (i + 16 < n) __builtin_prefetch(&TAB[v[i + 16]]);
                if (i + 8 < n) __builtin_prefetch(&TAB[__atomic_load_n(&TAB[v[i + 8]].parent, __ATOMIC_RELAXED) - 1]);
                const u32 x = v[i];
                __atomic_store_n(&TAB[x].parent, uf_find_ro(x) + 1, __ATOMIC_RELAXED);
            }
        });
    }
    lap("links joined");

    // ---- events and clicks
    if (g_products_thread.joinable()) g_products_thread.join();
    dense_settle();
    PD = (u32)(DLIMIT >> DLSH);
    if (PD) PEB = event_partitions(est_rows / 32);
    const u32 PE = 1u << PEB;
    if (VERBOSE && !LAP_QUIET) {
        if (DLIMIT)
            fprintf(stderr, "event key %010llx below %llu (search %.2f ms, %zu samples): %u dense partitions of %u, %u hashed\n",
                    (unsigned long long)DKEY, (unsigned long long)DLIMIT, DS_MS, DS_W.size(), PD, 1u << DLSH, PE);
        else
            fprintf(stderr, "no event key (%zu samples, bound %llu): %u event partitions\n", DS_W.size(),
                    (unsigned long long)DS_R, PE);
    }
    {
        std::vector<Work> work;
        add_work(work, F_EVENTS, 0, 4 << 20);
        add_work(work, F_CLICKS, 1, 4 << 20);
        std::atomic<size_t> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            t.se.init(PE, ST_EREC, &t);
            if (PD) t.sd.init(PD, ST_DENSE, &t);
            t.sk.init(PB, ST_CLICK, &t);
            EventH eh(t);
            ClickH ch(t);
            for (;;) {
                size_t i = next.fetch_add(1);
                if (i >= work.size() || g_overflow.load()) break;
                const Work& w = work[i];
                const u8* buf;
                u64 len, cs, ce;
                work_view(t, w, buf, len, cs, ce);
                piece_populate(w);
                if (w.kind == 0) {
                    parse_range<7, EventH>(buf, len, cs, ce, t.sc, eh);
                    eh.flush();
                } else {
                    parse_range<4, ClickH>(buf, len, cs, ce, t.sc, ch);
                    ch.flush();
                }
                piece_drop(w);
            }
            t.se.finish();
            if (PD) t.sd.finish();
            t.sk.finish();
        });
        if (g_overflow.load()) return cleanup(), false;
    }
    lap("events and clicks parsed");

    // ---- dedup, then scatter the survivors by person
    {
        L_EREC = build_lists(ST_EREC, PE);
        if (PD) L_DENSE = build_lists(ST_DENSE, PD);
        std::atomic<u32> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            t.hot_used = 0;  // the parse is done with its staging
            t.sm.init(PB, ST_MAIN, &t);
            t.sp.init(PB, ST_PURCH, &t);
            if (PD && !(t.dt = (u32*)hot_take(&t, sizeof(u32) << DLSH))) {
                t.dtv.resize((size_t)1 << DLSH);
                t.dt = t.dtv.data();
            }
            t.dtab_cap = (HOT_BYTES - std::min(HOT_BYTES, t.hot_used)) / 8;
            t.dtab_hot = (u64*)hot_take(&t, t.dtab_cap * 8);
            if (!t.dtab_hot) t.dtab_cap = 0;
            for (;;) {
                u32 p = next.fetch_add(1);
                if (p >= PD + PE) break;
                if (p < PD) dedup_dense(t, p);
                else dedup_partition(t, p - PD);
            }
            t.sm.finish();
            t.sp.finish();
        });
    }
    lap("events deduplicated");

    // ---- sessions, attribution, user_daily
    {
        L_MAIN = build_lists(ST_MAIN, PB);
        L_PURCH = build_lists(ST_PURCH, PB);
        L_CLICK = build_lists(ST_CLICK, PB);
        std::vector<u32> order(PB);
        for (u32 b = 0; b < PB; b++) order[b] = b;
        std::sort(order.begin(), order.end(), [](u32 a, u32 b) { return L_MAIN.count(a) > L_MAIN.count(b); });
        std::atomic<u32> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            t.cd.assign((size_t)NDAYS * (NCAMP + 1), CampAcc{0, 0, 0});
            t.assist.assign((size_t)NDAYS * (NCAMP + 1), 0);
            t.wcnt.assign(NCAMP + 1, 0), t.wpos.assign(NCAMP + 1, 0), t.wact.assign(NCAMP + 1, 0);
            t.catsum.assign(NCAT + 1, 0), t.cattouched.assign(NCAT + 1, 0);
            t.ud.init(tid);
            for (;;) {
                u32 k = next.fetch_add(1);
                if (k >= PB) break;
                if (!L_MAIN.count(order[k])) break;
                process_bucket(t, order[k]);
            }
            t.ud.close();
        });
    }
    lap("sessions done, user_daily written");

    // ---- campaign_daily
    {
        size_t cells = (size_t)NDAYS * (NCAMP + 1);
        std::vector<CampAcc>& acc = TC[0]->cd;
        std::vector<u32>& assisted = TC[0]->assist;
        for (int i = 1; i < T; i++) {
            const CampAcc* o = TC[i]->cd.data();
            const u32* oa = TC[i]->assist.data();
            for (size_t k = 0; k < cells; k++) {
                acc[k].sessions += o[k].sessions, acc[k].purchasing += o[k].purchasing;
                acc[k].revenue += o[k].revenue, assisted[k] += oa[k];
            }
        }
        Buf cid, chan, day, ses, pur, rev, ast;
        u64 rows = 0;
        for (u32 d = 0; d < NDAYS; d++) {
            for (u32 c = 0; c <= NCAMP; c++) {
                const CampAcc& a = acc[(size_t)d * (NCAMP + 1) + c];
                const u32 as = assisted[(size_t)d * (NCAMP + 1) + c];
                if (!a.sessions && !as) continue;
                cid.u32v((u32)CAMP_NAME[c].size()), cid.put(CAMP_NAME[c].data(), CAMP_NAME[c].size());
                chan.u32v((u32)CAMP_CHANNEL[c].size()), chan.put(CAMP_CHANNEL[c].data(), CAMP_CHANNEL[c].size());
                day.u32v((u32)(i32)(DAY0 + d));
                ses.i64v(a.sessions), pur.i64v(a.purchasing), rev.i64v(a.revenue), ast.i64v(as);
                rows++;
            }
        }
        PqFile f;
        f.open(OUT_DIR + "/campaign_daily/part-000.parquet",
               {{"campaign_id", PQ_BYTES, 0, false}, {"channel", PQ_BYTES, 0, false}, {"day", PQ_INT32, 6, false},
                {"sessions", PQ_INT64, -1, false}, {"purchasing_sessions", PQ_INT64, -1, false},
                {"revenue_cents", PQ_INT64, -1, false}, {"assisted_sessions", PQ_INT64, -1, false}});
        if (rows) {
            PqPart parts[7] = {{cid.p, cid.n, nullptr}, {chan.p, chan.n, nullptr}, {day.p, day.n, nullptr},
                               {ses.p, ses.n, nullptr}, {pur.p, pur.n, nullptr}, {rev.p, rev.n, nullptr},
                               {ast.p, ast.n, nullptr}};
            f.row_group(rows, parts);
        }
        f.close();
        u64 ud_rows = 0;
        for (auto t : TC) ud_rows += t->ud.total;
        if (!ud_rows) {
            PqFile e;
            e.open(OUT_DIR + "/user_daily/part-000.parquet", user_daily_cols());
            e.close();
        }
        if (VERBOSE && !LAP_QUIET) {
            u64 tk[8] = {0, 0, 0, 0, 0, 0, 0, 0};
            for (auto t : TC)
                for (int k = 0; k < 8; k++) tk[k] += t->tk[k];
            fprintf(stderr,
                    "thread ms: dedup table %.0f, dedup scatter %.0f; buckets gather %.0f, sort events %.0f, purchases %.0f, "
                    "clicks %.0f, walk and write %.0f\n",
                    tk[0] * 1e-6, tk[1] * 1e-6, tk[2] * 1e-6, tk[3] * 1e-6, tk[4] * 1e-6, tk[5] * 1e-6, tk[6] * 1e-6);
            u64 r = 0, ok = 0, sv = 0, ck = 0, ss = 0, dn = 0;
            for (auto t : TC) r += t->n_rows, ok += t->n_ok, sv += t->n_surv, ck += t->n_clicks, ss += t->n_sessions, dn += t->n_dense;
            fprintf(stderr,
                    "event rows %llu (dense %llu), valid %llu, surviving %llu, clicks %llu, sessions %llu, user_daily rows %llu, "
                    "campaign_daily rows %llu, chunks %u, ids %llu+\n",
                    (unsigned long long)r, (unsigned long long)dn, (unsigned long long)ok, (unsigned long long)sv, (unsigned long long)ck,
                    (unsigned long long)ss, (unsigned long long)ud_rows, (unsigned long long)rows, g_next_chunk.load(),
                    (unsigned long long)g_tab_used.load());
        }
    }
    lap("campaign_daily written");

    // Hand the memory back from every thread at once. Left alone, the kernel
    // frees it page by page on one core while the process exits.
    if (!getenv("SS_NOFREE")) {
        const u64 two = 2u << 20;
        u64 used = std::min<u64>(arena_bytes, ((u64)g_next_chunk.load() * CHUNK + two - 1) & ~(two - 1));
        run_threads([&](int tid) {
            auto slice = [&](void* base, u64 bytes) {
                u64 per = (bytes / (u64)T) & ~(two - 1);
                u64 a = per * (u64)tid, b = tid == T - 1 ? bytes : per * (u64)(tid + 1);
                if (b > a) madvise((u8*)base + a, b - a, MADV_DONTNEED);
            };
            slice(tabp, tab_bytes);
            slice(arenap, used);
            // The per-thread buffers from malloc hold about 90 MB of small pages at
            // s2, about 10 ms of exit_mmap on one core. Only whole pages inside each
            // block go, so malloc's chunk headers stay intact.
            if (tid < (int)TC.size()) {
                auto drop = [](const void* p, u64 bytes) {
                    u64 a = ((u64)p + 4095) & ~(u64)4095, b = ((u64)p + bytes) & ~(u64)4095;
                    if (p && b > a) madvise((void*)a, b - a, MADV_DONTNEED);
                };
                auto dv = [&](auto& v) { drop(v.data(), v.capacity() * sizeof(*v.data())); };
                TCtx& t = *TC[tid];
                dv(t.dtab), dv(t.dtv), dv(t.A), dv(t.B), dv(t.wide), dv(t.PV), dv(t.CA), dv(t.CB2), dv(t.cd);
                for (Buf* b : {&t.ud.uid, &t.ud.day, &t.ud.ses, &t.ud.evs, &t.ud.rev, &t.ud.cat}) drop(b->p, b->cap);
            }
        });
        lap("memory released");
    }
#ifdef SS_PROBE
    if (!PROBE_CHILD) cleanup();  // the probe runs the pipeline many times in one process
#endif
    return true;
}

#ifdef SS_PROBE
// A probe build (-DSS_PROBE). It prints what the scoring machine looks like and
// how long each step takes there, then leaves an empty campaign table on
// purpose: the dev check fails, the scorer hands the log back, and the run can
// never be scored. Never the default build.
static void probe_cat(const char* path, const char* only = nullptr, int max_lines = 6) {
    FILE* f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "== %s: cannot open\n", path);
        return;
    }
    char line[8192];
    int n = 0;
    while (n < max_lines && fgets(line, sizeof line, f)) {
        if (only && !strstr(line, only)) continue;
        size_t len = strlen(line);
        if (len && line[len - 1] == '\n') line[len - 1] = 0;
        fprintf(stderr, "== %s: %s\n", path, line);
        n++;
    }
    fclose(f);
}
static void probe_touch(size_t mb, int threads, bool huge) {
    size_t n = mb << 20;
    char* p = (char*)mmap(nullptr, n, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (p == MAP_FAILED) return;
    if (huge) madvise(p, n, MADV_HUGEPAGE);
    double t0 = now_s();
    std::vector<std::thread> th;
    for (int i = 0; i < threads; i++)
        th.emplace_back([=] {
            for (size_t x = n / threads * i, b = n / threads * (i + 1); x < b; x += 4096) p[x] = 1;
        });
    for (auto& t : th) t.join();
    double t1 = now_s();
    long thp = -1;
    if (FILE* f = fopen("/proc/self/smaps_rollup", "r")) {
        char line[256];
        while (fgets(line, sizeof line, f))
            if (!strncmp(line, "AnonHugePages:", 14)) thp = atol(line + 14) / 1024;
        fclose(f);
    }
    double t2 = now_s();
    munmap(p, n);
    double t3 = now_s();
    fprintf(stderr, "probe touch %zu MB, %d threads, madvise huge %d: %.1f ms (%.2f us per 4K), huge now %ld MB, unmap %.1f ms\n",
            mb, threads, (int)huge, (t1 - t0) * 1e3, (t1 - t0) * 1e6 / (double)(n / 4096), thp, (t3 - t2) * 1e3);
}
static void probe_clock(int threads) {
    const u64 N = 200000000ull;
    std::vector<std::thread> th;
    std::vector<double> secs((size_t)threads);
    for (int i = 0; i < threads; i++)
        th.emplace_back([&secs, i, N] {
            double t0 = now_s();
            u64 x = (u64)i + 1;
            for (u64 k = 0; k < N; k++) x = x * 6364136223846793005ull + 1442695040888963407ull;
            secs[(size_t)i] = now_s() - t0 + (x == 42 ? 1e-12 : 0);
        });
    for (auto& t : th) t.join();
    double worst = 0, best = 1e9;
    for (double s : secs) worst = std::max(worst, s), best = std::min(best, s);
    fprintf(stderr, "probe clock, %d threads: %.2f to %.2f GHz (4-cycle multiply-add chain)\n", threads,
            (double)N * 4 / worst / 1e9, (double)N * 4 / best / 1e9);
}
static void probe_env() {
    fprintf(stderr, "==== probe: the machine ====\n");
    probe_cat("/proc/version");
    probe_cat("/proc/cpuinfo", "model name", 1);
    probe_cat("/proc/cpuinfo", "flags", 1);
    probe_cat("/proc/cpuinfo", "cpu MHz", 16);
    probe_cat("/proc/cpuinfo", "cache size", 1);
    probe_cat("/sys/devices/system/cpu/cpu0/cache/index1/size");
    probe_cat("/sys/devices/system/cpu/cpu0/cache/index2/size");
    probe_cat("/sys/devices/system/cpu/cpu0/cache/index3/size");
    probe_cat("/sys/devices/system/cpu/cpu0/topology/thread_siblings_list");
    probe_cat("/sys/devices/system/cpu/online");
    probe_cat("/proc/self/status", "Cpus_allowed_list", 1);
    fprintf(stderr, "hardware_concurrency %u, threads %d, NCPU=%s, MEM_GB=%s\n", std::thread::hardware_concurrency(), T,
            getenv("NCPU") ? getenv("NCPU") : "", getenv("MEM_GB") ? getenv("MEM_GB") : "");
    probe_cat("/sys/kernel/mm/transparent_hugepage/enabled");
    probe_cat("/sys/kernel/mm/transparent_hugepage/defrag");
    probe_cat("/sys/kernel/mm/transparent_hugepage/khugepaged/defrag");
    probe_cat("/proc/sys/vm/overcommit_memory");
    probe_cat("/proc/meminfo", nullptr, 7);
    probe_cat("/proc/meminfo", "Huge", 8);
    probe_cat("/proc/meminfo", "Dirty", 1);
    probe_cat("/sys/fs/cgroup/memory.max");
    probe_cat("/sys/fs/cgroup/memory.high");
    probe_cat("/sys/fs/cgroup/cpu.max");
    probe_cat("/sys/fs/cgroup/cpuset.cpus.effective");
    probe_cat("/sys/fs/cgroup/memory/memory.limit_in_bytes");
    probe_cat("/sys/fs/cgroup/cpu/cpu.cfs_quota_us");
    probe_cat("/proc/self/mountinfo", " /data ", 2);
    probe_cat("/proc/self/mountinfo", " /output ", 2);
    probe_cat("/proc/self/mountinfo", " /scratch ", 2);
    probe_cat("/proc/self/mountinfo", " /tmp ", 2);
    probe_cat("/proc/self/mountinfo", " / ", 2);
    probe_cat("/proc/loadavg");

    // Was the input already in the page cache when the container started?
    const MFile* big = nullptr;
    u64 files = 0, cached = 0, pages = 0;
    for (auto* v : {&F_EVENTS, &F_CLICKS, &F_LINKS})
        for (auto& f : *v) {
            if (!big || f.size > big->size) big = &f;
            if (f.fd < 0) continue;
            void* m = mmap(nullptr, f.size, PROT_READ, MAP_SHARED, f.fd, 0);
            if (m == MAP_FAILED) continue;
            size_t np = (size_t)((f.size + 4095) / 4096);
            std::vector<unsigned char> vec(np);
            if (!mincore(m, f.size, vec.data()))
                for (unsigned char c : vec) cached += c & 1;
            pages += np, files++;
            munmap(m, f.size);
        }
    fprintf(stderr, "probe input: %llu files, %llu MB, %.1f%% of pages already in the page cache\n",
            (unsigned long long)files, (unsigned long long)(pages >> 8), pages ? 100.0 * (double)cached / (double)pages : 0.0);

    // Reading speed, the way the pipeline reads: 128 KB pieces of the largest file.
    if (big && big->fd >= 0) {
        u8* buf = (u8*)aligned_alloc(4096, 128 << 10);
        for (int pass = 0; pass < 2; pass++) {
            double t0 = now_s();
            u64 got = 0, lim = std::min<u64>(big->size, 1ull << 30);
            while (got < lim) {
                ssize_t r = pread(big->fd, buf, 128 << 10, (off_t)got);
                if (r <= 0) break;
                got += (u64)r;
            }
            double dt = now_s() - t0;
            fprintf(stderr, "probe read pass %d: %llu MB in %.1f ms, %.2f GB/s on one thread\n", pass,
                    (unsigned long long)(got >> 20), dt * 1e3, (double)got / dt / 1e9);
        }
        free(buf);
    }
    probe_touch(256, 1, false);
    probe_touch(256, T, false);
    probe_touch(256, 1, true);
    probe_touch(256, T, true);
    probe_clock(1);
    probe_clock(T / 2 > 0 ? T / 2 : 1);
    probe_clock(T);
}

// ---- the probe's benchmark: the pipeline at the size of the timed runs, on the scoring machine.
// The dev set is copied many times into files that live in memory (memfd), so nothing waits on a
// disk. Every copy has the last characters of each ID rotated, so the copies are different
// people, events and clicks of the same shape.
static inline bool probe_is36(char c) { return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z'); }
static inline void probe_rot(char& c) { c = c == '9' ? 'a' : c == 'z' ? '0' : (char)(c + 1); }
static double PROBE_START;
static double probe_elapsed() { return now_s() - PROBE_START; }

struct ProbeFile {
    u64 order;  // kind, source file, copy
    int fd;
    u64 size;
    int kind;  // 0 events, 1 clicks, 2 links
};
static std::vector<ProbeFile> PROBE_FILES;
static std::mutex PROBE_MU;
static std::vector<std::string> PROBE_BEST;  // the best run of each setting, printed again as the log's last lines

// Adds copies [from, to) of every CSV file of the dataset in src. Returns the bytes added.
static u64 probe_replicate(const std::string& src, int from, int to, int threads) {
    struct Job {
        std::string in;
        int kind;
    };
    std::vector<Job> jobs;
    const char* kinds[3] = {"events", "clicks", "links"};
    for (int kind = 0; kind < 3; kind++) {
        std::string dir = src + "/" + kinds[kind];
        std::vector<std::string> names;
        if (DIR* d = opendir(dir.c_str())) {
            while (dirent* e = readdir(d)) {
                std::string n = e->d_name;
                if (n.size() > 4 && n.compare(n.size() - 4, 4, ".csv") == 0) names.push_back(n);
            }
            closedir(d);
        }
        std::sort(names.begin(), names.end());
        for (auto& n : names) jobs.push_back({dir + "/" + n, kind});
    }
    std::atomic<size_t> next{0};
    std::atomic<u64> bytes{0};
    std::vector<std::thread> th;
    for (int w = 0; w < threads; w++)
        th.emplace_back([&] {
            for (;;) {
                size_t j = next.fetch_add(1);
                if (j >= jobs.size()) break;
                std::string s = read_small(jobs[j].in);
                std::vector<u32> last, prev;  // the characters to rotate: the end of fields 0 and 1
                size_t pos = s.find('\n');
                pos = pos == std::string::npos ? s.size() : pos + 1;  // the header stays as it is
                while (pos < s.size()) {
                    size_t le = s.find('\n', pos);
                    if (le == std::string::npos) le = s.size();
                    size_t fs = pos;
                    for (int k = 0; k < 2 && fs <= le; k++) {
                        const char* c = (const char*)memchr(s.data() + fs, ',', le - fs);
                        size_t fe = c ? (size_t)(c - s.data()) : le;
                        size_t a = fs, b = fe;
                        if (b - a >= 2 && s[a] == '"' && s[b - 1] == '"') a++, b--;
                        if (b > a + 1 && probe_is36(s[b - 1])) {
                            last.push_back((u32)(b - 1));
                            if (b > a + 2 && probe_is36(s[b - 2])) prev.push_back((u32)(b - 2));
                        }
                        fs = fe + 1;
                    }
                    pos = le + 1;
                }
                for (int c = 0; c < to; c++) {
                    if (c) {
                        for (u32 at : last) probe_rot(s[at]);
                        if (c % 36 == 0)
                            for (u32 at : prev) probe_rot(s[at]);
                    }
                    if (c < from || s.empty()) continue;
                    int fd = memfd_create("ssb", MFD_CLOEXEC);
                    if (fd < 0) return;
                    size_t done = 0;
                    while (done < s.size()) {
                        ssize_t r = write(fd, s.data() + done, s.size() - done);
                        if (r <= 0) break;
                        done += (size_t)r;
                    }
                    if (done != s.size()) {
                        close(fd);
                        return;
                    }
                    bytes += done;
                    std::lock_guard<std::mutex> g(PROBE_MU);
                    PROBE_FILES.push_back({((u64)jobs[j].kind << 40) | ((u64)j << 16) | (u64)c, fd, (u64)s.size(), jobs[j].kind});
                }
            }
        });
    for (auto& t : th) t.join();
    std::sort(PROBE_FILES.begin(), PROBE_FILES.end(), [](const ProbeFile& a, const ProbeFile& b) { return a.order < b.order; });
    return bytes.load();
}

static void probe_close_inputs(bool close_fds) {
    for (auto* v : {&F_EVENTS, &F_CLICKS, &F_LINKS}) {
        for (auto& f : *v) {
            if (f.fd >= 0 && close_fds) close(f.fd);
            if (f.p) munmap((void*)f.p, ((f.size + 4095) & ~4095ULL) + PADB);
        }
        v->clear();
    }
    B_EVENTS = B_CLICKS = B_LINKS = 0;
}
// Points the pipeline at the benchmark's files, read in pieces or mapped.
static void probe_use_copies(bool map) {
    probe_close_inputs(false);
    USE_MMAP = map, MMAP_MODE = map ? 2 : 0;
    for (auto& pf : PROBE_FILES) {
        MFile m;
        m.size = pf.size;
        if (!map) {
            m.fd = pf.fd;
        } else {
            u64 rounded = (m.size + 4095) & ~4095ULL;
            u8* r = (u8*)mmap(nullptr, rounded + PADB, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
            if (r == MAP_FAILED || mmap(r, m.size, PROT_READ, MAP_PRIVATE | MAP_FIXED, pf.fd, 0) == MAP_FAILED)
                die("cannot map a benchmark file");
            m.p = r;
        }
        (pf.kind == 0 ? F_EVENTS : pf.kind == 1 ? F_CLICKS : F_LINKS).push_back(m);
        (pf.kind == 0 ? B_EVENTS : pf.kind == 1 ? B_CLICKS : B_LINKS) += m.size;
    }
}
// Back to the real dataset.
static void probe_use_data(const std::string& dir) {
    probe_close_inputs(false);
    for (auto& pf : PROBE_FILES) close(pf.fd);
    PROBE_FILES.clear();
    USE_MMAP = false, MMAP_MODE = 0;
    F_EVENTS = map_dir(dir + "/events", B_EVENTS);
    F_CLICKS = map_dir(dir + "/clicks", B_CLICKS);
    F_LINKS = map_dir(dir + "/links", B_LINKS);
}

struct ProbeCfg {
    const char* name;
    bool half;  // half the threads
    int io;     // -1 read or mapped as the startup copy test chose, 0 read, 1 mapped
    int huge;   // HUGE_MODE: 0 where the startup test finds them cheap, 1 never, 2 always
    int peb;    // added to the default number of partition bits
    int stage;  // SS_STAGE: stop the parse early (1 scan, 2 split, 3 fields, 4 lookups), first round only
    bool pin = false;  // SS_PIN
};
// The first line is the entry as it ships: its two startup tests decide. The next four say
// whether those tests chose well on this machine.
static const ProbeCfg PROBE_CFGS[] = {
    {"as shipped", false, -1, 0, 0, 0},        {"no huge pages", false, -1, 1, 0, 0},
    {"huge pages always", false, -1, 2, 0, 0}, {"read input", false, 0, 0, 0, 0},
    {"mapped input", false, 1, 0, 0, 0},       {"half the threads", true, -1, 0, 0, 0},
    {"partitions / 2", false, -1, 0, -1, 0},   {"partitions x 2", false, -1, 0, 1, 0},
    {"pinned threads", false, -1, 0, 0, 0, true},
    {"parse: scan only", false, -1, 0, 0, 1},  {"parse: + split", false, -1, 0, 0, 2},
    {"parse: + fields", false, -1, 0, 0, 3},   {"parse: + lookups", false, -1, 0, 0, 4},
};
struct ProbeRes {
    int n;
    double ms[16];
    double user, sys;
    long faults;
};

// Runs every setting `rounds` times, in turn. Each run is a child process that does what the real
// entry does and exits, so the time from fork to reaped includes giving the memory back, as the
// scorer's clock does. Prints one line per run and the best of each setting at the end.
static void probe_bench(const char* label, int full, int rounds, double deadline) {
    const int NC = (int)(sizeof PROBE_CFGS / sizeof PROBE_CFGS[0]);
    std::vector<double> best((size_t)NC, 1e18);
    std::vector<std::string> best_line((size_t)NC);
    // The huge page test again, for a dataset of this size: its line in the log says what the
    // entry would decide here, and "as shipped" below runs with that decision.
    probe_use_copies(false);
    HUGE_OK = huge_pages_cheap((B_EVENTS + B_CLICKS) / 2 + ((B_EVENTS + B_CLICKS) / 500 + B_LINKS / 10 + 4096) * 16);
    fprintf(stderr, "bench %s: as shipped the input is %s\n", label, COPY_SLOW ? "mapped" : "read");
    // Round -1 is one run of the first setting that is not counted: the first run after the
    // copies are made was slower than the same setting run later, whatever the setting.
    for (int round = -1; round < rounds; round++)
        for (int ci = 0; ci < NC; ci++) {
            const ProbeCfg& c = PROBE_CFGS[ci];
            if (round < 0 && ci) break;
            if (c.stage && round) continue;
            if (probe_elapsed() > deadline) {
                fprintf(stderr, "bench %s: out of time before round %d, setting %d\n", label, round, ci);
                round = rounds;
                break;
            }
            probe_use_copies(c.io < 0 ? COPY_SLOW : c.io == 1);
            T = c.half ? std::max(1, full / 2) : full;
            HUGE_MODE = c.huge;
            STAGE = c.stage;
            PIN = c.pin;
            u32 peb = 4;
            u64 est_rows = B_EVENTS / 74 + 1;
            while (peb < 13 && (est_rows >> peb) > SS_PART_ROWS) peb++;
            FORCE_PEB = std::max(4, std::min(13, (int)peb + c.peb));
            u64 slots = (B_EVENTS + B_CLICKS) / 500 + B_LINKS / 10 + 4096;
            int pfd[2];
            if (pipe(pfd)) return;
            double w0 = now_s();
            pid_t pid = fork();
            if (pid == 0) {
                close(pfd[0]);
                signal(SIGALRM, SIG_DFL);
                alarm(45);  // a run that hangs is killed and reported, the probe goes on
                PROBE_CHILD = true;
                LAP_QUIET = true;
                do {
                    LAP_N = 0;
                    T0 = now_s();
                } while (!run(slots) && (slots *= 4));
                ProbeRes res{};
                rusage ru;
                getrusage(RUSAGE_SELF, &ru);
                res.n = LAP_N;
                memcpy(res.ms, LAP_MS, sizeof res.ms);
                res.user = (double)ru.ru_utime.tv_sec * 1e3 + (double)ru.ru_utime.tv_usec * 1e-3;
                res.sys = (double)ru.ru_stime.tv_sec * 1e3 + (double)ru.ru_stime.tv_usec * 1e-3;
                res.faults = ru.ru_minflt;
                if (write(pfd[1], &res, sizeof res) != (ssize_t)sizeof res) _exit(3);
                _exit(0);
            }
            close(pfd[1]);
            ProbeRes res{};
            ssize_t got = pid > 0 ? read(pfd[0], &res, sizeof res) : -1;
            close(pfd[0]);
            int status = 0;
            if (pid > 0) waitpid(pid, &status, 0);
            double wall = (now_s() - w0) * 1e3;
            if (got != (ssize_t)sizeof res || res.n <= 0 || res.n > 16) {
                fprintf(stderr, "bench %s %-17s failed, wait status %d\n", label, c.name, status);
                continue;
            }
            double total = res.ms[res.n - 1];
            char line[512];
            int n = snprintf(line, sizeof line, "bench %s %-17s T%-2d peb%-2d wall %7.1f ms (run %7.1f, exit %5.1f) | steps", label,
                             c.name, T, FORCE_PEB, wall, total, wall - total);
            for (int i = 0; i < res.n && n < 400; i++)
                n += snprintf(line + n, sizeof line - (size_t)n, " %.0f", res.ms[i] - (i ? res.ms[i - 1] : 0));
            snprintf(line + n, sizeof line - (size_t)n, " | user %.0f sys %.0f ms, faults %ld", res.user, res.sys, res.faults);
            if (round < 0) {
                fprintf(stderr, "warm-up, not counted: %s\n", line);
                continue;
            }
            fprintf(stderr, "%s\n", line);
            if (wall < best[(size_t)ci]) best[(size_t)ci] = wall, best_line[(size_t)ci] = line;
        }
    fprintf(stderr, "==== bench %s: the best run of each setting. wall is fork to reaped, so it has the cost of exiting. "
                    "steps: links, join, parse, dedup, sessions, campaigns, release ====\n",
            label);
    for (int ci = 0; ci < NC; ci++)
        if (!best_line[(size_t)ci].empty()) {
            fprintf(stderr, "best  %s\n", best_line[(size_t)ci].c_str());
            PROBE_BEST.push_back(best_line[(size_t)ci]);
        }
    FORCE_PEB = 0, HUGE_MODE = 0, STAGE = 0, PIN = false, T = full;
}
#endif

int main() {
    T0 = now_s();
    VERBOSE = getenv("SS_VERBOSE") != nullptr;
#ifdef SS_PROBE
    VERBOSE = true;
#endif
    const char* e;
    std::string data = (e = getenv("DATA_DIR")) && *e ? e : "/data";
    OUT_DIR = (e = getenv("OUTPUT_DIR")) && *e ? e : "/output";
    int ncpu = (e = getenv("NCPU")) ? atoi(e) : 0;
    if (ncpu <= 0) ncpu = (int)std::thread::hardware_concurrency();
    T = std::max(1, std::min(ncpu, 32));
    if ((e = getenv("SS_THREADS")) && atoi(e) > 0) T = std::min(atoi(e), 32);

    init_calendar();
    std::string manifest = read_small(data + "/manifest.json");
    WS = manifest_ts(manifest, "window_start");
    WE = manifest_ts(manifest, "window_end");
    if (WE <= WS) die("window_end is not after window_start");
    if (WE - WS + WEEKMS >= (1LL << 31)) die("a window longer than 17 days is not supported");
    CWS = WS - WEEKMS;
    i64 ws_sec = WS >= 0 ? WS / 1000 : -((-WS + 999) / 1000);
    ING_BASE = ws_sec - (1LL << 31);
    DAY0 = WS >= 0 ? WS / DAYMS : -((-WS + DAYMS - 1) / DAYMS);
    WS_OFF = (u32)(WS - DAY0 * DAYMS);
    i64 last = WE - 1;
    i64 last_day = last >= 0 ? last / DAYMS : -((-last + DAYMS - 1) / DAYMS);
    NDAYS = (u32)(last_day - DAY0 + 1);

    // Every input file stays open, and a process starts with room for 64 descriptors. Growing
    // the table while a second thread runs waits for an RCU grace period (expand_fdtable calls
    // synchronize_rcu): 6 to 17 ms in map_dir with the products thread running, and once more
    // past 128 files. Grown here, with one thread, it costs a few microseconds.
    if (struct rlimit rl; !getrlimit(RLIMIT_NOFILE, &rl) && rl.rlim_cur > 64) {
        const int top = (int)std::min<rlim_t>(rl.rlim_cur, 1024) - 1;
        const int fd = open("/", O_RDONLY | O_CLOEXEC);
        if (fd >= 0) {
            if (fd < top && dup2(fd, top) == top) close(top);
            close(fd);
        }
    }
    // With one thread the products load in line. Nothing then depends on how two threads take
    // turns, so the training run of the profile-guided build counts the same every time.
    if (T == 1) load_products(data);
    else g_products_thread = std::thread([data] { load_products(data); });
    load_campaigns(data);
    if ((e = getenv("SS_MMAP"))) USE_MMAP = true, MMAP_MODE = std::max(1, atoi(e));
    if (getenv("SS_NOHUGE")) HUGE_MODE = 1;
    else if (getenv("SS_HUGE")) HUGE_MODE = 2;
    PIN = getenv("SS_PIN") != nullptr;
    if (PIN) pin_init();
    if ((e = getenv("SS_PEB"))) FORCE_PEB = atoi(e);
    if (getenv("SS_OLDSPLIT")) OLDSPLIT = true;
    if ((e = getenv("SS_FUSED"))) FUSED = atoi(e) != 0;
    if (getenv("SS_NOSKEW")) NOSKEW = true;
    if (getenv("SS_QUEUE")) NOQUEUE = false;
    if (getenv("SS_SLOTSORT")) FULLSORT = false;
    if (getenv("SS_RADIXSORT")) PERSONSORT = false;
    if (getenv("SS_CHUNKIDORDER")) CHUNKIDORDER = true;
    if (getenv("SS_NONORDER")) NORDER = false;
    if (getenv("SS_NOKEYS")) NKEYS = false;
    if (getenv("SS_NODENSE")) NODENSE = true;
    if ((e = getenv("SS_DLSH")) && atoi(e) >= 10 && atoi(e) <= 20) DLSH = (u32)atoi(e);
#ifdef SS_PROBE
    NODENSE = true;  // the probe's benchmark runs the hashed way it measures
#endif
#if defined(SS_PROBE) || defined(SS_STAGES)
    if ((e = getenv("SS_STAGE"))) STAGE = atoi(e);
#endif
    F_EVENTS = map_dir(data + "/events", B_EVENTS);
    F_CLICKS = map_dir(data + "/clicks", B_CLICKS);
    F_LINKS = map_dir(data + "/links", B_LINKS);
    // Reading or mapping the input. Reading wins where the kernel copies fast (4% over
    // mapping on Intel runners). On other machines the same copy runs at a fifth of the
    // speed and mapping wins by far. So time the copy of 8 MB the way the pipeline reads,
    // and map the files when it is slow. SS_READ: always read. SS_MMAP: always map.
    if (!USE_MMAP && !getenv("SS_READ")) {
        MFile* big = nullptr;
        for (auto& f : F_EVENTS)
            if (!big || f.size > big->size) big = &f;
        const size_t piece = 128 << 10, pieces = 64;
        if (big && big->fd >= 0 && big->size >= 2 * piece * pieces) {
            u8* buf = (u8*)aligned_alloc(4096, piece);
            memset(buf, 1, piece);
            size_t got = 0;
            const u64 t0 = mono_ns();
            for (size_t i = 0; i < pieces; i++) {
                ssize_t r = pread(big->fd, buf, piece, (off_t)(i * piece));
                if (r <= 0) break;
                got += (size_t)r;
            }
            const u64 dt = mono_ns() - t0;
            free(buf);
            const double gbs = dt ? (double)got / (double)dt : 99.0;  // bytes per ns
            const bool slow = got == piece * pieces && gbs < 3.0;
            if (VERBOSE) fprintf(stderr, "kernel copy %.1f GB/s: the input is %s\n", gbs, slow ? "mapped" : "read");
            if (slow) {
                COPY_SLOW = true;
                USE_MMAP = true, MMAP_MODE = 2;
                for (auto* v : {&F_EVENTS, &F_CLICKS, &F_LINKS})
                    for (auto& f : *v) map_open_file(f);
            }
        }
    }
    // The key search runs beside the links (run waits for it before the events), on one
    // thread. With one thread in all, in line, so the training run of the profile-guided
    // build counts the same every time.
    if (!NODENSE && B_EVENTS) {
        DS_ON = true;
        if (T == 1) dense_infer(1);
        else g_dense_thread = std::thread([] { dense_infer(1); });
    }
    mkdir(OUT_DIR.c_str(), 0777);
    mkdir((OUT_DIR + "/user_daily").c_str(), 0777);
    mkdir((OUT_DIR + "/campaign_daily").c_str(), 0777);
    lap("inputs mapped");

    u64 slots = (B_EVENTS + B_CLICKS) / 500 + B_LINKS / 10 + 4096;
    // Huge pages are asked for where they are cheap, unless SS_NOHUGE or SS_HUGE settled it above.
    if (HUGE_MODE == 0) HUGE_OK = huge_pages_cheap((B_EVENTS + B_CLICKS) / 2 + slots * 16);
    if ((e = getenv("SS_SLOTS")) && atoll(e) > 0) slots = (u64)atoll(e);  // testing: force the regrow path
#ifdef SS_PROBE
    PROBE_START = T0;
    // Never run into the scorer's own time limit: a probe that is cut off may hand back no log.
    signal(SIGALRM, [](int) {
        static const char m[] = "==== probe: out of time, stopping ====\n";
        ssize_t r = write(2, m, sizeof m - 1);
        (void)r;
        _exit(0);
    });
    alarm(165);
    if (g_products_thread.joinable()) g_products_thread.join();  // the benchmark forks: no thread may be left running
    probe_env();
    {
        const int full = T;
        // The benchmark: the dev set 20 times over (the size of the practice run), every setting
        // twice, then 60 times over (the size of the final) if there is time. The dev check gives
        // a submission 3 minutes; everything here stops by itself well before that.
        int copies = (e = getenv("SS_PROBE_COPIES")) ? atoi(e) : 20;
        int big = (e = getenv("SS_PROBE_BIG")) ? atoi(e) : 60;
        rlimit nof;
        if (!getrlimit(RLIMIT_NOFILE, &nof)) {
            nof.rlim_cur = nof.rlim_max;
            setrlimit(RLIMIT_NOFILE, &nof);
        }
        pin_init();
        if (copies > 0) {
            // The original fds are closed by hand here: the real dataset is opened again after the benchmark.
            probe_close_inputs(true);
            std::string scratch = (e = getenv("SCRATCH_DIR")) && *e ? e : "/scratch";
            std::string real_out = OUT_DIR, bench_out = scratch + "/ssb-out";
            bool own_out = mkdir(bench_out.c_str(), 0777) == 0;
            if (own_out) {
                OUT_DIR = bench_out;
                mkdir((OUT_DIR + "/user_daily").c_str(), 0777);
                mkdir((OUT_DIR + "/campaign_daily").c_str(), 0777);
            }
            double t = now_s();
            u64 wrote = probe_replicate(data, 0, copies, full);
            fprintf(stderr, "==== probe: %d copies of the dev set in memory, %zu files, %llu MB in %.1f s (%.1f s since the start), "
                            "output to %s ====\n",
                    copies, PROBE_FILES.size(), (unsigned long long)(wrote >> 20), now_s() - t, probe_elapsed(), OUT_DIR.c_str());
            char label[16];
            snprintf(label, sizeof label, "x%d", copies);
            if (wrote) probe_bench(label, full, 2, 80);
            if (wrote && big > copies && probe_elapsed() < 70) {
                t = now_s();
                wrote = probe_replicate(data, copies, big, full);
                fprintf(stderr, "==== probe: %d more copies, %zu files, %llu MB in %.1f s (%.1f s since the start) ====\n", big - copies,
                        PROBE_FILES.size(), (unsigned long long)(wrote >> 20), now_s() - t, probe_elapsed());
                snprintf(label, sizeof label, "x%d", big);
                if (wrote) probe_bench(label, full, 1, 135);
            }
            if (own_out) {  // leave the scratch disk as it was found
                for (const char* kind : {"/user_daily", "/campaign_daily", ""}) {
                    std::string dir = bench_out + kind;
                    if (DIR* d = opendir(dir.c_str())) {
                        while (dirent* en = readdir(d))
                            if (en->d_name[0] != '.') unlink((dir + "/" + en->d_name).c_str());
                        closedir(d);
                    }
                    rmdir(dir.c_str());
                }
            }
            OUT_DIR = real_out;
            probe_use_data(data);
        }
        // The dev set itself: all threads, half of them, then all again. The last run starts from
        // an empty folder, so user_daily is left complete and right.
        const int plan[3] = {full, std::max(1, full / 2), full};
        for (int r = 0; r < 3; r++) {
            T = plan[r];
            if (r == 2) {
                std::string dir = OUT_DIR + "/user_daily";
                if (DIR* d = opendir(dir.c_str())) {
                    while (dirent* en = readdir(d))
                        if (en->d_name[0] != '.') unlink((dir + "/" + en->d_name).c_str());
                    closedir(d);
                }
            }
            fprintf(stderr, "==== probe: pipeline run %d on the dev set, %d threads, %.1f s since the start ====\n", r, T,
                    probe_elapsed());
            T0 = now_s();
            slots = (B_EVENTS + B_CLICKS) / 500 + B_LINKS / 10 + 4096;
            while (!run(slots)) slots *= 4;
            lap("done");
        }
        PqFile empty;
        empty.open(OUT_DIR + "/campaign_daily/part-000.parquet",
                   {{"campaign_id", PQ_BYTES, 0, false}, {"channel", PQ_BYTES, 0, false}, {"day", PQ_INT32, 6, false},
                    {"sessions", PQ_INT64, -1, false}, {"purchasing_sessions", PQ_INT64, -1, false},
                    {"revenue_cents", PQ_INT64, -1, false}, {"assisted_sessions", PQ_INT64, -1, false}});
        empty.close();
        // Once more at the very end, in case the scorer hands back only the end of a log.
        fprintf(stderr, "==== the benchmark's best runs again (wall = fork to reaped; steps: links, join, parse, dedup, "
                        "sessions, campaigns, release) ====\n");
        for (auto& line : PROBE_BEST) fprintf(stderr, "best  %s\n", line.c_str());
        fprintf(stderr, "==== probe: done, campaign_daily left empty on purpose ====\n");
        fflush(stderr);
        _exit(0);
    }
#endif
    while (!run(slots)) {
        if (VERBOSE) fprintf(stderr, "user table too small at %llu slots, retrying\n", (unsigned long long)slots);
        slots *= 4;
    }
    lap("done");
    fflush(stderr);
    // The counting build of a profile-guided compile writes its counters here. No other build
    // has the function, so they go straight to the exit, and both compiles see the same code.
    if (__gcov_dump) __gcov_dump();
    _exit(0);
}
