// Shopping Sessions pipeline. One native binary, no engine.
//
// Phases (all parallel over NCPU threads):
//   1. links   -> lock-free union-find inside the user table; the root of a
//                 person is always their byte-wise smallest ID.
//   2. parse   -> events become 24-byte records partitioned by hash(event_id);
//                 clicks become 16-byte records partitioned by person bucket.
//   3. dedup   -> each event partition is deduplicated in cache (smallest
//                 ingest_ts wins, then validity decides), survivors are
//                 scattered to person buckets.
//   4. buckets -> per bucket: radix sort by (person, ts), sessionize, credit
//                 and assist from the person's clicks, write user_daily rows.
//   5. merge the per-thread campaign tables and write campaign_daily.
//
// IDs are kept exact without storing strings: an ID of 2..9 bytes that starts
// with the expected letter (e/u/k) and holds only bytes 0x01..0x7F is packed
// into a u64 (the 8 bytes after the letter). Anything else goes through a
// mutex-protected interner and gets a key with bit 63 set.
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <algorithm>
#include <atomic>
#include <cerrno>
#include <csignal>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include <dirent.h>
#include <fcntl.h>
#include <sched.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#if defined(__x86_64__)
#include <immintrin.h>
#elif defined(__aarch64__)
#include <arm_neon.h>
#endif

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int32_t i32;
typedef int64_t i64;

// Present only in a build made with -fprofile-generate (see the Dockerfile and the end of main).
extern "C" void __gcov_dump(void) __attribute__((weak));

#define likely(x) __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)
// -DSS_INLINE_ROW puts each row handler inside the loop that cuts the lines (no call per row).
#ifdef SS_INLINE_ROW
#define ROW_INLINE __attribute__((always_inline))
#else
#define ROW_INLINE
#endif

static inline u64 load64(const u8* p) { u64 v; memcpy(&v, p, 8); return v; }
static inline u32 load32(const u8* p) { u32 v; memcpy(&v, p, 4); return v; }

[[noreturn]] static void die(const char* fmt, ...) __attribute__((format(printf, 1, 2)));
static void die(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "fatal: ");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
    _exit(1);
}

static double now_s() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}
static double T0;
static bool VERBOSE = false;
// Step timers inside the phases, printed with SS_VERBOSE. Thread time, summed over the threads.
static inline u64 ticks() {
    timespec ts;
    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
    return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}
// Profiling only (SS_STAGE): stop early in the parse. 1 scan, 2 split, 3 fields, 4 lookups, 0 everything.
// Only a build made with -DSS_PROBE or -DSS_STAGES has the switch. In the entry itself it is a
// constant, so the checks on it in the row loops cost nothing.
#if defined(SS_PROBE) || defined(SS_STAGES)
static int STAGE = 0;
#else
static const int STAGE = 0;
#endif
// The probe's benchmark keeps the step times instead of printing them.
static bool LAP_QUIET = false;
static double LAP_MS[16], LAP_SYS[16];
static long LAP_FLT[16];
static int LAP_N = 0;
static void lap(const char* what) {
    if (!VERBOSE) return;
    if (LAP_QUIET) {
        if (LAP_N < 16) {
            rusage ru;
            getrusage(RUSAGE_SELF, &ru);
            LAP_SYS[LAP_N] = (double)ru.ru_stime.tv_sec * 1e3 + (double)ru.ru_stime.tv_usec * 1e-3;
            LAP_FLT[LAP_N] = ru.ru_minflt;
            LAP_MS[LAP_N++] = (now_s() - T0) * 1e3;
        }
        return;
    }
    rusage ru;
    getrusage(RUSAGE_SELF, &ru);
    long thp = -1, rss = -1;
    if (FILE* f = fopen("/proc/self/smaps_rollup", "r")) {
        char line[256];
        while (fgets(line, sizeof line, f)) {
            if (!strncmp(line, "AnonHugePages:", 14)) thp = atol(line + 14) / 1024;
            if (!strncmp(line, "Rss:", 4)) rss = atol(line + 4) / 1024;
        }
        fclose(f);
    }
    fprintf(stderr, "[%8.1f ms] %-32s user %6.0f ms, sys %6.0f ms, minflt %7ld, rss %5ld MB, thp %5ld MB\n",
            (now_s() - T0) * 1e3, what, ru.ru_utime.tv_sec * 1e3 + ru.ru_utime.tv_usec * 1e-3,
            ru.ru_stime.tv_sec * 1e3 + ru.ru_stime.tv_usec * 1e-3, ru.ru_minflt, rss, thp);
}

static inline u64 mix64(u64 x) {
    x ^= x >> 32;
    x *= 0xd6e8feb86659fd93ULL;
    x ^= x >> 32;
    x *= 0xd6e8feb86659fd93ULL;
    x ^= x >> 32;
    return x;
}

// One multiply. The IDs are packed text, so the top bytes are folded down first:
// every character then reaches the high bits of the product, the only bits used.
static inline u64 hash1(u64 x) { return (x ^ (x >> 29)) * 0x9E3779B97F4A7C15ULL; }

static inline u32 tz64(u64 x) {
#if defined(__BMI__)
    return (u32)_tzcnt_u64(x);
#else
    return x ? (u32)__builtin_ctzll(x) : 64;
#endif
}

// ---------------------------------------------------------------- constants
static const i64 DAYMS = 86400000;
static const i64 WEEKMS = 7 * DAYMS;
static const u32 GAPMS = 1800000;
static const u64 SLOW = 1ull << 63;
static const u32 INVALID = 0xFFFFFFFFu;  // well-formed row that fails validation
static const u32 DEAD = 0xFFFFFFFEu;     // lost the dedup
static const u32 CHUNK = 16384;
static const u32 NOCHUNK = 0xFFFFFFFFu;

enum : u8 { ST_FREE = 0, ST_EREC = 1, ST_MAIN = 2, ST_PURCH = 3, ST_CLICK = 4 };

// ---------------------------------------------------------------- globals
static int T = 8;
static i64 WS, WE, CWS;  // event window and click window start, ms
static i64 ING_BASE;     // seconds; ingest is stored as u32 relative to this
static i64 DAY0;         // epoch day of the window start
static u32 WS_OFF;       // ms of the window start into its day
static u32 NDAYS;

static std::atomic<bool> g_overflow{false};

// ---------------------------------------------------------------- calendar
static i32 YEAR_START[10000];
static u8 YEAR_LEAP[10000];
static const u16 CUM[2][13] = {{0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334},
                               {0, 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335}};
static const u8 DIM[2][13] = {{0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
                              {0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}};

static i64 days_from_civil(i64 y, i64 m, i64 d) {
    y -= m <= 2;
    i64 era = (y >= 0 ? y : y - 399) / 400;
    i64 yoe = y - era * 400;
    i64 doy = (153 * ((m + 9) % 12) + 2) / 5 + d - 1;
    i64 doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + doe - 719468;
}
static void init_calendar() {
    for (int y = 0; y < 10000; y++) {
        YEAR_START[y] = (i32)days_from_civil(y, 1, 1);
        YEAR_LEAP[y] = (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)) ? 1 : 0;
    }
}
static void civil_from_days(i64 z, int& y, int& m, int& d) {
    z += 719468;
    i64 era = (z >= 0 ? z : z - 146096) / 146097;
    i64 doe = z - era * 146097;
    i64 yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    i64 yy = yoe + era * 400;
    i64 doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    i64 mp = (5 * doy + 2) / 153;
    d = (int)(doy - (153 * mp + 2) / 5 + 1);
    m = (int)(mp < 10 ? mp + 3 : mp - 9);
    y = (int)(yy + (m <= 2));
}

// ---------------------------------------------------------------- numbers
static const u64 M7 = 0x7F7F7F7F7F7F7F7FULL, H8 = 0x8080808080808080ULL;

static inline bool all_digits8(u64 w) {
    return ((w & 0xF0F0F0F0F0F0F0F0ULL) | (((w + 0x0606060606060606ULL) & 0xF0F0F0F0F0F0F0F0ULL) >> 4)) ==
           0x3333333333333333ULL;
}
static inline u32 parse8(u64 w) {
    w = (w & 0x0F0F0F0F0F0F0F0FULL) * 2561 >> 8;
    w = (w & 0x00FF00FF00FF00FFULL) * 6553601 >> 16;
    return (u32)((w & 0x0000FFFF0000FFFFULL) * 42949672960001ULL >> 32);
}
// The first n (1..8) chars at s as an 8-char block with leading '0's.
static inline u64 block8(const u8* s, size_t n) {
    u64 w = load64(s);
    if (n == 8) return w;
    int sh = (int)(8 - n) * 8;
    return (w << sh) | (0x3030303030303030ULL >> (64 - sh));
}
// Digits only, more than 16 of them: the rare case, kept out of line so the short
// cases below stay small enough to sit inside the row handlers.
__attribute__((noinline, cold)) static bool parse_digits_long(const u8* s, size_t n, u64& out) {
    for (size_t i = 0; i < n; i++)
        if ((u8)(s[i] - '0') > 9) return false;
    while (n > 1 && *s == '0') s++, n--;
    if (n > 18) { out = ~0ULL; return true; }
    u64 v = 0;
    for (size_t i = 0; i < n; i++) v = v * 10 + (s[i] - '0');
    out = v;
    return true;
}
// Digits only, any length >= 1. More than 18 significant digits saturates.
__attribute__((always_inline)) static inline bool parse_digits(const u8* s, size_t n, u64& out) {
    if (likely(n - 1 < 8)) {
        u64 w = block8(s, n);
        if (!all_digits8(w)) return false;
        out = parse8(w);
        return true;
    }
    if (n == 0) return false;
    if (likely(n <= 16)) {
        u64 lo = load64(s + n - 8), hi = block8(s, n - 8);
        if (!all_digits8(lo) || !all_digits8(hi)) return false;
        out = (u64)parse8(hi) * 100000000ULL + parse8(lo);
        return true;
    }
    return parse_digits_long(s, n, out);
}
// Digits with no leading zero (or the single digit 0), at most 7 of them.
static inline bool canon_num(const u8* s, size_t n, u32& out) {
    if (n - 1 >= 7) return false;
    u64 w = block8(s, n);
    if (!all_digits8(w)) return false;
    if (n > 1 && s[0] == '0') return false;
    out = parse8(w);
    return true;
}

// ---------------------------------------------------------------- timestamps
static const i64 BAD_TS = INT64_MIN;

// "YYYY-MM-DD" at p[0..10). Days since the epoch.
static bool parse_date10(const u8* p, i64& days) {
    u64 a = load64(p) ^ 0x2D30302D30303030ULL;
    u32 d0 = (u32)p[8] ^ 0x30, d1 = (u32)p[9] ^ 0x30;
    u64 bad = (((a & M7) + 0x7F76767F76767676ULL) | a) & H8;
    if (bad || d0 > 9 || d1 > 9) return false;
    u64 pa = a * 2561;
    u32 year = (u32)((pa >> 8) & 0xFF) * 100 + (u32)((pa >> 24) & 0xFF);
    u32 mon = (u32)(pa >> 48) & 0xFF;
    u32 day = d0 * 10 + d1;
    if (mon - 1 >= 12) return false;
    u32 leap = YEAR_LEAP[year];
    if (day - 1 >= DIM[leap][mon]) return false;
    days = (i64)YEAR_START[year] + CUM[leap][mon] + day - 1;
    return true;
}

// A dataset holds a few dozen dates, each millions of times. Every thread
// keeps the dates it has checked, by their ten bytes, with their midnight.
struct DateEnt {
    u64 a;     // "YYYY-MM-" as read
    u32 d2;    // "DD" as read
    u32 pad;
    i64 secs;  // the date's midnight
};
static thread_local DateEnt DATE_CACHE[64];

static inline bool parse_dt19_old(const u8* p, i64& secs);

// "YYYY-MM-DDTHH:MM:SS" at p[0..19). Seconds since the epoch.
__attribute__((always_inline)) static inline bool parse_dt19(const u8* p, i64& secs) {
    // "HH:MM:SS": digits within 2 9 : 5 9 : 5 9 and the two colons, then the hour itself.
    u64 x = load64(p + 11) ^ 0x30303A30303A3030ULL;
    u64 badt = (((x & M7) + 0x767A7F767A7F767DULL) | x) & H8;
    u64 pb = x * 2561;
    u32 hh = (u32)(pb >> 8) & 0xFF, mi = (u32)(pb >> 32) & 0xFF, ss = (u32)(pb >> 56);
    if (unlikely((badt | (u64)(p[10] ^ 'T') | (u64)(hh > 23)) != 0)) return false;
    u64 a = load64(p);
    u32 d2 = (u32)p[8] | ((u32)p[9] << 8);
    // The slot: two bits of the day's first digit and four of its second.
#if defined(__BMI2__)
    DateEnt& en = DATE_CACHE[_pext_u32(d2, 0x0F03u)];
#else
    DateEnt& en = DATE_CACHE[(d2 & 3) | ((d2 >> 6) & 0x3C)];
#endif
    i64 day_secs;
    if (likely(en.a == a && en.d2 == d2)) {
        day_secs = en.secs;
    } else {
        i64 days;
        if (!parse_date10(p, days)) return false;
        day_secs = days * 86400;
        en.a = a, en.d2 = d2, en.secs = day_secs;
    }
    secs = day_secs + (i64)(hh * 3600 + mi * 60 + ss);
    return true;
}

static inline bool parse_dt19_old(const u8* p, i64& secs) {
    u64 a = load64(p) ^ 0x2D30302D30303030ULL;
    u64 b = load64(p + 8) ^ 0x30303A3030543030ULL;
    u32 c = (load32(p + 16) ^ 0x0030303Au) & 0x00FFFFFFu;
    u64 bad = (((a & M7) + 0x7F76767F76767676ULL) | a | ((b & M7) + 0x76767F76767F7676ULL) | b) & H8;
    u32 badc = (((c & 0x7F7F7Fu) + 0x76767Fu) | c) & 0x808080u;
    if (unlikely(bad | badc)) return false;
    u64 pa = a * 2561, pb = b * 2561;
    u32 pc = (c >> 8) * 2561;
    u32 year = (u32)((pa >> 8) & 0xFF) * 100 + (u32)((pa >> 24) & 0xFF);
    u32 mon = (u32)(pa >> 48) & 0xFF;
    u32 day = (u32)(pb >> 8) & 0xFF, hh = (u32)(pb >> 32) & 0xFF, mi = (u32)(pb >> 56) & 0xFF;
    u32 ss = (pc >> 8) & 0xFF;
    if (unlikely(mon - 1 >= 12 || hh > 23 || mi > 59 || ss > 59)) return false;
    u32 leap = YEAR_LEAP[year];
    if (unlikely(day - 1 >= DIM[leap][mon])) return false;
    i64 days = (i64)YEAR_START[year] + CUM[leap][mon] + day - 1;
    secs = days * 86400 + hh * 3600 + mi * 60 + ss;
    return true;
}

// Any of the three forms, as epoch milliseconds, or BAD_TS. Inside the row handlers:
// as a call it cost a dozen instructions of entry and exit for every row.
__attribute__((always_inline)) static inline i64 parse_ts(const u8* p, size_t n) {
    if (n == 20 && p[19] == 'Z') {
        i64 s;
        return parse_dt19(p, s) ? s * 1000 : BAD_TS;
    }
    if (n == 25 && (p[19] == '+' || p[19] == '-')) {
        i64 s;
        if (!parse_dt19(p, s)) return BAD_TS;
        u64 d = (load64(p + 17) ^ 0x30303A3030000000ULL) & 0xFFFFFFFFFF000000ULL;
        if ((((d & M7) + 0x76767F7676000000ULL) | d) & H8) return BAD_TS;
        u64 pd = d * 2561;
        u32 oh = (u32)(pd >> 32) & 0xFF, om = (u32)(pd >> 56) & 0xFF;
        if (oh > 23 || om > 59) return BAD_TS;
        i64 off = oh * 3600 + om * 60;
        return (p[19] == '+' ? s - off : s + off) * 1000;
    }
    u64 v;
    if (likely(n - 9 < 8)) {  // 9 to 16 digits: epoch milliseconds have 13
        const u64 lo = load64(p + n - 8), hi = block8(p, n - 8);
        if (unlikely(!all_digits8(lo) || !all_digits8(hi))) return BAD_TS;
        v = (u64)parse8(hi) * 100000000ULL + parse8(lo);
    } else if (!parse_digits(p, n, v)) {
        return BAD_TS;
    }
    return v > (u64)INT64_MAX ? INT64_MAX : (i64)v;
}

// ---------------------------------------------------------------- interner
// IDs that do not fit the packed form. The strings are spread over many small
// maps by a hash, each with its own lock, so threads rarely wait on each other
// even when every ID in a dataset takes this path. A key is the map's number
// and the string's number inside it.
struct Interner {
    static const u32 STRIPES = 1024;
    struct Stripe {
        ~Stripe() {}
        std::mutex m;
        std::unordered_map<std::string, u32> map;
        std::deque<std::string> strs;
        char pad[64];
    };
    Stripe* stripes = new Stripe[STRIPES];
    u64 intern(const u8* s, size_t n) {
        u64 h = 0xcbf29ce484222325ULL;
        for (size_t i = 0; i < n; i++) h = (h ^ s[i]) * 0x100000001b3ULL;
        u32 si = (u32)(mix64(h) >> 54);
        Stripe& st = stripes[si];
        std::lock_guard<std::mutex> g(st.m);
        auto it = st.map.find(std::string((const char*)s, n));
        u32 id;
        if (it != st.map.end()) {
            id = it->second;
        } else {
            id = (u32)st.strs.size();
            st.strs.emplace_back((const char*)s, n);
            st.map.emplace(st.strs.back(), id);
        }
        return SLOW | ((u64)si << 32) | id;
    }
    std::string get(u64 key) {
        Stripe& st = stripes[(u32)(key >> 32) & (STRIPES - 1)];
        std::lock_guard<std::mutex> g(st.m);
        return st.strs[(u32)key];
    }
};
static Interner g_intern;

// The rare IDs go through a call that is kept out of line, so the packed path
// stays small enough to sit inside every row handler.
__attribute__((noinline, cold)) static u64 id_key_slow(const u8* s, size_t n) { return g_intern.intern(s, n); }
__attribute__((always_inline)) static inline u64 id_key(const u8* s, size_t n, u8 prefix) {
    if (likely(n - 2 < 8 && s[0] == prefix)) {
        const unsigned sh = 64 - 8 * ((unsigned)n - 1);  // 0..56
        const u64 m = ~0ULL >> sh;
        const u64 w = load64(s + 1) & m;
        const u64 z = w | ~m;
        if (likely((w & H8) == 0 && ((z - 0x0101010101010101ULL) & ~z & H8) == 0)) return w;
    }
    return id_key_slow(s, n);
}
// The ID a key stands for, written to out (at least 16 bytes). Returns its length
// when the key is packed; an interned key returns 0 and fills `slow`.
static inline size_t key_str_fast(u64 key, u8 prefix, u8* out) {
    out[0] = prefix;
    memcpy(out + 1, &key, 8);
    return 1 + (size_t)((71 - __builtin_clzll(key)) >> 3);
}
static std::string key_string(u64 key, u8 prefix) {
    if (key & SLOW) return g_intern.get(key);
    u8 b[16];
    size_t n = key_str_fast(key, prefix, b);
    return std::string((const char*)b, n);
}
// Byte-wise order of the IDs two keys stand for.
static inline bool id_less(u64 a, u64 b, u8 prefix) {
    if (likely(!((a | b) & SLOW))) return __builtin_bswap64(a) < __builtin_bswap64(b);
    return key_string(a, prefix) < key_string(b, prefix);
}

// ---------------------------------------------------------------- user table
struct Slot {
    u64 key;     // 0 = empty
    u32 parent;  // 0 = root, else parent slot + 1
    u32 pad;
};
static Slot* TAB;
static u64 TABN;
static u64 TAB_LIMIT, TAB_QUOTA;
static std::atomic<u64> g_tab_used{0};
static u32 LW;   // log2(slots per person bucket)
static u32 PB;   // person buckets
static u32 CBITS;  // bits of a campaign index
static u32 PEB;  // log2(event partitions)

static inline u64 tab_home(u64 key) { return (u64)(((unsigned __int128)hash1(key) * TABN) >> 64); }

struct TabCounter {
    u64 pending = 0;
    inline void inserted() {
        if (unlikely(++pending >= TAB_QUOTA)) {
            u64 total = g_tab_used.fetch_add(pending, std::memory_order_relaxed) + pending;
            pending = 0;
            if (total > TAB_LIMIT) g_overflow.store(true, std::memory_order_relaxed);
        }
    }
};

// The slot of a key, inserting it if it is new.
static inline u32 tab_slot(u64 key, u64 i, TabCounter& tc) {
    {
        // Nearly every key sits in its home slot or the next one. Which of the two is a
        // coin toss, so both are compared before the one branch that is almost always taken.
        const u64 i1 = i + 1 == TABN ? 0 : i + 1;
        const u64 k0 = __atomic_load_n(&TAB[i].key, __ATOMIC_RELAXED);
        const u64 k1 = __atomic_load_n(&TAB[i1].key, __ATOMIC_RELAXED);
        const bool miss0 = k0 != key;
        if (likely((!miss0) | ((k1 == key) & (k0 != 0)))) return (u32)(i ^ ((i ^ i1) & (0 - (u64)miss0)));
    }
    for (;;) {
        u64 k = __atomic_load_n(&TAB[i].key, __ATOMIC_RELAXED);
        if (k == key) return (u32)i;
        if (k == 0) {
            if (unlikely(g_overflow.load(std::memory_order_relaxed))) return 0;
            u64 expect = 0;
            if (__atomic_compare_exchange_n(&TAB[i].key, &expect, key, false, __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
                tc.inserted();
                return (u32)i;
            }
            if (expect == key) return (u32)i;
        }
        if (++i == TABN) i = 0;
    }
}
// Root or not is a coin toss per row, so the choice is made without a branch.
static inline u32 tab_person(u32 slot) {
    u32 p = __atomic_load_n(&TAB[slot].parent, __ATOMIC_RELAXED);
    u32 pick = 0u - (u32)(p != 0);  // all ones when the slot has a parent
    return slot ^ ((slot ^ (p - 1)) & pick);
}

static inline u32 uf_find(u32 x) {
    for (;;) {
        u32 p = __atomic_load_n(&TAB[x].parent, __ATOMIC_RELAXED);
        if (!p) return x;
        u32 gp = __atomic_load_n(&TAB[p - 1].parent, __ATOMIC_RELAXED);
        if (!gp) return p - 1;
        __atomic_store_n(&TAB[x].parent, gp, __ATOMIC_RELAXED);  // path halving
        x = gp - 1;
    }
}
static inline u32 uf_find_ro(u32 x) {
    for (;;) {
        u32 p = __atomic_load_n(&TAB[x].parent, __ATOMIC_RELAXED);
        if (!p) return x;
        x = p - 1;
    }
}
// Joins two slots. The root with the larger ID goes under the smaller one, so
// a root is always the smallest ID of its tree.
static inline void uf_union(u32 a, u32 b) {
    for (;;) {
        u32 ra = uf_find(a), rb = uf_find(b);
        if (ra == rb) return;
        u64 ka = __atomic_load_n(&TAB[ra].key, __ATOMIC_RELAXED), kb = __atomic_load_n(&TAB[rb].key, __ATOMIC_RELAXED);
        if (id_less(kb, ka, 'u')) std::swap(ra, rb);
        u32 expect = 0;
        if (__atomic_compare_exchange_n(&TAB[rb].parent, &expect, ra + 1, false, __ATOMIC_ACQ_REL, __ATOMIC_RELAXED))
            return;
    }
}

// ---------------------------------------------------------------- lookups
static std::vector<std::string> CAT_NAME;  // index ncat = "unknown"
static std::vector<u32> CAT_RANK;          // byte-wise rank of the name
static u32 NCAT;                           // categories in the file; NCAT = unknown
static std::vector<u32> PROD_DIRECT;       // by number, for canonical p<digits>
static std::unordered_map<std::string, u32> PROD_MAP;
static bool WIDE_CAT = false;

static std::vector<std::string> CAMP_NAME, CAMP_CHANNEL;  // index NCAMP = organic
static u32 NCAMP;
static std::vector<i32> CAMP_DIRECT;
static std::unordered_map<std::string, u32> CAMP_MAP;

static inline u32 product_cat(const u8* s, size_t n) {
    u32 num;
    if (likely(n >= 2 && s[0] == 'p' && canon_num(s + 1, n - 1, num)))
        return num < PROD_DIRECT.size() ? PROD_DIRECT[num] : NCAT;
    auto it = PROD_MAP.find(std::string((const char*)s, n));
    return it == PROD_MAP.end() ? NCAT : it->second;
}
static inline i32 campaign_idx(const u8* s, size_t n) {
    u32 num;
    if (likely(n >= 3 && s[0] == 'c' && s[1] == '_' && canon_num(s + 2, n - 2, num)))
        return num < CAMP_DIRECT.size() ? CAMP_DIRECT[num] : -1;
    auto it = CAMP_MAP.find(std::string((const char*)s, n));
    return it == CAMP_MAP.end() ? -1 : (i32)it->second;
}

// ---------------------------------------------------------------- scanner
#ifndef SS_WIN
#define SS_WIN 32768
#endif
static const u32 WIN = SS_WIN;  // bytes scanned before their lines are parsed
struct Scan {
    u32* cidx;
    u32* nidx;
    u64* qb;
    u32 nc, nn;
    // The tagged index (scan_tagged): every separator's position and a flag byte.
    // spos[-1] and sflg[-1] stand for the newline before the window.
    u32* spos_raw;
    u8* sflg_raw;
    u32* spos;
    u8* sflg;
    u32 ns;
    static const u32 QCAP = 128;  // rows held per timestamp form before they are handed over
    u32* rowq;
    void init() {
        cidx = (u32*)malloc((WIN + 128) * 4);
        nidx = (u32*)malloc((WIN + 128) * 4);
        qb = (u64*)malloc((WIN / 64 + 2) * 8);
        spos_raw = (u32*)malloc((WIN + 160) * 4);
        sflg_raw = (u8*)malloc(WIN + 160);
        spos = spos_raw + 16, sflg = sflg_raw + 16;
        rowq = (u32*)aligned_alloc(64, 3 * QCAP * 16 * 4);
    }
    void release() { free(cidx), free(nidx), free(qb), free(spos_raw), free(sflg_raw), free(rowq); }
};
static bool OLDSPLIT = false;  // SS_OLDSPLIT: the comma and newline indexes instead of the tagged one
// Measured on x86: queueing the rows by timestamp form gains nothing (0.4%, inside the
// noise), so rows go to the handler in file order unless SS_QUEUE is set.
static bool NOQUEUE = true;

static inline void emit_bits(u32*& out, u64 bits, u32 base) {
    u32 cnt = (u32)__builtin_popcountll(bits);
    u32* o = out;
    for (int i = 0; i < 8; i++) {
        o[i] = base + tz64(bits);
        bits &= bits - 1;
    }
    if (unlikely(cnt > 8)) {
        for (u32 i = 8; i < cnt; i++) {
            o[i] = base + tz64(bits);
            bits &= bits - 1;
        }
    }
    out += cnt;
}
static inline void emit_bits_few(u32*& out, u64 bits, u32 base) {
    u32 cnt = (u32)__builtin_popcountll(bits);
    u32* o = out;
    o[0] = base + tz64(bits);
    bits &= bits - 1;
    o[1] = base + tz64(bits);
    bits &= bits - 1;
    if (unlikely(cnt > 2)) {
        for (u32 i = 2; i < cnt; i++) {
            o[i] = base + tz64(bits);
            bits &= bits - 1;
        }
    }
    out += cnt;
}

// Comma, newline and quote masks of the 64 bytes at p.
static inline void masks64(const u8* p, u64& cm, u64& nm, u64& qm) {
#if defined(__AVX2__)
    __m256i a = _mm256_loadu_si256((const __m256i*)p), b = _mm256_loadu_si256((const __m256i*)(p + 32));
    const __m256i vc = _mm256_set1_epi8(','), vn = _mm256_set1_epi8('\n'), vq = _mm256_set1_epi8('"');
    cm = (u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(a, vc)) |
         ((u64)(u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(b, vc)) << 32);
    nm = (u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(a, vn)) |
         ((u64)(u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(b, vn)) << 32);
    qm = (u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(a, vq)) |
         ((u64)(u32)_mm256_movemask_epi8(_mm256_cmpeq_epi8(b, vq)) << 32);
#elif defined(__aarch64__)
    static const u8 bitv[16] = {1, 2, 4, 8, 16, 32, 64, 128, 1, 2, 4, 8, 16, 32, 64, 128};
    const uint8x16_t bm = vld1q_u8(bitv);
    uint8x16_t v0 = vld1q_u8(p), v1 = vld1q_u8(p + 16), v2 = vld1q_u8(p + 32), v3 = vld1q_u8(p + 48);
    auto mm = [&](u8 ch) -> u64 {
        const uint8x16_t c = vdupq_n_u8(ch);
        uint8x16_t t0 = vandq_u8(vceqq_u8(v0, c), bm), t1 = vandq_u8(vceqq_u8(v1, c), bm);
        uint8x16_t t2 = vandq_u8(vceqq_u8(v2, c), bm), t3 = vandq_u8(vceqq_u8(v3, c), bm);
        uint8x16_t s0 = vpaddq_u8(t0, t1), s1 = vpaddq_u8(t2, t3);
        s0 = vpaddq_u8(s0, s1);
        s0 = vpaddq_u8(s0, s0);
        return vgetq_lane_u64(vreinterpretq_u64_u8(s0), 0);
    };
    cm = mm(',');
    nm = mm('\n');
    qm = mm('"');
#else
    cm = nm = qm = 0;
    for (int i = 0; i < 64; i++) {
        u8 ch = p[i];
        cm |= (u64)(ch == ',') << i;
        nm |= (u64)(ch == '\n') << i;
        qm |= (u64)(ch == '"') << i;
    }
#endif
}

// Indexes the commas and newlines of base[0..len) and keeps a quote bitmap.
// Reads up to 63 bytes past len: every input has zero padding after it.
static inline void scan_window(const u8* base, u32 len, Scan& sc) {
    u32* co = sc.cidx;
    u32* no = sc.nidx;
    u32 nblk = (len + 63) >> 6;
    for (u32 b = 0; b < nblk; b++) {
        u64 cm, nm, qm;
        masks64(base + ((size_t)b << 6), cm, nm, qm);
        if (unlikely(b == nblk - 1) && (len & 63)) {
            u64 keep = (1ULL << (len & 63)) - 1;
            cm &= keep, nm &= keep, qm &= keep;
        }
        sc.qb[b] = qm;
        emit_bits(co, cm, b << 6);
        emit_bits_few(no, nm, b << 6);
    }
    sc.nc = (u32)(co - sc.cidx);
    sc.nn = (u32)(no - sc.nidx);
    for (int i = 0; i < 16; i++) co[i] = 0xFFFFFFFFu;
}

// ---- the tagged index
// One entry per separator (comma or newline) of the window, in order: its
// position and a flag byte. The flags let a line be cut into fields without
// looking at its bytes again:
//   FQA   the byte after the separator is a quote: the next field opens with one
//   FQB   the byte before it is a quote: the field it ends closes with one
//   FNL   the separator is a newline
//   FBAD  a quote that touches no separator lies in the field it ends
// No value holds a comma or a newline, so every separator bounds a field, and a
// line is well quoted exactly when no field has FBAD, each field's opening
// flag equals its closing flag, and a quoted field has two bytes or more.
static const u8 FQA = 1, FQB = 2, FNL = 4, FBAD = 8;

static inline void emit_flags(u8* out, u64 sep, u64 qa, u64 qb, u64 nm, u64 bad, u32 cnt) {
#if defined(__BMI2__)
    u64 fa = _pext_u64(qa, sep), fb = _pext_u64(qb, sep), fn = _pext_u64(nm, sep);
    u64 fx = bad ? _pext_u64(bad, sep) : 0;
    for (u32 k = 0;; k += 8) {
        u64 bytes = _pdep_u64(fa >> k, 0x0101010101010101ULL) | _pdep_u64(fb >> k, 0x0202020202020202ULL) |
                    _pdep_u64(fn >> k, 0x0404040404040404ULL);
        if (unlikely(fx)) bytes |= _pdep_u64(fx >> k, 0x0808080808080808ULL);
        memcpy(out + k, &bytes, 8);
        if (likely(k + 8 >= cnt)) break;
    }
#else
    u64 first = 0;
    memcpy(out, &first, 8);  // the callers read whole words of flags
    for (u32 k = 0; sep; k++, sep &= sep - 1) {
        u32 p = tz64(sep);
        out[k] = (u8)(((qa >> p) & 1) | (((qb >> p) & 1) << 1) | (((nm >> p) & 1) << 2) | (((bad >> p) & 1) << 3));
    }
    (void)cnt;
#endif
}

// Builds the tagged index of base[0..len). A line starts at base[0].
// Reads up to 63 bytes past len: every input has zero padding after it.
static inline void scan_tagged(const u8* base, u32 len, Scan& sc) {
    u32* po = sc.spos;
    u8* fo = sc.sflg;
    const u32 nblk = (len + 63) >> 6;
    const u64 tail = (len & 63) ? (1ULL << (len & 63)) - 1 : ~0ULL;
    u64 cm, nm, qm, cm1 = 0, nm1 = 0, qm1 = 0;
    masks64(base, cm, nm, qm);
    if (nblk == 1) cm &= tail, nm &= tail, qm &= tail;
    sc.spos[-1] = 0xFFFFFFFFu;  // plus one is the first byte of the window
    sc.sflg[-1] = (u8)(FNL | (qm & 1 ? FQA : 0));
    u64 q_before = 0;    // the last byte of the block before was a quote
    u64 sep_before = 1;  // ... was a separator: the newline before the window
    u64 pend_bad = 0;    // a quote touching no separator, waiting for the separator that ends its field
    u32 nn = 0;
    for (u32 b = 0; b < nblk; b++) {
        if (b + 1 < nblk) {
            masks64(base + ((size_t)(b + 1) << 6), cm1, nm1, qm1);
            if (b + 2 == nblk) cm1 &= tail, nm1 &= tail, qm1 &= tail;
        } else {
            cm1 = nm1 = qm1 = 0;
        }
        const u64 sep = cm | nm;
        const u64 qa = sep & ((qm >> 1) | (qm1 << 63));
        const u64 qb = sep & ((qm << 1) | q_before);
        const u64 touching = ((sep << 1) | sep_before) | ((sep >> 1) | ((cm1 | nm1) << 63));
        const u64 inner = qm & ~touching;
        u64 bad = 0;
        if (unlikely((inner | pend_bad) != 0)) {
            u64 s = sep, done = 0;  // done: every bit up to the last separator handled
            bool pend = pend_bad != 0;
            while (s) {
                u32 p = tz64(s);
                u64 upto = (2ULL << p) - 1;
                if (pend || (inner & upto & ~done)) bad |= 1ULL << p;
                pend = false, done = upto;
                s &= s - 1;
            }
            pend_bad = (pend || (inner & ~done)) ? 1 : 0;
        }
        const u32 cnt = (u32)__builtin_popcountll(sep);
        emit_flags(fo, sep, qa, qb, nm, bad, cnt);
        fo += cnt;
        emit_bits(po, sep, b << 6);
        nn += (u32)__builtin_popcountll(nm);
        q_before = qm >> 63, sep_before = sep >> 63;
        cm = cm1, nm = nm1, qm = qm1;
    }
    sc.ns = (u32)(po - sc.spos);
    sc.nn = nn;
    for (int i = 0; i < 16; i++) po[i] = 0xFFFFFFFFu;
    memset(fo, 0, 16);
}

// Field offsets of one row, starts in [0..8) and ends in [8..16), to pointers, then the handler.
template <class H>
static inline void call_row(const u8* base, const u32* q, H& h) {
    alignas(32) const u8* s[8];
    alignas(32) const u8* e[8];
#if defined(__AVX2__)
    const __m256i vb = _mm256_set1_epi64x((long long)(uintptr_t)base);
    const __m256i S = _mm256_loadu_si256((const __m256i*)q), E = _mm256_loadu_si256((const __m256i*)(q + 8));
    _mm256_store_si256((__m256i*)s, _mm256_add_epi64(vb, _mm256_cvtepu32_epi64(_mm256_castsi256_si128(S))));
    _mm256_store_si256((__m256i*)(s + 4), _mm256_add_epi64(vb, _mm256_cvtepu32_epi64(_mm256_extracti128_si256(S, 1))));
    _mm256_store_si256((__m256i*)e, _mm256_add_epi64(vb, _mm256_cvtepu32_epi64(_mm256_castsi256_si128(E))));
    _mm256_store_si256((__m256i*)(e + 4), _mm256_add_epi64(vb, _mm256_cvtepu32_epi64(_mm256_extracti128_si256(E, 1))));
#else
    for (int k = 0; k < 8; k++) s[k] = base + q[k], e[k] = base + q[8 + k];
#endif
    h.row(s, e);
}

// Cuts the lines of a tagged window into fields and calls h.row for each
// well-formed one. Stops at the first line that starts at or after `limit` or
// is not complete in the window. Returns where that line starts.
//
// A handler with a timestamp names its field in H::CLS. The three forms of a
// timestamp come in no order, and a branch on them is wrong for half the rows,
// so the rows are queued by the length of that field (20, 25, anything else)
// and each queue is handed over in one go. Row order means nothing to the
// handlers. A handler with CLS < 0 gets its rows straight away.
template <int NF, class H>
static inline u32 split_tagged(const u8* base, u64 limit, Scan& sc, H& h, bool rows) {
    const u32* P = sc.spos;
    const u8* F = sc.sflg;
    const u32 ns = sc.ns;
    // Flag words hold lanes 0..7 for separators i-1..i+6: lane 0 is the newline
    // before the line, lanes 1..NF its own separators.
    const u64 LANES = NF == 7 ? ~0ULL : (1ULL << (8 * (NF + 1))) - 1;
    const u64 NLM = 0x0404040404040404ULL & LANES;
    const u64 NLEXP = 0x04ULL | (0x04ULL << (8 * NF));
    const u64 QPAIR = 0x0101010101010101ULL & (LANES >> 8);  // lanes 0..NF-1
    const u64 BADM = 0x0808080808080808ULL & LANES & ~0xFFULL;  // lanes 1..NF
    const int CLS = H::CLS;
    const bool queued = CLS >= 0 && !NOQUEUE;
    u32* const Q = sc.rowq;
    u32 qn[3] = {0, 0, 0};
    auto replay = [&](u32 c) {
        const u32* q = Q + (size_t)c * (Scan::QCAP * 16);
        for (u32 r = 0; r < qn[c]; r++, q += 16) call_row(base, q, h);
        qn[c] = 0;
    };
    u32 i = 0, ls = 0;
    while (i < ns) {
        if (unlikely(ls >= limit)) break;
        const u64 f = load64(F + i - 1);
        if (likely((f & NLM) == NLEXP)) {
            // NF fields. Field k opens after separator lane k and ends at lane k+1.
            u64 bad = (((f >> 9) ^ f) & QPAIR) | (f & BADM);
            alignas(32) u32 se[16];
#if defined(__AVX2__)
            const __m256i one = _mm256_set1_epi32(1);
            __m256i p0 = _mm256_loadu_si256((const __m256i*)(P + i - 1));
            __m256i p1 = _mm256_loadu_si256((const __m256i*)(P + i));
            __m256i f0 = _mm256_cvtepu8_epi32(_mm_loadl_epi64((const __m128i*)(F + i - 1)));
            __m256i f1 = _mm256_cvtepu8_epi32(_mm_loadl_epi64((const __m128i*)(F + i)));
            __m256i S = _mm256_add_epi32(_mm256_add_epi32(p0, one), _mm256_and_si256(f0, one));
            __m256i E = _mm256_sub_epi32(p1, _mm256_and_si256(_mm256_srli_epi32(f1, 1), one));
            // A quoted field of one byte: its start passes its end.
            bad |= (u32)_mm256_movemask_ps(_mm256_castsi256_ps(_mm256_cmpgt_epi32(S, E))) & ((1u << NF) - 1);
            _mm256_store_si256((__m256i*)se, S);
            _mm256_store_si256((__m256i*)(se + 8), E);
#else
            const u32* Pm = P + i - 1;  // entry -1 of the first line is the newline before the window
            const u8* Fm = F + i - 1;
            for (int k = 0; k < 8; k++) se[k] = se[8 + k] = 0;
            for (int k = 0; k < NF; k++) {
                u32 S = Pm[k] + 1 + (Fm[k] & 1);
                u32 E = Pm[k + 1] - ((Fm[k + 1] >> 1) & 1);
                bad |= (i32)S > (i32)E;
                se[k] = S, se[8 + k] = E;
            }
#endif
            ls = P[i + NF - 1] + 1, i += NF;
            if (unlikely(bad)) continue;
            if (unlikely(!rows)) continue;
            if (queued) {
                const u32 len = se[8 + (CLS < 0 ? 0 : CLS)] - se[CLS < 0 ? 0 : CLS];
                const u32 c = (u32)(len != 20) + (u32)((len != 20) & (len != 25));
                memcpy(Q + (size_t)c * (Scan::QCAP * 16) + (size_t)qn[c] * 16, se, 64);
                if (unlikely(++qn[c] == Scan::QCAP)) replay(c);
            } else {
                call_row(base, se, h);
            }
        } else {
            // Not NF fields: drop the line. Its newline is the first one in lanes 1..7, or further on.
            const u64 m = f & 0x0404040404040400ULL;
            if (m) {
                u32 k = tz64(m) >> 3;  // 1..7
                i += k;
                ls = P[i - 1] + 1;
            } else {
                u32 j = i + 7;
                while (j < ns && !(F[j] & FNL)) j++;
                if (j >= ns) break;  // the line is not complete in this window
                ls = P[j] + 1, i = j + 1;
            }
        }
    }
    if (queued)
        for (u32 c = 0; c < 3; c++)
            if (qn[c]) replay(c);
    return ls;
}

static inline u32 count_quotes(const u64* qb, u32 a, u32 b) {  // [a, b), b > a
    u32 wa = a >> 6, wb = (b - 1) >> 6;
    u64 ma = ~0ULL << (a & 63), mb = ~0ULL >> (63 - ((b - 1) & 63));
    if (likely(wa == wb)) return (u32)__builtin_popcountll(qb[wa] & ma & mb);
    u32 n = (u32)__builtin_popcountll(qb[wa] & ma) + (u32)__builtin_popcountll(qb[wb] & mb);
    for (u32 w = wa + 1; w < wb; w++) n += (u32)__builtin_popcountll(qb[w]);
    return n;
}

// One line by the plain rules, for the rare lines the window scan cannot take
// (longer than a window, or the last line of a file with no newline).
template <int NF, class H>
static void slow_line(const u8* lb, const u8* le, H& h) {
    const u8* s[NF];
    const u8* e[NF];
    int nf = 0;
    const u8* fs = lb;
    for (const u8* p = lb;; p++) {
        if (p == le || *p == ',') {
            if (nf == NF) return;
            s[nf] = fs, e[nf] = p, nf++;
            if (p == le) break;
            fs = p + 1;
        }
    }
    if (nf != NF) return;
    for (int k = 0; k < NF; k++) {
        size_t nq = 0;
        for (const u8* p = s[k]; p < e[k]; p++) nq += *p == '"';
        if (!nq) continue;
        if (nq != 2 || e[k] - s[k] < 2 || *s[k] != '"' || e[k][-1] != '"') return;
        s[k]++, e[k]--;
    }
    h.row(s, e);
}

// ---- one pass per line (SS_FUSED=1 on, SS_FUSED=0 off; off by default until it is timed on x86)
// The separators of a line are found in the 128 bytes at its start and its fields are cut
// right there: no index of a whole window in between. A line longer than that, and the last
// line of a file with no newline, go to slow_line. Reads up to 128 bytes past the line start:
// every input has zero padding after it, and zero bytes are neither separators nor quotes.
#ifndef SS_FUSED_DEFAULT
#define SS_FUSED_DEFAULT 0  // -DSS_FUSED_DEFAULT=1 turns it on in the build itself (and in its profile run)
#endif
static bool FUSED = SS_FUSED_DEFAULT != 0;

static inline u64 low_bits(u64 x, u32 n) {  // the bits of x below bit n; all of x when n >= 64
#if defined(__BMI2__)
    return _bzhi_u64(x, n);
#else
    return n >= 64 ? x : x & ((1ULL << n) - 1);
#endif
}

template <int NF, class H>
static void fused_range(const u8* buf, u64 fsz, u64 pos, u64 ce, H& h) {
    while (pos < ce) {
        const u8* r = buf + pos;
        u64 cm0, nm0, qm0, cm1, nm1, qm1;
        masks64(r, cm0, nm0, qm0);
        masks64(r + 64, cm1, nm1, qm1);
        if (unlikely((nm0 | nm1) == 0)) {
            const u64 avail = fsz - pos;
            u64 lend = fsz;
            if (avail > 128) {
                const u8* nl = (const u8*)memchr(r + 128, '\n', avail - 128);
                if (nl) lend = (u64)(nl - buf);
            }
            slow_line<NF, H>(r, buf + lend, h);
            pos = lend + 1;
            continue;
        }
        // The line ends at its first newline. Which word holds it is picked without a branch.
        const u32 t0 = tz64(nm0), t1 = tz64(nm1);
        const u32 eol = nm0 ? t0 : 64 + t1;
        const u32 e1 = eol > 64 ? eol - 64 : 0;  // how much of the second word belongs to the line
        const u64 c0 = low_bits(cm0, eol), c1 = low_bits(cm1, e1);
        const u64 q0 = low_bits(qm0, eol), q1 = low_bits(qm1, e1);
        pos += (u64)eol + 1;
        if (unlikely(STAGE == 1)) continue;
        const u32 n0 = (u32)__builtin_popcountll(c0);
        if (unlikely(n0 + (u32)__builtin_popcountll(c1) != (u32)(NF - 1))) continue;  // not NF fields
        // The commas of the first word, then those of the second written over the unused tail.
        u32 cp[2 * NF];
        {
            u64 b = c0;
            for (int k = 0; k < NF - 1; k++) cp[k] = tz64(b), b &= b - 1;
        }
        {
            u64 b = c1;
            for (int k = 0; k < NF - 1; k++) cp[n0 + k] = 64 + tz64(b), b &= b - 1;
        }
        const u8* s[NF];
        const u8* e[NF];
        s[0] = r;
        for (int k = 0; k < NF - 1; k++) e[k] = r + cp[k], s[k + 1] = r + cp[k] + 1;
        e[NF - 1] = r + eol;
        const u32 nq = (u32)__builtin_popcountll(q0) + (u32)__builtin_popcountll(q1);
        if (nq) {
            // Quotes are fine only as the first and last byte of a field, so the wrapped fields
            // must account for every quote in the line.
            u32 nw = 0;
            for (int f = 0; f < NF; f++) {
                u32 w = (e[f] - s[f] >= 2) & (*s[f] == '"') & (e[f][-1] == '"');
                s[f] += w, e[f] -= w, nw += w;
            }
            if (unlikely(2 * nw != nq)) continue;
        }
        if (likely(STAGE != 2)) h.row(s, e);
    }
}

// Calls h.row(starts, ends) for every well-formed line that starts in
// [cs, ce) of the file. The first line of the file is its header.
template <int NF, class H>
static void parse_range(const u8* buf, u64 fsz, u64 cs, u64 ce, Scan& sc, H& h) {
    u64 pos;
    {
        u64 from = cs ? cs - 1 : 0;
        if (from >= fsz) return;
        const u8* nl = (const u8*)memchr(buf + from, '\n', fsz - from);
        if (!nl) return;
        pos = (u64)(nl - buf) + 1;
    }
    if (ce > fsz) ce = fsz;
    if (FUSED) {
        fused_range<NF, H>(buf, fsz, pos, ce, h);
        return;
    }
    while (pos < ce) {
        u32 wlen = (u32)std::min<u64>(WIN, fsz - pos);
        const u8* base = buf + pos;
        if (likely(!OLDSPLIT)) scan_tagged(base, wlen, sc);
        else scan_window(base, wlen, sc);
        if (unlikely(sc.nn == 0)) {
            u64 lend = fsz;
            if (pos + wlen < fsz) {
                const u8* nl = (const u8*)memchr(base + wlen, '\n', fsz - pos - wlen);
                if (nl) lend = (u64)(nl - buf);
            }
            slow_line<NF, H>(base, buf + lend, h);
            pos = lend + 1;
            continue;
        }
        if (likely(!OLDSPLIT)) {
            if (unlikely(STAGE == 1)) {
                u32 j = sc.ns;
                while (!(sc.sflg[j - 1] & FNL)) j--;
                pos += sc.spos[j - 1] + 1;
                continue;
            }
            pos += split_tagged<NF, H>(base, ce - pos, sc, h, STAGE != 2);
            continue;
        }
        if (unlikely(STAGE == 1)) {
            pos += sc.nidx[sc.nn - 1] + 1;
            continue;
        }
        const u32* ci = sc.cidx;
        u64 limit = ce - pos;
        u32 ls = 0, c = 0;
        const u32 nn = sc.nn;
        for (u32 k = 0; k < nn; k++) {
            if (unlikely(ls >= limit)) break;
            u32 nl = sc.nidx[k];
            if (likely(ci[c + NF - 2] < nl && ci[c + NF - 1] > nl)) {
                const u8* s[NF];
                const u8* e[NF];
                u32 fs = ls;
                for (int f = 0; f < NF - 1; f++) {
                    s[f] = base + fs;
                    e[f] = base + ci[c + f];
                    fs = ci[c + f] + 1;
                }
                s[NF - 1] = base + fs;
                e[NF - 1] = base + nl;
                c += NF - 1;
                u32 nq = count_quotes(sc.qb, ls, nl);
                if (nq) {
                    u32 nw = 0;
                    for (int f = 0; f < NF; f++) {
                        u32 w = (e[f] - s[f] >= 2) & (*s[f] == '"') & (e[f][-1] == '"');
                        s[f] += w, e[f] -= w, nw += w;
                    }
                    if (unlikely(2 * nw != nq)) {
                        ls = nl + 1;
                        continue;
                    }
                }
                if (likely(STAGE != 2)) h.row(s, e);
            } else {
                while (ci[c] < nl) c++;
            }
            ls = nl + 1;
        }
        pos += ls;
    }
}

// ---------------------------------------------------------------- arena
struct ChunkMeta {
    u32 part;
    u16 fill;  // bytes used
    u8 stream;
    u8 pad;
};
static u8* ARENA;
static ChunkMeta* META;
static std::atomic<u32> g_next_chunk{0};
static u32 MAX_CHUNKS;

static inline void nt_copy(u8* dst, const u8* src, u32 n) {  // n is a multiple of 64
#if defined(__AVX2__)
    for (u32 i = 0; i < n; i += 32) _mm256_stream_si256((__m256i*)(dst + i), _mm256_load_si256((const __m256i*)(src + i)));
#else
    memcpy(dst, src, n);
#endif
}
static inline void nt_done() {
#if defined(__x86_64__)
    _mm_sfence();
#endif
}

struct TCtx;
static u32 alloc_chunk(TCtx* t);

// Appends fixed-size records to P partitions through small staging buffers.
template <int REC, int UB>
struct Scatter {
    static constexpr int UR = UB / REC;
    static constexpr u32 CAP = (CHUNK / UB) * UB;
    struct Dst {
        u8* cur;
        u32 left;
        u32 chunk;
    };
    u32 P = 0;
    u8 stream = 0;
    TCtx* t = nullptr;
    u8* stage = nullptr;
    u8* fill = nullptr;
    Dst* dst = nullptr;

    void init(u32 P_, u8 stream_, TCtx* t_) {
        P = P_, stream = stream_, t = t_;
        stage = (u8*)aligned_alloc(64, (size_t)P * UB);
        fill = (u8*)calloc(P, 1);
        dst = (Dst*)malloc(sizeof(Dst) * P);
        for (u32 p = 0; p < P; p++) dst[p] = {nullptr, 0, NOCHUNK};
    }
    void release() {
        free(stage), free(fill), free(dst);
        stage = fill = nullptr, dst = nullptr;
    }
    inline u8* slot(u32 p) { return stage + (size_t)p * UB + (size_t)fill[p] * REC; }
    inline void commit(u32 p) {
        if (unlikely(++fill[p] == UR)) flush(p);
    }
    void newchunk(u32 p) {
        Dst& d = dst[p];
        if (d.chunk != NOCHUNK) META[d.chunk].fill = (u16)CAP;
        u32 id = alloc_chunk(t);
        META[id].part = p, META[id].fill = 0, META[id].stream = stream;
        d.cur = ARENA + (size_t)id * CHUNK, d.left = CAP, d.chunk = id;
    }
    inline void flush(u32 p) {
        Dst& d = dst[p];
        if (unlikely(d.left == 0)) newchunk(p);
        nt_copy(d.cur, stage + (size_t)p * UB, UB);
        d.cur += UB, d.left -= UB;
        fill[p] = 0;
    }
    void finish() {
        for (u32 p = 0; p < P; p++) {
            Dst& d = dst[p];
            if (fill[p]) {
                if (d.left == 0) newchunk(p);
                u32 nb = (u32)fill[p] * REC;
                memcpy(d.cur, stage + (size_t)p * UB, nb);
                d.cur += nb, d.left = 0;  // a partly filled unit ends the chunk
                fill[p] = 0;
            }
            if (d.chunk != NOCHUNK) {
                META[d.chunk].fill = (u16)(d.cur - (ARENA + (size_t)d.chunk * CHUNK));
                d = {nullptr, 0, NOCHUNK};
            }
        }
        nt_done();
    }
};

struct ERec {
    u64 ekey;
    u32 ingest;
    u32 person;
    u32 ts;
    u32 aux;
};
struct Purch {
    u64 key;
    u32 aux;
    u32 pad;
};
struct Click {
    u64 key;
    u64 ckey;
};

struct Lists {
    std::vector<u32> start, ids;
    u32 count(u32 p) const { return start[p + 1] - start[p]; }
};
static Lists build_lists(u8 stream, u32 P) {
    Lists L;
    u32 nch = g_next_chunk.load();
    L.start.assign(P + 2, 0);
    for (u32 i = 0; i < nch; i++)
        if (META[i].stream == stream && META[i].fill) L.start[META[i].part + 2]++;
    for (u32 p = 0; p < P; p++) L.start[p + 2] += L.start[p + 1];
    L.ids.resize(L.start[P + 1]);
    for (u32 i = 0; i < nch; i++)
        if (META[i].stream == stream && META[i].fill) L.ids[L.start[META[i].part + 1]++] = i;
    L.start.pop_back();
    return L;
}

// ---------------------------------------------------------------- parquet
struct Buf {
    u8* p = nullptr;
    size_t n = 0, cap = 0;
    inline void ensure(size_t extra) {
        if (unlikely(n + extra > cap)) {
            cap = std::max(cap * 2, n + extra + 4096);
            p = (u8*)realloc(p, cap);
        }
    }
    inline void put(const void* s, size_t len) {
        ensure(len);
        memcpy(p + n, s, len);
        n += len;
    }
    inline void u8v(u8 v) { ensure(1), p[n++] = v; }
    inline void u32v(u32 v) { put(&v, 4); }
    inline void i64v(i64 v) { put(&v, 8); }
    void varint(u64 v) {
        while (v >= 0x80) u8v((u8)(v | 0x80)), v >>= 7;
        u8v((u8)v);
    }
    void zz(i64 v) { varint(((u64)v << 1) ^ (u64)(v >> 63)); }
};

struct Thrift {
    Buf& b;
    int last = 0;
    std::vector<int> stack;
    explicit Thrift(Buf& b_) : b(b_) {}
    void fh(int id, int type) {
        int d = id - last;
        if (d > 0 && d <= 15) b.u8v((u8)((d << 4) | type));
        else b.u8v((u8)type), b.zz(id);
        last = id;
    }
    void i32f(int id, i32 v) { fh(id, 5), b.zz(v); }
    void i64f(int id, i64 v) { fh(id, 6), b.zz(v); }
    void strf(int id, const std::string& s) { fh(id, 8), b.varint(s.size()), b.put(s.data(), s.size()); }
    void listf(int id, int etype, size_t n) {
        fh(id, 9);
        if (n < 15) b.u8v((u8)((n << 4) | etype));
        else b.u8v((u8)(0xF0 | etype)), b.varint(n);
    }
    void open() { stack.push_back(last), last = 0; }
    void openf(int id) { fh(id, 12), open(); }
    void close() { b.u8v(0), last = stack.back(), stack.pop_back(); }
};

enum { PQ_INT32 = 1, PQ_INT64 = 2, PQ_BYTES = 6 };
struct PqCol {
    std::string name;
    int type;
    int conv;  // -1 none, 0 UTF8, 6 DATE
    bool optional;
};
struct PqPart {
    const u8* data;
    size_t len;
    const u8* defbits;  // optional columns: one bit per row, set when not null
};
struct PqFile {
    int fd = -1;
    u64 off = 0, nrows = 0;
    std::vector<PqCol> cols;
    struct CC {
        u64 page_off, size;
    };
    struct RG {
        u64 rows, bytes;
        std::vector<CC> cc;
    };
    std::vector<RG> rgs;

    static void write_all(int fd, iovec* iov, int cnt) {
        while (cnt) {
            ssize_t w = writev(fd, iov, std::min(cnt, 512));
            if (w < 0) {
                if (errno == EINTR) continue;
                die("write failed: %s", strerror(errno));
            }
            size_t left = (size_t)w;
            while (cnt && left >= iov->iov_len) left -= iov->iov_len, iov++, cnt--;
            if (cnt && left) iov->iov_base = (u8*)iov->iov_base + left, iov->iov_len -= left;
        }
    }
    void open(const std::string& path, std::vector<PqCol> c) {
        cols = std::move(c);
        fd = ::open(path.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0666);
        if (fd < 0) die("cannot create %s: %s", path.c_str(), strerror(errno));
        iovec v = {(void*)"PAR1", 4};
        write_all(fd, &v, 1);
        off = 4;
    }
    void row_group(u64 rows, const PqPart* parts) {
        size_t nc = cols.size();
        std::vector<Buf> hdr(nc), lvl(nc);
        std::vector<iovec> iov;
        RG rg;
        rg.rows = rows, rg.bytes = 0;
        u64 at = off;
        for (size_t i = 0; i < nc; i++) {
            size_t body = parts[i].len;
            if (cols[i].optional) {
                size_t nbytes = (size_t)((rows + 7) / 8);
                Buf rle;
                rle.varint(((u64)nbytes << 1) | 1);
                lvl[i].u32v((u32)(rle.n + nbytes));
                lvl[i].put(rle.p, rle.n);
                lvl[i].put(parts[i].defbits, nbytes);
                free(rle.p);
                body += lvl[i].n;
            }
            Thrift t(hdr[i]);
            t.i32f(1, 0);
            t.i32f(2, (i32)body);
            t.i32f(3, (i32)body);
            t.openf(5);
            t.i32f(1, (i32)rows);
            t.i32f(2, 0);
            t.i32f(3, 3);
            t.i32f(4, 3);
            t.close();
            hdr[i].u8v(0);
            u64 size = hdr[i].n + body;
            rg.cc.push_back({at, size});
            rg.bytes += size;
            at += size;
            iov.push_back({hdr[i].p, hdr[i].n});
            if (lvl[i].n) iov.push_back({lvl[i].p, lvl[i].n});
            if (parts[i].len) iov.push_back({(void*)parts[i].data, parts[i].len});
        }
        write_all(fd, iov.data(), (int)iov.size());
        for (size_t i = 0; i < nc; i++) free(hdr[i].p), free(lvl[i].p);
        off = at;
        nrows += rows;
        rgs.push_back(std::move(rg));
    }
    void close() {
        Buf f;
        Thrift t(f);
        t.i32f(1, 1);
        t.listf(2, 12, cols.size() + 1);
        t.open();
        t.strf(4, "schema");
        t.i32f(5, (i32)cols.size());
        t.close();
        for (auto& c : cols) {
            t.open();
            t.i32f(1, c.type);
            t.i32f(3, c.optional ? 1 : 0);
            t.strf(4, c.name);
            if (c.conv >= 0) {
                t.i32f(6, c.conv);
                t.openf(10);
                t.openf(c.conv == 0 ? 1 : 6);
                t.close();
                t.close();
            }
            t.close();
        }
        t.i64f(3, (i64)nrows);
        t.listf(4, 12, rgs.size());
        for (auto& rg : rgs) {
            t.open();
            t.listf(1, 12, cols.size());
            for (size_t i = 0; i < cols.size(); i++) {
                t.open();
                t.i64f(2, (i64)rg.cc[i].page_off);
                t.openf(3);
                t.i32f(1, cols[i].type);
                t.listf(2, 5, 2);
                f.zz(0), f.zz(3);
                t.listf(3, 8, 1);
                f.varint(cols[i].name.size()), f.put(cols[i].name.data(), cols[i].name.size());
                t.i32f(4, 0);
                t.i64f(5, (i64)rg.rows);
                t.i64f(6, (i64)rg.cc[i].size);
                t.i64f(7, (i64)rg.cc[i].size);
                t.i64f(9, (i64)rg.cc[i].page_off);
                t.close();
                t.close();
            }
            t.i64f(2, (i64)rg.bytes);
            t.i64f(3, (i64)rg.rows);
            t.close();
        }
        t.strf(6, "shopping-sessions native");
        f.u8v(0);
        u32 flen = (u32)f.n;
        f.u32v(flen);
        f.put("PAR1", 4);
        iovec v = {f.p, f.n};
        write_all(fd, &v, 1);
        free(f.p);
        ::close(fd);
        fd = -1;
    }
};

static std::string OUT_DIR;

static std::vector<PqCol> user_daily_cols() {
    return {{"user_id", PQ_BYTES, 0, false},  {"day", PQ_INT32, 6, false},          {"sessions", PQ_INT32, -1, false},
            {"events", PQ_INT32, -1, false},  {"revenue_cents", PQ_INT64, -1, false}, {"top_category", PQ_BYTES, 0, true}};
}

static const u32 RG_ROWS = 1 << 17;
struct UDWriter {
    PqFile f;
    bool opened = false;
    int tid = 0;
    Buf uid, day, ses, evs, rev, cat;
    std::vector<u8> defbits;
    u32 rows = 0;
    u64 total = 0;
    void init(int tid_) {
        tid = tid_;
        defbits.assign(RG_ROWS / 8 + 8, 0);
    }
    void flush() {
        if (!rows) return;
        if (!opened) {
            char name[64];
            snprintf(name, sizeof name, "/user_daily/part-%03d.parquet", tid);
            f.open(OUT_DIR + name, user_daily_cols());
            opened = true;
        }
        PqPart parts[6] = {{uid.p, uid.n, nullptr}, {day.p, day.n, nullptr}, {ses.p, ses.n, nullptr},
                           {evs.p, evs.n, nullptr}, {rev.p, rev.n, nullptr}, {cat.p, cat.n, defbits.data()}};
        f.row_group(rows, parts);
        total += rows;
        uid.n = day.n = ses.n = evs.n = rev.n = cat.n = 0;
        memset(defbits.data(), 0, defbits.size());
        rows = 0;
    }
    inline void row(u64 ukey, i32 d, u32 sessions, u32 events, i64 revenue, i32 topcat) {
        if (likely(!(ukey & SLOW))) {
            uid.ensure(16);
            u8* o = uid.p + uid.n;
            size_t len = key_str_fast(ukey, 'u', o + 4);
            u32 l32 = (u32)len;
            memcpy(o, &l32, 4);
            uid.n += 4 + len;
        } else {
            std::string s = g_intern.get(ukey);
            uid.u32v((u32)s.size());
            uid.put(s.data(), s.size());
        }
        day.put(&d, 4);
        ses.put(&sessions, 4);
        evs.put(&events, 4);
        rev.put(&revenue, 8);
        if (topcat >= 0) {
            const std::string& c = CAT_NAME[topcat];
            cat.u32v((u32)c.size());
            cat.put(c.data(), c.size());
            defbits[rows >> 3] |= (u8)(1u << (rows & 7));
        }
        if (++rows == RG_ROWS) flush();
    }
    void close() {
        flush();
        if (opened) f.close();
    }
};

// ---------------------------------------------------------------- threads
struct CampAcc {
    u32 sessions, purchasing, assisted, pad;
    i64 revenue;
};

struct TCtx {
    int tid = 0;
    Scan sc;
    u8* rbuf = nullptr;  // read buffer
    u64 rcap = 0;
    TabCounter tc;
    std::vector<u32> freelist;
    Scatter<24, 192> se;  // events by event partition
    Scatter<16, 64> sk;   // clicks by person bucket
    Scatter<8, 64> sm;    // surviving events by person bucket
    Scatter<16, 64> sp;   // surviving purchases by person bucket
    std::vector<u64> wide;  // purchases when a category does not fit 8 bits
    // dedup
    std::vector<u64> dkeys;
    std::vector<u32> drefs;
    // buckets
    std::vector<u64> A, B;
    std::vector<Purch> PV;
    std::vector<Click> CA, CB2;
    std::vector<CampAcc> cd;
    std::vector<u32> wcnt, wpos, wact;
    std::vector<i64> catsum;
    std::vector<u32> cattouched;
    UDWriter ud;
    u64 n_rows = 0, n_ok = 0, n_surv = 0, n_clicks = 0, n_sessions = 0;
    u64 tk[8] = {0, 0, 0, 0, 0, 0, 0, 0};  // dedup: table, scatter; buckets: gather, sort, purchases, clicks, walk
};
static std::vector<TCtx*> TC;

static u32 alloc_chunk(TCtx* t) {
    if (!t->freelist.empty()) {
        u32 id = t->freelist.back();
        t->freelist.pop_back();
        return id;
    }
    u32 id = g_next_chunk.fetch_add(1, std::memory_order_relaxed);
    if (unlikely(id >= MAX_CHUNKS)) die("record arena exhausted");
    return id;
}

// SS_PIN: thread i stays on the i-th CPU this process may use, cores first and their second
// hyperthreads after. Off unless asked for: the scheduler usually does as well by itself.
static bool PIN = false;
static std::vector<int> PIN_CPUS;
static void pin_init() {
    cpu_set_t set;
    if (sched_getaffinity(0, sizeof set, &set)) return;
    std::vector<std::pair<long, int>> first, rest;  // (core, cpu)
    std::vector<long> seen;
    for (int c = 0; c < CPU_SETSIZE; c++) {
        if (!CPU_ISSET(c, &set)) continue;
        long core = c;
        char path[96];
        snprintf(path, sizeof path, "/sys/devices/system/cpu/cpu%d/topology/core_id", c);
        if (FILE* f = fopen(path, "r")) {
            if (fscanf(f, "%ld", &core) != 1) core = c;
            fclose(f);
        }
        bool again = std::find(seen.begin(), seen.end(), core) != seen.end();
        if (!again) seen.push_back(core);
        (again ? rest : first).push_back({core, c});
    }
    PIN_CPUS.clear();
    for (auto& p : first) PIN_CPUS.push_back(p.second);
    for (auto& p : rest) PIN_CPUS.push_back(p.second);
}
static inline void pin_thread(int i) {
    if (!PIN || PIN_CPUS.empty()) return;
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(PIN_CPUS[(size_t)i % PIN_CPUS.size()], &set);
    sched_setaffinity(0, sizeof set, &set);
}

template <class F>
static void run_threads(F&& f) {
    std::vector<std::thread> th;
    for (int i = 1; i < T; i++)
        th.emplace_back([&f, i] {
            pin_thread(i);
            f(i);
        });
    pin_thread(0);
    f(0);
    for (auto& t : th) t.join();
}

// ---------------------------------------------------------------- inputs
struct MFile {
    const u8* p = nullptr;  // set when the file is memory-mapped (SS_MMAP=1)
    u64 size = 0;
    int fd = -1;  // otherwise it is read in pieces from this descriptor
};
static const u64 PADB = 1 << 16;
static bool USE_MMAP = false;
// How a mapped file is used (SS_MMAP=n). 1: each piece is dropped from the page
// tables by the thread that parsed it, so no file page is left to unmap when the
// process exits. 2: the same, and each piece is first faulted in with one call.
static int MMAP_MODE = 0;
static bool COPY_SLOW = false;  // the startup copy test (in main) found reading slow, so the input is mapped
#ifndef MADV_POPULATE_READ
#define MADV_POPULATE_READ 22
#endif

static MFile map_file(const std::string& path) {
    MFile m;
    int fd = open(path.c_str(), O_RDONLY | O_CLOEXEC);
    if (fd < 0) die("cannot open %s: %s", path.c_str(), strerror(errno));
    struct stat st;
    if (fstat(fd, &st)) die("cannot stat %s", path.c_str());
    m.size = (u64)st.st_size;
    if (m.size && !USE_MMAP) {
        posix_fadvise(fd, 0, 0, POSIX_FADV_SEQUENTIAL);
        m.fd = fd;
        return m;
    }
    if (m.size) {
        u64 rounded = (m.size + 4095) & ~4095ULL;
        u8* r = (u8*)mmap(nullptr, rounded + PADB, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
        if (r == MAP_FAILED) die("mmap failed for %s", path.c_str());
        if (mmap(r, m.size, PROT_READ, MAP_PRIVATE | MAP_FIXED, fd, 0) == MAP_FAILED)
            die("cannot map %s: %s", path.c_str(), strerror(errno));
        m.p = r;
    }
    close(fd);
    return m;
}
// Maps a file that was opened for reading (see the copy test in main).
static void map_open_file(MFile& m) {
    if (m.fd < 0 || !m.size) return;
    u64 rounded = (m.size + 4095) & ~4095ULL;
    u8* r = (u8*)mmap(nullptr, rounded + PADB, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (r == MAP_FAILED) die("mmap failed for an input file");
    if (mmap(r, m.size, PROT_READ, MAP_PRIVATE | MAP_FIXED, m.fd, 0) == MAP_FAILED) die("cannot map an input file: %s", strerror(errno));
    m.p = r;
    close(m.fd);
    m.fd = -1;
}
static std::vector<MFile> map_dir(const std::string& dir, u64& total) {
    std::vector<std::string> names;
    if (DIR* d = opendir(dir.c_str())) {
        while (dirent* e = readdir(d)) {
            std::string n = e->d_name;
            if (n.size() > 4 && n.compare(n.size() - 4, 4, ".csv") == 0) names.push_back(n);
        }
        closedir(d);
    }
    std::sort(names.begin(), names.end());
    std::vector<MFile> out;
    for (auto& n : names) {
        std::string path = dir + "/" + n;
        struct stat st;
        if (stat(path.c_str(), &st) || !S_ISREG(st.st_mode)) continue;
        MFile m = map_file(path);
        total += m.size;
        if (m.size) out.push_back(m);
    }
    return out;
}
static std::string read_small(const std::string& path) {
    int fd = open(path.c_str(), O_RDONLY);
    if (fd < 0) die("cannot open %s: %s", path.c_str(), strerror(errno));
    std::string s;
    char buf[65536];
    ssize_t r;
    while ((r = read(fd, buf, sizeof buf)) > 0) s.append(buf, (size_t)r);
    close(fd);
    return s;
}

struct Work {
    const MFile* f;
    u64 cs, ce;
    u8 kind;  // 0 events, 1 clicks, 2 links
};
static inline void piece_populate(const Work& w) {
    if (MMAP_MODE != 2 || !w.f->p) return;
    u64 a = w.cs & ~4095ULL, b = (std::min(w.f->size, w.ce) + 4095) & ~4095ULL;
    if (b > a) madvise((void*)(w.f->p + a), b - a, MADV_POPULATE_READ);
}
static inline void piece_drop(const Work& w) {
    if (!w.f->p) return;
    // Only the pages that lie wholly inside the piece: its neighbours read the edges.
    // The pages stay in the page cache, so a neighbour reading across an edge only takes a fault.
    u64 a = (w.cs + 4095) & ~4095ULL, b = std::min(w.f->size, w.ce) & ~4095ULL;
    if (b > a) madvise((void*)(w.f->p + a), b - a, MADV_DONTNEED);
}
static void add_work(std::vector<Work>& w, const std::vector<MFile>& files, u8 kind, u64 step) {
    if (!USE_MMAP) step = 128 << 10;  // small pieces, so the read buffer stays in cache
    for (auto& f : files)
        for (u64 at = 0; at < f.size; at += step) w.push_back({&f, at, std::min(f.size, at + step), kind});
}

// The bytes a piece of work needs, as (buf, len) and the piece's range inside
// it. A mapped file is used in place. Otherwise the piece is read into the
// thread's buffer, from one byte before it (to see whether a line starts at its
// first byte) to the end of the last line that starts in it.
static bool NOSKEW = false;
static void work_view(TCtx& t, const Work& w, const u8*& buf, u64& len, u64& cs, u64& ce) {
    const MFile& f = *w.f;
    if (f.p) {
        buf = f.p, len = f.size, cs = w.cs, ce = w.ce;
        return;
    }
    const u64 from = w.cs ? w.cs - 1 : 0;
    // The data lands at the same offset inside a page as it has in the file. A piece
    // starts one byte before a page boundary, and with a page-aligned buffer the kernel
    // would copy every page to an address one byte off: measured three times slower in
    // the kernel on AMD Zen 3 and Zen 4. SS_NOSKEW: the buffer's first byte, as before.
    const u64 skew = NOSKEW ? 0 : (from & 4095);
    u64 slack = 4096;
    for (;;) {
        u64 to = std::min(f.size, w.ce + slack);
        u64 need = to - from;
        if (t.rcap < need + skew + 256) {
            free(t.rbuf);
            t.rcap = ((need + 4096 + 256 + need / 8) + 4095) & ~(u64)4095;
            t.rbuf = (u8*)aligned_alloc(4096, t.rcap);
        }
        u8* const dst = t.rbuf + skew;
        u64 got = 0;
        while (got < need) {
            ssize_t r = pread(f.fd, dst + got, need - got, (off_t)(from + got));
            if (r < 0) {
                if (errno == EINTR) continue;
                die("read failed: %s", strerror(errno));
            }
            if (r == 0) die("a file shrank while it was read");
            got += (u64)r;
        }
        memset(dst + need, 0, 256);
        u64 tail = w.ce - 1 - from;  // the last line of the piece ends at or after this byte
        if (to == f.size || memchr(dst + tail, '\n', need - tail)) {
            buf = dst, len = need, cs = w.cs ? 1 : 0, ce = w.ce - from;
            return;
        }
        slack *= 16;
    }
}

// ---------------------------------------------------------------- lookups from files
struct PairRows {
    std::vector<std::pair<std::string, std::string>> rows;
    void row(const u8** s, const u8** e) {
        rows.emplace_back(std::string((const char*)s[0], e[0] - s[0]), std::string((const char*)s[1], e[1] - s[1]));
    }
};
static PairRows read_pairs(const std::string& path) {
    std::string raw = read_small(path);
    size_t n = raw.size();
    raw.append(128, '\0');
    PairRows pr;
    const u8* b = (const u8*)raw.data();
    size_t pos = 0;
    bool header = true;
    while (pos < n) {
        const u8* nl = (const u8*)memchr(b + pos, '\n', n - pos);
        size_t end = nl ? (size_t)(nl - b) : n;
        if (!header) slow_line<2, PairRows>(b + pos, b + end, pr);
        header = false;
        pos = end + 1;
    }
    return pr;
}
static void load_products(const std::string& dir) {
    PairRows pr = read_pairs(dir + "/products.csv");
    std::unordered_map<std::string, u32> cats;
    std::vector<std::pair<std::string, u32>> prods;
    for (auto& r : pr.rows) {
        if (r.first.empty()) continue;
        auto it = cats.find(r.second);
        u32 c;
        if (it == cats.end()) c = (u32)CAT_NAME.size(), cats.emplace(r.second, c), CAT_NAME.push_back(r.second);
        else c = it->second;
        prods.emplace_back(r.first, c);
    }
    NCAT = (u32)CAT_NAME.size();
    CAT_NAME.push_back("unknown");
    WIDE_CAT = NCAT + 1 > 256;
    std::vector<u32> order(NCAT + 1);
    for (u32 i = 0; i <= NCAT; i++) order[i] = i;
    std::sort(order.begin(), order.end(), [](u32 a, u32 b) { return CAT_NAME[a] < CAT_NAME[b]; });
    CAT_RANK.resize(NCAT + 1);
    for (u32 i = 0; i <= NCAT; i++) CAT_RANK[order[i]] = i;
    for (auto& p : prods) {
        u32 num;
        std::string padded = p.first + std::string(16, '\0');
        const u8* s = (const u8*)padded.data();
        if (p.first.size() >= 2 && s[0] == 'p' && canon_num(s + 1, p.first.size() - 1, num)) {
            if (num >= PROD_DIRECT.size()) PROD_DIRECT.resize((size_t)num + 1, NCAT);
            PROD_DIRECT[num] = p.second;
        } else {
            PROD_MAP.emplace(p.first, p.second);
        }
    }
}
static void load_campaigns(const std::string& dir) {
    PairRows pr = read_pairs(dir + "/campaigns.csv");
    for (auto& r : pr.rows) {
        if (r.first.empty()) continue;
        u32 idx = (u32)CAMP_NAME.size();
        u32 num;
        std::string padded = r.first + std::string(16, '\0');
        const u8* s = (const u8*)padded.data();
        if (r.first.size() >= 3 && s[0] == 'c' && s[1] == '_' && canon_num(s + 2, r.first.size() - 2, num)) {
            if (num >= CAMP_DIRECT.size()) CAMP_DIRECT.resize((size_t)num + 1, -1);
            if (CAMP_DIRECT[num] >= 0) continue;
            CAMP_DIRECT[num] = (i32)idx;
        } else {
            if (!CAMP_MAP.emplace(r.first, idx).second) continue;
        }
        CAMP_NAME.push_back(r.first);
        CAMP_CHANNEL.push_back(r.second);
    }
    NCAMP = (u32)CAMP_NAME.size();
    CAMP_NAME.push_back("organic");
    CAMP_CHANNEL.push_back("organic");
}
static i64 manifest_ts(const std::string& js, const char* key) {
    size_t k = js.find(std::string("\"") + key + "\"");
    if (k == std::string::npos) die("manifest.json has no %s", key);
    size_t colon = js.find(':', k);
    size_t q1 = js.find('"', colon + 1);
    size_t q2 = js.find('"', q1 + 1);
    if (colon == std::string::npos || q1 == std::string::npos || q2 == std::string::npos) die("bad manifest.json");
    std::string v = js.substr(q1 + 1, q2 - q1 - 1);
    std::string padded = v + std::string(64, '\0');
    i64 t = parse_ts((const u8*)padded.data(), v.size());
    if (t == BAD_TS) die("bad %s in manifest.json", key);
    return t;
}

// ---------------------------------------------------------------- row handlers
static const int BATCH = 16;

// Links are looked up in batches too: the table is far larger than the cache,
// so each line's two slots, and then the two slots' parents, are fetched while
// the lines before them are still being joined.
struct LinkH {
    static constexpr int CLS = -1;
    TCtx& t;
    struct Item {
        u64 ka, kb, ha, hb;
    } items[BATCH];
    int n = 0;
    explicit LinkH(TCtx& t_) : t(t_) {}
    inline void flush() {
        u32 sa[BATCH], sb[BATCH];
        for (int i = 0; i < n; i++) {
            Item& it = items[i];
            sa[i] = tab_slot(it.ka, it.ha, t.tc);
            sb[i] = it.ka == it.kb ? sa[i] : tab_slot(it.kb, it.hb, t.tc);
        }
        if (unlikely(g_overflow.load(std::memory_order_relaxed))) {
            n = 0;
            return;
        }
        for (int i = 0; i < n; i++) {
            u32 pa = __atomic_load_n(&TAB[sa[i]].parent, __ATOMIC_RELAXED);
            u32 pb = __atomic_load_n(&TAB[sb[i]].parent, __ATOMIC_RELAXED);
            if (pa) __builtin_prefetch(&TAB[pa - 1]);
            if (pb) __builtin_prefetch(&TAB[pb - 1]);
        }
        for (int i = 0; i < n; i++)
            if (sa[i] != sb[i]) uf_union(sa[i], sb[i]);
        n = 0;
    }
    ROW_INLINE inline void row(const u8** s, const u8** e) {
        size_t la = (size_t)(e[0] - s[0]), lb = (size_t)(e[1] - s[1]);
        if (!la || !lb) return;
        Item& it = items[n];
        it.ka = id_key(s[0], la, 'u'), it.kb = id_key(s[1], lb, 'u');
        it.ha = tab_home(it.ka), it.hb = tab_home(it.kb);
        __builtin_prefetch(&TAB[it.ha], 1);
        __builtin_prefetch(&TAB[it.ha + 1], 1);
        __builtin_prefetch(&TAB[it.hb], 1);
        __builtin_prefetch(&TAB[it.hb + 1], 1);
        if (++n == BATCH) flush();
    }
};

struct EventH {
    static constexpr int CLS = 2;  // ts
    TCtx& t;
    struct Item {
        u64 ekey, ukey, home;
        u32 ingest, ts, aux;
    } items[BATCH];
    int n = 0;
    explicit EventH(TCtx& t_) : t(t_) {}

    inline void emit(u64 ekey, u32 ingest, u32 person, u32 ts, u32 aux) {
        u32 p = (u32)(hash1(ekey) >> (64 - PEB));
        ERec* r = (ERec*)t.se.slot(p);
        r->ekey = ekey, r->ingest = ingest, r->person = person, r->ts = ts, r->aux = aux;
        t.se.commit(p);
    }
    inline void flush() {
        for (int i = 0; i < n; i++) {
            Item& it = items[i];
            u32 person = tab_person(tab_slot(it.ukey, it.home, t.tc));
            if (unlikely(STAGE == 4)) {
                t.n_surv += person & 1;
                continue;
            }
            emit(it.ekey, it.ingest, person, it.ts, it.aux);
        }
        n = 0;
    }
    ROW_INLINE inline void row(const u8** s, const u8** e) {
        size_t l0 = (size_t)(e[0] - s[0]);
        if (unlikely(!l0)) return;
        t.n_rows++;
        u64 ekey = id_key(s[0], l0, 'e');
        i64 isec = 0;
        bool ok = (e[3] - s[3] == 20) && s[3][19] == 'Z' && parse_dt19(s[3], isec);
        if (unlikely(!ok)) isec = INT64_MAX / 4096;
        i64 irel = isec - ING_BASE;
        u32 ingest = irel < 0 ? 0 : irel > 0xFFFFFFFFLL ? 0xFFFFFFFFu : (u32)irel;
        size_t l1 = (size_t)(e[1] - s[1]);
        i64 ts = parse_ts(s[2], (size_t)(e[2] - s[2]));
        ok &= l1 != 0;
        ok &= (ts >= WS) & (ts < WE);
        size_t l4 = (size_t)(e[4] - s[4]);
        // view or cart is a coin toss per row and only "one of the two" matters, so it is one
        // flag without a branch. The loads may run past a short field: every input is padded.
        const u32 w4 = load32(s[4]);
        const bool viewcart = (l4 == 4) & ((w4 == 0x77656976u) | (w4 == 0x74726163u));
        const bool purchase = (l4 == 8) & (load64(s[4]) == 0x6573616863727570ULL);
        ok &= viewcart | purchase;
        size_t l5 = (size_t)(e[5] - s[5]);
        ok &= l5 != 0;
        ok &= ((i64)((u64)isec * 1000 - (u64)ts) <= DAYMS);
        u32 aux = 0;
        if (unlikely(purchase) && ok) {
            u64 price;
            if (parse_digits(s[6], (size_t)(e[6] - s[6]), price) && price - 1 < 10000000) {
                u32 cat = product_cat(s[5], l5);
                if (likely(!WIDE_CAT)) {
                    aux = ((u32)price << 8) | cat;
                } else {
                    t.wide.push_back(price | ((u64)cat << 32));
                    if (t.wide.size() >= (1u << 27)) die("too many purchases for wide categories");
                    aux = ((u32)t.tid << 27) | (u32)t.wide.size();
                }
            } else {
                ok = false;
            }
        }
        if (unlikely(STAGE == 3)) {
            t.n_ok += ok + (aux & 1) + (ekey & 1) + (ingest & 1);
            return;
        }
        if (unlikely(!ok)) {
            emit(ekey, ingest, INVALID, 0, 0);
            return;
        }
        t.n_ok++;
        u64 ukey = id_key(s[1], l1, 'u');
        u64 home = tab_home(ukey);
        __builtin_prefetch(&TAB[home]);
        __builtin_prefetch(&TAB[home + 1]);  // the next slot is on another cache line one time in four
        Item& it = items[n];
        it.ekey = ekey, it.ukey = ukey, it.home = home, it.ingest = ingest, it.ts = (u32)(ts - WS), it.aux = aux;
        if (++n == BATCH) flush();
    }
};

struct ClickH {
    static constexpr int CLS = 3;  // ts
    TCtx& t;
    struct Item {
        u64 ckey, ukey, home;
        u32 ts, camp;
    } items[BATCH];
    int n = 0;
    explicit ClickH(TCtx& t_) : t(t_) {}
    inline void flush() {
        for (int i = 0; i < n; i++) {
            Item& it = items[i];
            u32 person = tab_person(tab_slot(it.ukey, it.home, t.tc));
            u32 b = person >> LW;
            u64 local = person & ((1u << LW) - 1);
            Click* c = (Click*)t.sk.slot(b);
            c->key = (((local << 31) | it.ts) << CBITS) | it.camp;
            c->ckey = it.ckey;
            t.sk.commit(b);
        }
        n = 0;
    }
    ROW_INLINE inline void row(const u8** s, const u8** e) {
        size_t l0 = (size_t)(e[0] - s[0]), l1 = (size_t)(e[1] - s[1]);
        if (unlikely(!l0 || !l1)) return;
        i64 ts = parse_ts(s[3], (size_t)(e[3] - s[3]));
        if (unlikely(ts < CWS || ts >= WE)) return;  // BAD_TS is below every window
        i32 camp = campaign_idx(s[2], (size_t)(e[2] - s[2]));
        if (unlikely(camp < 0)) return;
        t.n_clicks++;
        u64 ukey = id_key(s[1], l1, 'u');
        u64 home = tab_home(ukey);
        __builtin_prefetch(&TAB[home]);
        __builtin_prefetch(&TAB[home + 1]);  // the next slot is on another cache line one time in four
        Item& it = items[n];
        it.ckey = id_key(s[0], l0, 'k'), it.ukey = ukey, it.home = home, it.ts = (u32)(ts - CWS), it.camp = (u32)camp;
        if (++n == BATCH) flush();
    }
};

// ---------------------------------------------------------------- sorting
static const int RB = 11;
template <class R>
static R* radix_sort(R* a, R* b, size_t n, int lo, int hi) {
    if (n < 2) return a;
    if (n < 96) {
        std::sort(a, a + n, [](const R& x, const R& y) { return *(const u64*)&x < *(const u64*)&y; });
        return a;
    }
    int np = (hi - lo + RB - 1) / RB;
    if (np > 6) np = 6;
    static thread_local u32 hist[6][1 << RB];
    memset(hist, 0, sizeof(u32) * (size_t)np * (1 << RB));
    const u64 DM = (1 << RB) - 1;
    if (likely(np == 4)) {
        // Events and clicks both sort on 37 to 44 bits, so four passes is the usual case. Written
        // out, the count takes half the instructions of the loop over the passes below.
        u32 *h0 = hist[0], *h1 = hist[1], *h2 = hist[2], *h3 = hist[3];
        for (size_t i = 0; i < n; i++) {
            const u64 k = *(const u64*)&a[i] >> lo;
            h0[k & DM]++, h1[(k >> RB) & DM]++, h2[(k >> (2 * RB)) & DM]++, h3[(k >> (3 * RB)) & DM]++;
        }
    } else {
        for (size_t i = 0; i < n; i++) {
            u64 k = *(const u64*)&a[i] >> lo;
            for (int p = 0; p < np; p++) hist[p][(k >> (p * RB)) & DM]++;
        }
    }
    for (int p = 0; p < np; p++) {
        u32* h = hist[p];
        int sh = lo + p * RB;
        if (h[(*(const u64*)&a[0] >> sh) & ((1 << RB) - 1)] == n) continue;
        u32 sum = 0;
        for (int d = 0; d < (1 << RB); d++) {
            u32 c = h[d];
            h[d] = sum;
            sum += c;
        }
        for (size_t i = 0; i < n; i++) {
            u64 k = *(const u64*)&a[i];
            b[h[(k >> sh) & ((1 << RB) - 1)]++] = a[i];
        }
        std::swap(a, b);
    }
    return a;
}

// A session needs its events grouped, not ordered. Slots of 2^20 ms (17.5 minutes) are
// shorter than the 30-minute gap, so the events of one slot always share a session, and
// only the step from one slot's latest event to the next slot's earliest can end one.
// Sorting by (person, slot) takes two passes of 12 bits where (person, ms) took four of 11.
// Measured on x86: the sort gets 43% cheaper and the walk over unsorted slots pays it
// all back, so the events are sorted by millisecond unless SS_SLOTSORT is set.
static bool FULLSORT = true;
static const int SLOTB = 20;
static u64* sort_slots(u64* a, u64* b, size_t n) {
    if (n < 2) return a;
    if (n < 96) {
        std::sort(a, a + n, [](u64 x, u64 y) { return (x >> SLOTB) < (y >> SLOTB); });
        return a;
    }
    static thread_local u32 h0[4096], h1[4096];
    memset(h0, 0, sizeof h0), memset(h1, 0, sizeof h1);
    for (size_t i = 0; i < n; i++) {
        u64 k = a[i] >> SLOTB;
        h0[k & 4095]++, h1[(k >> 12) & 4095]++;
    }
    u32 s0 = 0, s1 = 0;
    for (int d = 0; d < 4096; d++) {
        u32 c0 = h0[d], c1 = h1[d];
        h0[d] = s0, h1[d] = s1;
        s0 += c0, s1 += c1;
    }
    for (size_t i = 0; i < n; i++) {
        u64 k = a[i];
        b[h0[(k >> SLOTB) & 4095]++] = k;
    }
    for (size_t i = 0; i < n; i++) {
        u64 k = b[i];
        a[h1[(k >> (SLOTB + 12)) & 4095]++] = k;
    }
    return a;
}

// ---------------------------------------------------------------- phases
static Lists L_EREC, L_MAIN, L_PURCH, L_CLICK;

static inline void decode_aux(u32 aux, u32& price, u32& cat) {
    if (likely(!WIDE_CAT)) {
        price = aux >> 8, cat = aux & 255;
    } else {
        u64 v = TC[aux >> 27]->wide[(aux & ((1u << 27) - 1)) - 1];
        price = (u32)v, cat = (u32)(v >> 32);
    }
}

static void dedup_partition(TCtx& t, u32 part) {
    u32 c0 = L_EREC.start[part], c1 = L_EREC.start[part + 1];
    if (c0 == c1) return;
    const u32* ids = L_EREC.ids.data() + c0;
    u32 nch = c1 - c0;
    size_t n = 0;
    for (u32 i = 0; i < nch; i++) n += META[ids[i]].fill / sizeof(ERec);
    size_t S = 1024;
    while (S < 2 * n) S <<= 1;
    if (t.dkeys.size() < S) t.dkeys.resize(S), t.drefs.resize(S);
    u64* keys = t.dkeys.data();
    u32* refs = t.drefs.data();
    memset(keys, 0, S * 8);
    size_t mask = S - 1;
    const int dshift = 64 - __builtin_ctzll((u64)S);
    auto rec = [&](u32 ref) -> ERec* { return (ERec*)(ARENA + (size_t)ids[ref >> 10] * CHUNK) + (ref & 1023); };
    u64 tk0 = VERBOSE ? ticks() : 0;
    for (u32 i = 0; i < nch; i++) {
        ERec* r = (ERec*)(ARENA + (size_t)ids[i] * CHUNK);
        u32 cnt = META[ids[i]].fill / sizeof(ERec);
        for (u32 j = 0; j < cnt; j++) {
            u64 k = r[j].ekey;
            size_t s = (size_t)((hash1(k) << PEB) >> dshift);  // the bits below the ones that chose the partition
            {
                // Nearly every event is new and lands in its home slot or the next one. Which
                // of the two is a coin toss, so both are looked at before the one branch that
                // is almost always taken, and the slot is picked without a branch.
                const size_t s1 = (s + 1) & mask;
                const u64 x0 = keys[s], x1 = keys[s1];
                if (likely((x0 != k) & (x1 != k) & ((x0 == 0) | (x1 == 0)))) {
                    const size_t at = s1 ^ ((s ^ s1) & (0 - (size_t)(x0 == 0)));  // s when it is free
                    keys[at] = k, refs[at] = (i << 10) | j;
                    continue;
                }
            }
            for (;;) {
                u64 x = keys[s];
                if (x == 0) {
                    keys[s] = k, refs[s] = (i << 10) | j;
                    break;
                }
                if (x == k) {
                    ERec* old = rec(refs[s]);
                    if (r[j].ingest < old->ingest) old->person = DEAD, refs[s] = (i << 10) | j;
                    else r[j].person = (r[j].person == INVALID ? INVALID : DEAD);
                    break;
                }
                s = (s + 1) & mask;
            }
        }
    }
    u32 lmask = (1u << LW) - 1;
    (void)lmask;
    u64 tk1 = VERBOSE ? ticks() : 0;
    for (u32 i = 0; i < nch; i++) {
        ERec* r = (ERec*)(ARENA + (size_t)ids[i] * CHUNK);
        u32 cnt = META[ids[i]].fill / sizeof(ERec);
        for (u32 j = 0; j < cnt; j++) {
            u32 person = r[j].person;
            if (person >= DEAD) continue;
            u32 b = person >> LW;
            u64 key = ((u64)person << 31) | r[j].ts;
            *(u64*)t.sm.slot(b) = key;
            t.sm.commit(b);
            if (unlikely(r[j].aux)) {
                Purch* pu = (Purch*)t.sp.slot(b);
                pu->key = key, pu->aux = r[j].aux, pu->pad = 0;
                t.sp.commit(b);
            }
            t.n_surv++;
        }
    }
    for (u32 i = 0; i < nch; i++) {
        META[ids[i]].stream = ST_FREE, META[ids[i]].fill = 0;
        t.freelist.push_back(ids[i]);
    }
    if (VERBOSE) t.tk[0] += tk1 - tk0, t.tk[1] += ticks() - tk1;
}

template <class R>
static size_t gather(const Lists& L, u32 b, std::vector<R>& out) {
    u32 c0 = L.start[b], c1 = L.start[b + 1];
    size_t bytes = 0;
    for (u32 i = c0; i < c1; i++) bytes += META[L.ids[i]].fill;
    size_t n = bytes / sizeof(R);
    if (out.size() < n) out.resize(n + n / 4 + 64);
    u8* o = (u8*)out.data();
    for (u32 i = c0; i < c1; i++) {
        u32 f = META[L.ids[i]].fill;
        memcpy(o, ARENA + (size_t)L.ids[i] * CHUNK, f);
        o += f;
    }
    return n;
}

static void process_bucket(TCtx& t, u32 b) {
    u64 tk0 = VERBOSE ? ticks() : 0;
    size_t n = gather(L_MAIN, b, t.A);
    if (!n) return;
    if (t.B.size() < t.A.size()) t.B.resize(t.A.size());
    u64 tk1 = VERBOSE ? ticks() : 0;
    const bool slots = !FULLSORT && 31 + (int)LW <= SLOTB + 24;
    const u64* K = slots ? sort_slots(t.A.data(), t.B.data(), n) : radix_sort<u64>(t.A.data(), t.B.data(), n, 0, 31 + (int)LW);
    u64 tk2 = VERBOSE ? ticks() : 0;

    size_t m = gather(L_PURCH, b, t.PV);
    Purch* PR = t.PV.data();
    if (m > 1) std::sort(PR, PR + m, [](const Purch& x, const Purch& y) { return x.key < y.key; });

    u64 tk3 = VERBOSE ? ticks() : 0;
    size_t c = gather(L_CLICK, b, t.CA);
    if (t.CB2.size() < t.CA.size()) t.CB2.resize(t.CA.size());
    const Click* C = radix_sort<Click>(t.CA.data(), t.CB2.data(), c, (int)CBITS, (int)(CBITS + 31 + LW));

    const u32 lmask = (1u << LW) - 1, cmask = (1u << CBITS) - 1;
    const int csh = 31 + (int)CBITS;
    const u32 ncampx = NCAMP + 1;
    CampAcc* cd = t.cd.data();
    u32* wcnt = t.wcnt.data();
    u32* wpos = t.wpos.data();
    u32* wact = t.wact.data();
    i64* catsum = t.catsum.data();
    auto cts = [&](size_t i) -> u32 { return (u32)(C[i].key >> CBITS) & 0x7FFFFFFFu; };
    auto ccamp = [&](size_t i) -> u32 { return (u32)C[i].key & cmask; };

    u64 tk4 = VERBOSE ? ticks() : 0;
    size_t i = 0, ip = 0, ic = 0;
    while (i < n) {
        const u32 person = (u32)(K[i] >> 31);
        const u64 local = person & lmask;
        while (ic < c && (C[ic].key >> csh) < local) ic++;
        size_t lo = ic, hi = ic;
        while (ic < c && (C[ic].key >> csh) == local) ic++;
        const size_t cend = ic;
        u32 nact = 0;

        i64 cur_day = INT64_MIN;
        u32 d_sessions = 0, d_events = 0;
        i64 d_rev = 0;
        u32 ntouched = 0;
        auto flush_day = [&]() {
            i32 top = -1;
            if (ntouched) {
                u32 best = t.cattouched[0];
                for (u32 q = 1; q < ntouched; q++) {
                    u32 x = t.cattouched[q];
                    if (catsum[x] > catsum[best] || (catsum[x] == catsum[best] && CAT_RANK[x] < CAT_RANK[best])) best = x;
                }
                top = (i32)best;
                for (u32 q = 0; q < ntouched; q++) catsum[t.cattouched[q]] = 0;
                ntouched = 0;
            }
            t.ud.row(TAB[person].key, (i32)cur_day, d_sessions, d_events, d_rev, top);
            d_sessions = d_events = 0, d_rev = 0;
        };

        while (i < n && (u32)(K[i] >> 31) == person) {
            u32 start = (u32)K[i] & 0x7FFFFFFFu;
            u32 prev = start, cnt = 1;
            if (likely(slots)) {
                // The session's first slot: its earliest event starts the session.
                const u64 g0 = K[i] >> SLOTB;
                i++;
                while (i < n && (K[i] >> SLOTB) == g0) {
                    u32 x = (u32)K[i] & 0x7FFFFFFFu;
                    start = std::min(start, x), prev = std::max(prev, x), cnt++, i++;
                }
                // Later slots join while their earliest event is within the gap of the latest so far.
                while (i < n && (u32)(K[i] >> 31) == person) {
                    const u64 g = K[i] >> SLOTB;
                    u32 mn = (u32)K[i] & 0x7FFFFFFFu, mx = mn;
                    size_t j = i + 1;
                    while (j < n && (K[j] >> SLOTB) == g) {
                        u32 x = (u32)K[j] & 0x7FFFFFFFu;
                        mn = std::min(mn, x), mx = std::max(mx, x), j++;
                    }
                    if (mn - prev > GAPMS) break;  // this slot opens the next session
                    cnt += (u32)(j - i), prev = mx, i = j;
                }
            } else {
                i++;
                while (i < n && (u32)(K[i] >> 31) == person) {
                    u32 x = (u32)K[i] & 0x7FFFFFFFu;
                    if (x - prev > GAPMS) break;
                    prev = x, cnt++, i++;
                }
            }
            const i64 day = DAY0 + (i64)(((u64)start + WS_OFF) / (u64)DAYMS);
            if (day != cur_day) {
                if (cur_day != INT64_MIN) flush_day();
                cur_day = day;
            }
            i64 rev = 0;
            u32 npurch = 0;
            const u64 last_key = ((u64)person << 31) | prev;
            while (ip < m && PR[ip].key <= last_key) {
                u32 price, cat;
                decode_aux(PR[ip].aux, price, cat);
                rev += price;
                if (catsum[cat] == 0) t.cattouched[ntouched++] = cat;
                catsum[cat] += price;
                npurch++, ip++;
            }
            d_sessions++, d_events += cnt, d_rev += rev;
            t.n_sessions++;

            // Clicks are kept on a clock that starts 7 days before the window.
            const u32 s_click = start + (u32)WEEKMS;
            while (hi < cend && cts(hi) <= s_click) {
                u32 a = ccamp(hi);
                if (wcnt[a]++ == 0) wpos[a] = nact, wact[nact++] = a;
                hi++;
            }
            while (lo < hi && cts(lo) < start) {
                u32 a = ccamp(lo);
                if (--wcnt[a] == 0) {
                    u32 p = wpos[a], lastc = wact[--nact];
                    wact[p] = lastc, wpos[lastc] = p;
                }
                lo++;
            }
            u32 camp = NCAMP;
            if (hi > lo) {
                size_t best = hi - 1;
                const u32 tt = cts(best);
                for (size_t q = hi - 1; q-- > lo && cts(q) == tt;)
                    if (id_less(C[q].ckey, C[best].ckey, 'k')) best = q;
                camp = ccamp(best);
            }
            CampAcc* row = cd + (size_t)(day - DAY0) * ncampx;
            row[camp].sessions++;
            row[camp].purchasing += npurch > 0;
            row[camp].revenue += rev;
            for (u32 q = 0; q < nact; q++) row[wact[q]].assisted++;
        }
        flush_day();
        for (u32 q = 0; q < nact; q++) wcnt[wact[q]] = 0;
    }
    if (VERBOSE) {
        u64 tk5 = ticks();
        t.tk[2] += tk1 - tk0, t.tk[3] += tk2 - tk1, t.tk[4] += tk3 - tk2, t.tk[5] += tk4 - tk3, t.tk[6] += tk5 - tk4;
    }
}

// ---------------------------------------------------------------- run
static std::vector<MFile> F_EVENTS, F_CLICKS, F_LINKS;
static std::thread g_products_thread;  // products.csv loads while the links are joined
static u64 B_EVENTS, B_CLICKS, B_LINKS;

// Huge pages. 0: ask where they are cheap (huge_pages_cheap below), 1: never (SS_NOHUGE),
// 2: always (SS_HUGE). The probe's benchmark sets this for each run.
static int HUGE_MODE = 0;
#ifdef SS_PROBE
static bool PROBE_CHILD = false;  // a benchmark run in its own process: it exits like the real entry
#endif
static int FORCE_PEB = 0;    // SS_PEB: log2 of the event partitions, 4 to 13

// ---- huge pages, only where they are cheap
// With transparent huge pages set to "madvise", asking for them also lets the
// kernel compact memory inside the page fault. Where memory is fragmented that
// costs milliseconds for every 2 MB (measured: 4 ms each on one cloud machine,
// 0.1 ms on others), far more than huge pages save. So before asking, look at
// how much memory is free in blocks of 2 MB or more, and time a few real faults.
static bool HUGE_OK = true;
static u64 mono_ns() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}
// Bytes free in blocks of 2 MB and larger. False when the kernel does not say.
static bool free_big_bytes(u64& total) {
    FILE* f = fopen("/proc/buddyinfo", "r");
    if (!f) return false;
    char line[2048];
    bool any = false;
    total = 0;
    while (fgets(line, sizeof line, f)) {
        char* p = strstr(line, "zone");
        if (!p) continue;
        p += 4;
        while (*p == ' ') p++;
        while (*p && *p != ' ') p++;  // the zone's name
        for (int order = 0;; order++) {
            char* end;
            unsigned long long v = strtoull(p, &end, 10);
            if (end == p) break;
            if (order >= 9) total += (u64)v << (order + 12);
            p = end, any = true;
        }
    }
    fclose(f);
    return any;
}
static bool huge_pages_cheap(u64 need) {
    u64 big = 0;
    const bool known = free_big_bytes(big);
    const size_t two = 2u << 20, n = 8 * two;
    int slow = 0;
    u64 worst = 0;
    u8* p = (u8*)mmap(nullptr, n + two, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (p != MAP_FAILED) {
        u8* a = (u8*)(((uintptr_t)p + two - 1) & ~(uintptr_t)(two - 1));
#ifdef MADV_HUGEPAGE
        madvise(a, n, MADV_HUGEPAGE);
#endif
        for (int i = 0; i < 8; i++) {
            u64 t0 = mono_ns();
            *(volatile u8*)(a + (size_t)i * two) = 1;
            u64 dt = mono_ns() - t0;
            slow += dt > 1000000, worst = std::max(worst, dt);
        }
        munmap(p, n + two);
    }
    const bool ok = slow < 2 && (!known || big >= need + need / 4);
    if (VERBOSE)
        fprintf(stderr, "huge pages: %s (free in 2 MB blocks %s%llu MB, need about %llu MB, slow test faults %d of 8, worst %.2f ms)\n",
                ok ? "asked for" : "not asked for", known ? "" : "unknown ", (unsigned long long)(big >> 20),
                (unsigned long long)(need >> 20), slow, (double)worst * 1e-6);
    return ok;
}

// Reserves zeroed memory. `fallback` is a smaller size to try when the kernel
// refuses the first one (strict overcommit); 0 means there is none.
static u64 map_or_die(void** out, u64 bytes, bool huge, u64 fallback = 0) {
    bytes = (bytes + (2u << 20) - 1) & ~((u64)(2u << 20) - 1);
    void* p = mmap(nullptr, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (p == MAP_FAILED && fallback) {
        bytes = (fallback + (2u << 20) - 1) & ~((u64)(2u << 20) - 1);
        p = mmap(nullptr, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    }
    if (p == MAP_FAILED) die("cannot reserve %llu MB", (unsigned long long)(bytes >> 20));
#ifdef MADV_HUGEPAGE
    if (huge && (HUGE_MODE == 2 || (HUGE_MODE == 0 && HUGE_OK))) madvise(p, bytes, MADV_HUGEPAGE);
#endif
    *out = p;
    return bytes;
}

#ifdef SS_PROBE
// The probe's numbers. The scorer hands back no log, but it shows the first rows of campaign_daily
// that differ from the expected ones, values and all. So the probe writes the right tables and
// puts these numbers in the four counts of five rows: the campaign whose ID sorts first, on its
// first five days. Each count is 1e15 + a * 1e10 + b * 1e5 + c, three numbers from 0 to 99999,
// so row k carries numbers 12k to 12k + 11, in column order.
struct PvRow {
    std::string cid, chan;
    i32 day;
    i64 v[4];  // sessions, purchasing_sessions, revenue_cents, assisted_sessions
};
static i64 PV[60];
static std::vector<PvRow> PV_ROWS;
static bool PV_SAVE;
static void pv(int k, double v) {
    if (k >= 0 && k < 60) PV[k] = (i64)std::max(0.0, std::min(99999.0, v + 0.5));
}
#endif

static bool run(u64 tab_slots) {
    g_overflow.store(false);
    g_tab_used.store(0);
    g_next_chunk.store(0);

    // Sizes. Every bound below is a worst case for the bytes on disk.
    u64 est_rows = B_EVENTS / 74 + 1;
    u32 cb = 1;
    while ((1ull << cb) < (u64)NCAMP + 1) cb++;
    CBITS = cb;
    if (CBITS > 26) die("too many campaigns");
    double per_slot = (double)est_rows / (double)tab_slots;
    int lw = 12;
    {
        double want = 14000.0 / std::max(per_slot, 0.001);
        lw = 0;
        while ((double)(1ull << (lw + 1)) <= want * 1.41 && lw < 13) lw++;  // nearest power of two
        if (lw < 6) lw = 6;
        if (lw > 33 - (int)CBITS) lw = 33 - (int)CBITS;
    }
    LW = (u32)lw;
    TABN = (tab_slots + (1ull << LW) - 1) >> LW << LW;
    if (TABN >= 0xFFFF0000ull) die("too many user IDs");
    PB = (u32)(TABN >> LW);
    TAB_LIMIT = TABN / 4 * 3;
    TAB_QUOTA = std::max<u64>(1, TABN / (16 * (u64)T));
    PEB = 4;
    while (PEB < 13 && (est_rows >> PEB) > 20000) PEB++;
    if (FORCE_PEB >= 4 && FORCE_PEB <= 13) PEB = (u32)FORCE_PEB;
    u32 PE = 1u << PEB;

    void* tabp;
    u64 tab_bytes = map_or_die(&tabp, TABN * sizeof(Slot), true);
    TAB = (Slot*)tabp;

    // Records per input byte, at worst: 24 bytes for an 8-byte event line, and
    // far less for the survivors and the clicks, which need valid fields.
    u64 arena_bytes = B_EVENTS * 9 / 2 + B_CLICKS * 2 + (u64)(PE + 3ull * PB) * (u64)T * CHUNK + (64u << 20);
    void* arenap;
    arena_bytes = map_or_die(&arenap, arena_bytes, true,
                             B_EVENTS + B_CLICKS + (u64)(PE + 3ull * PB) * (u64)T * CHUNK + (64u << 20));
    ARENA = (u8*)arenap;
    MAX_CHUNKS = (u32)std::min<u64>(arena_bytes / CHUNK, 0xFFFFFFF0u);
    void* metap;
    u64 meta_bytes = map_or_die(&metap, (u64)MAX_CHUNKS * sizeof(ChunkMeta), false);
    META = (ChunkMeta*)metap;

    if (getenv("SS_PRETOUCH")) {
        // For measuring: touch the memory first, then restart the clock, so the
        // times show the work without the cost of first-touch page faults.
#ifndef MADV_POPULATE_WRITE
#define MADV_POPULATE_WRITE 23
#endif
        madvise(tabp, tab_bytes, MADV_POPULATE_WRITE);
        madvise(arenap, std::min<u64>(arena_bytes, B_EVENTS * 3 / 2 + B_CLICKS + (256u << 20)), MADV_POPULATE_WRITE);
        T0 = now_s();
        lap("memory touched, clock restarted");
    }
    if (VERBOSE && !LAP_QUIET)
        fprintf(stderr, "threads %d, table %llu slots, %u buckets of %u, %u event partitions, %u campaign bits\n", T,
                (unsigned long long)TABN, PB, 1u << LW, PE, CBITS);

    TC.clear();
    for (int i = 0; i < T; i++) {
        TCtx* t = new TCtx();
        t->tid = i;
        t->sc.init();
        TC.push_back(t);
    }
    auto cleanup = [&]() {
        for (auto t : TC) {
            t->se.release(), t->sk.release(), t->sm.release(), t->sp.release();
            t->sc.release();
            delete t;
        }
        TC.clear();
        munmap(tabp, tab_bytes), munmap(arenap, arena_bytes), munmap(metap, meta_bytes);
    };

    // ---- links
    {
        std::vector<Work> work;
        add_work(work, F_LINKS, 2, 1 << 20);
        std::atomic<size_t> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            LinkH h(t);
            for (;;) {
                size_t i = next.fetch_add(1);
                if (i >= work.size() || g_overflow.load()) break;
                const u8* buf;
                u64 len, cs, ce;
                work_view(t, work[i], buf, len, cs, ce);
                piece_populate(work[i]);
                parse_range<2, LinkH>(buf, len, cs, ce, t.sc, h);
                h.flush();
                piece_drop(work[i]);
            }
        });
        if (g_overflow.load()) return cleanup(), false;
        lap("links parsed");
        // Point every linked ID straight at its root.
        std::atomic<u64> at{0};
        const u64 step = 1 << 16;
        run_threads([&](int) {
            for (;;) {
                u64 a = at.fetch_add(step);
                if (a >= TABN) break;
                u64 b = std::min(TABN, a + step);
                // Other threads walk through these slots at the same time. Old parent or new,
                // both lead to the same root; the atomic store only makes that sharing explicit.
                // The parent of the slot 16 ahead is fetched early: the table is far larger than the cache.
                for (u64 i = a; i < b; i++) {
                    if (i + 16 < b) {
                        u32 ahead = __atomic_load_n(&TAB[i + 16].parent, __ATOMIC_RELAXED);
                        if (ahead) __builtin_prefetch(&TAB[ahead - 1]);
                    }
                    if (__atomic_load_n(&TAB[i].parent, __ATOMIC_RELAXED))
                        __atomic_store_n(&TAB[i].parent, uf_find_ro((u32)i) + 1, __ATOMIC_RELAXED);
                }
            }
        });
    }
    lap("links joined");

    // ---- events and clicks
    if (g_products_thread.joinable()) g_products_thread.join();
    {
        std::vector<Work> work;
        add_work(work, F_EVENTS, 0, 4 << 20);
        add_work(work, F_CLICKS, 1, 4 << 20);
        std::atomic<size_t> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            t.se.init(PE, ST_EREC, &t);
            t.sk.init(PB, ST_CLICK, &t);
            EventH eh(t);
            ClickH ch(t);
            for (;;) {
                size_t i = next.fetch_add(1);
                if (i >= work.size() || g_overflow.load()) break;
                const Work& w = work[i];
                const u8* buf;
                u64 len, cs, ce;
                work_view(t, w, buf, len, cs, ce);
                piece_populate(w);
                if (w.kind == 0) {
                    parse_range<7, EventH>(buf, len, cs, ce, t.sc, eh);
                    eh.flush();
                } else {
                    parse_range<4, ClickH>(buf, len, cs, ce, t.sc, ch);
                    ch.flush();
                }
                piece_drop(w);
            }
            t.se.finish();
            t.sk.finish();
        });
        if (g_overflow.load()) return cleanup(), false;
    }
    lap("events and clicks parsed");

    // ---- dedup, then scatter the survivors by person
    {
        L_EREC = build_lists(ST_EREC, PE);
        std::atomic<u32> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            t.sm.init(PB, ST_MAIN, &t);
            t.sp.init(PB, ST_PURCH, &t);
            for (;;) {
                u32 p = next.fetch_add(1);
                if (p >= PE) break;
                dedup_partition(t, p);
            }
            t.sm.finish();
            t.sp.finish();
        });
    }
    lap("events deduplicated");

    // ---- sessions, attribution, user_daily
    {
        L_MAIN = build_lists(ST_MAIN, PB);
        L_PURCH = build_lists(ST_PURCH, PB);
        L_CLICK = build_lists(ST_CLICK, PB);
        std::vector<u32> order(PB);
        for (u32 b = 0; b < PB; b++) order[b] = b;
        std::sort(order.begin(), order.end(), [](u32 a, u32 b) { return L_MAIN.count(a) > L_MAIN.count(b); });
        std::atomic<u32> next{0};
        run_threads([&](int tid) {
            TCtx& t = *TC[tid];
            t.cd.assign((size_t)NDAYS * (NCAMP + 1), CampAcc{0, 0, 0, 0, 0});
            t.wcnt.assign(NCAMP + 1, 0), t.wpos.assign(NCAMP + 1, 0), t.wact.assign(NCAMP + 1, 0);
            t.catsum.assign(NCAT + 1, 0), t.cattouched.assign(NCAT + 1, 0);
            t.ud.init(tid);
            for (;;) {
                u32 k = next.fetch_add(1);
                if (k >= PB) break;
                if (!L_MAIN.count(order[k])) break;
                process_bucket(t, order[k]);
            }
            t.ud.close();
        });
    }
    lap("sessions done, user_daily written");

    // ---- campaign_daily
    {
        size_t cells = (size_t)NDAYS * (NCAMP + 1);
        std::vector<CampAcc>& acc = TC[0]->cd;
        for (int i = 1; i < T; i++) {
            const CampAcc* o = TC[i]->cd.data();
            for (size_t k = 0; k < cells; k++) {
                acc[k].sessions += o[k].sessions, acc[k].purchasing += o[k].purchasing;
                acc[k].assisted += o[k].assisted, acc[k].revenue += o[k].revenue;
            }
        }
        Buf cid, chan, day, ses, pur, rev, ast;
        u64 rows = 0;
        for (u32 d = 0; d < NDAYS; d++) {
            for (u32 c = 0; c <= NCAMP; c++) {
                const CampAcc& a = acc[(size_t)d * (NCAMP + 1) + c];
                if (!a.sessions && !a.assisted) continue;
                cid.u32v((u32)CAMP_NAME[c].size()), cid.put(CAMP_NAME[c].data(), CAMP_NAME[c].size());
                chan.u32v((u32)CAMP_CHANNEL[c].size()), chan.put(CAMP_CHANNEL[c].data(), CAMP_CHANNEL[c].size());
                day.u32v((u32)(i32)(DAY0 + d));
                ses.i64v(a.sessions), pur.i64v(a.purchasing), rev.i64v(a.revenue), ast.i64v(a.assisted);
                rows++;
            }
        }
#ifdef SS_PROBE
        if (PV_SAVE) {
            PV_ROWS.clear();
            for (u32 d = 0; d < NDAYS; d++)
                for (u32 c = 0; c <= NCAMP; c++) {
                    const CampAcc& a = acc[(size_t)d * (NCAMP + 1) + c];
                    if (!a.sessions && !a.assisted) continue;
                    PV_ROWS.push_back({std::string(CAMP_NAME[c].data(), CAMP_NAME[c].size()),
                                       std::string(CAMP_CHANNEL[c].data(), CAMP_CHANNEL[c].size()), (i32)(DAY0 + d),
                                       {(i64)a.sessions, (i64)a.purchasing, (i64)a.revenue, (i64)a.assisted}});
                }
        }
#endif
        PqFile f;
        f.open(OUT_DIR + "/campaign_daily/part-000.parquet",
               {{"campaign_id", PQ_BYTES, 0, false}, {"channel", PQ_BYTES, 0, false}, {"day", PQ_INT32, 6, false},
                {"sessions", PQ_INT64, -1, false}, {"purchasing_sessions", PQ_INT64, -1, false},
                {"revenue_cents", PQ_INT64, -1, false}, {"assisted_sessions", PQ_INT64, -1, false}});
        if (rows) {
            PqPart parts[7] = {{cid.p, cid.n, nullptr}, {chan.p, chan.n, nullptr}, {day.p, day.n, nullptr},
                               {ses.p, ses.n, nullptr}, {pur.p, pur.n, nullptr}, {rev.p, rev.n, nullptr},
                               {ast.p, ast.n, nullptr}};
            f.row_group(rows, parts);
        }
        f.close();
        u64 ud_rows = 0;
        for (auto t : TC) ud_rows += t->ud.total;
        if (!ud_rows) {
            PqFile e;
            e.open(OUT_DIR + "/user_daily/part-000.parquet", user_daily_cols());
            e.close();
        }
        if (VERBOSE && !LAP_QUIET) {
            u64 tk[8] = {0, 0, 0, 0, 0, 0, 0, 0};
            for (auto t : TC)
                for (int k = 0; k < 8; k++) tk[k] += t->tk[k];
            fprintf(stderr,
                    "thread ms: dedup table %.0f, dedup scatter %.0f; buckets gather %.0f, sort events %.0f, purchases %.0f, "
                    "clicks %.0f, walk and write %.0f\n",
                    tk[0] * 1e-6, tk[1] * 1e-6, tk[2] * 1e-6, tk[3] * 1e-6, tk[4] * 1e-6, tk[5] * 1e-6, tk[6] * 1e-6);
            u64 r = 0, ok = 0, sv = 0, ck = 0, ss = 0;
            for (auto t : TC) r += t->n_rows, ok += t->n_ok, sv += t->n_surv, ck += t->n_clicks, ss += t->n_sessions;
            fprintf(stderr,
                    "event rows %llu, valid %llu, surviving %llu, clicks %llu, sessions %llu, user_daily rows %llu, "
                    "campaign_daily rows %llu, chunks %u, ids %llu+\n",
                    (unsigned long long)r, (unsigned long long)ok, (unsigned long long)sv, (unsigned long long)ck,
                    (unsigned long long)ss, (unsigned long long)ud_rows, (unsigned long long)rows, g_next_chunk.load(),
                    (unsigned long long)g_tab_used.load());
        }
    }
    lap("campaign_daily written");

    // Hand the memory back from every thread at once. Left alone, the kernel
    // frees it page by page on one core while the process exits.
    if (!getenv("SS_NOFREE")) {
        const u64 two = 2u << 20;
        u64 used = std::min<u64>(arena_bytes, ((u64)g_next_chunk.load() * CHUNK + two - 1) & ~(two - 1));
        run_threads([&](int tid) {
            auto slice = [&](void* base, u64 bytes) {
                u64 per = (bytes / (u64)T) & ~(two - 1);
                u64 a = per * (u64)tid, b = tid == T - 1 ? bytes : per * (u64)(tid + 1);
                if (b > a) madvise((u8*)base + a, b - a, MADV_DONTNEED);
            };
            slice(tabp, tab_bytes);
            slice(arenap, used);
        });
        lap("memory released");
    }
#ifdef SS_PROBE
    if (!PROBE_CHILD) cleanup();  // the probe runs the pipeline many times in one process
#endif
    return true;
}

#ifdef SS_PROBE
// A probe build (-DSS_PROBE). It measures the scoring machine and how long each step takes there.
// The scorer hands back no log, only the first rows that differ from the expected ones, so the
// probe writes the right tables and then puts its numbers in five rows of campaign_daily (see PV):
// the dev check fails, the panel shows the numbers, and the run can never be scored. Never the
// default build.
static void probe_cat(const char* path, const char* only = nullptr, int max_lines = 6) {
    FILE* f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "== %s: cannot open\n", path);
        return;
    }
    char line[8192];
    int n = 0;
    while (n < max_lines && fgets(line, sizeof line, f)) {
        if (only && !strstr(line, only)) continue;
        size_t len = strlen(line);
        if (len && line[len - 1] == '\n') line[len - 1] = 0;
        fprintf(stderr, "== %s: %s\n", path, line);
        n++;
    }
    fclose(f);
}
static std::string probe_text(const char* path) {
    std::string s;
    if (FILE* f = fopen(path, "r")) {
        char b[4096];
        size_t n;
        while (s.size() < (1u << 20) && (n = fread(b, 1, sizeof b, f)) > 0) s.append(b, n);
        fclose(f);
    }
    return s;
}
// The setting in force, which the kernel puts in brackets ("always [madvise] never"): 1 for the
// first word given, 2 for the next... 9 for another word, 0 when there is none.
static int probe_choice(const std::string& s, std::initializer_list<const char*> words) {
    size_t a = s.find('['), b = s.find(']');
    if (a == std::string::npos || b == std::string::npos || b < a) return 0;
    std::string w = s.substr(a + 1, b - a - 1);
    int i = 1;
    for (const char* x : words) {
        if (w == x) return i;
        i++;
    }
    return 9;
}
// The number after "key<spaces>:" at the start of a line, as in /proc/cpuinfo.
static double probe_field(const std::string& s, const char* key) {
    for (size_t p = s.find(key); p != std::string::npos; p = s.find(key, p + 1)) {
        if (p && s[p - 1] != '\n') continue;
        size_t q = p + strlen(key);
        while (q < s.size() && (s[q] == ' ' || s[q] == '\t')) q++;
        if (q < s.size() && s[q] == ':') return atof(s.c_str() + q + 1);
    }
    return 0;
}
// The file system mounted at mnt: 0 none, 1 overlay, 2 ext4, 3 xfs, 4 tmpfs, 5 virtiofs, 6 fuse,
// 7 9p, 8 nfs, 9 another.
static int probe_fs(const std::string& mi, const char* mnt) {
    int code = 0;
    for (size_t p = 0; p < mi.size();) {
        size_t e = mi.find('\n', p);
        if (e == std::string::npos) e = mi.size();
        std::string line = mi.substr(p, e - p);
        p = e + 1;
        char mp[512] = {0}, fs[64] = {0};
        size_t dash = line.find(" - ");
        if (dash == std::string::npos || sscanf(line.c_str(), "%*s %*s %*s %*s %511s", mp) != 1 || strcmp(mp, mnt)) continue;
        if (sscanf(line.c_str() + dash + 3, "%63s", fs) != 1) continue;
        static const char* names[] = {"overlay", "ext4", "xfs", "tmpfs", "virtiofs", "fuse", "9p", "nfs"};
        code = 9;
        for (int i = 0; i < 8; i++)
            if (!strncmp(fs, names[i], strlen(names[i]))) {
                code = i + 1;
                break;
            }
    }
    return code;
}
// campaign_daily again, from the rows the last saved run made, with the probe's numbers in the
// first five rows of the campaign whose ID sorts first.
static void pv_write() {
    if (PV_ROWS.empty()) return;
    size_t first = 0;
    for (size_t i = 1; i < PV_ROWS.size(); i++)
        if (PV_ROWS[i].cid < PV_ROWS[first].cid) first = i;
    std::vector<size_t> pick;
    for (size_t i = 0; i < PV_ROWS.size(); i++)
        if (PV_ROWS[i].cid == PV_ROWS[first].cid) pick.push_back(i);
    std::sort(pick.begin(), pick.end(), [](size_t a, size_t b) { return PV_ROWS[a].day < PV_ROWS[b].day; });
    if (pick.size() > 5) pick.resize(5);
    Buf cid, chan, day, ses, pur, rev, ast;
    for (size_t i = 0; i < PV_ROWS.size(); i++) {
        const PvRow& r = PV_ROWS[i];
        i64 v[4] = {r.v[0], r.v[1], r.v[2], r.v[3]};
        for (size_t k = 0; k < pick.size(); k++)
            if (pick[k] == i)
                for (int j = 0; j < 4; j++) {
                    const i64* f = PV + k * 12 + (size_t)j * 3;
                    v[j] = 1000000000000000LL + f[0] * 10000000000LL + f[1] * 100000LL + f[2];
                }
        cid.u32v((u32)r.cid.size()), cid.put(r.cid.data(), r.cid.size());
        chan.u32v((u32)r.chan.size()), chan.put(r.chan.data(), r.chan.size());
        day.u32v((u32)r.day);
        ses.i64v(v[0]), pur.i64v(v[1]), rev.i64v(v[2]), ast.i64v(v[3]);
    }
    PqFile f;
    f.open(OUT_DIR + "/campaign_daily/part-000.parquet",
           {{"campaign_id", PQ_BYTES, 0, false}, {"channel", PQ_BYTES, 0, false}, {"day", PQ_INT32, 6, false},
            {"sessions", PQ_INT64, -1, false}, {"purchasing_sessions", PQ_INT64, -1, false},
            {"revenue_cents", PQ_INT64, -1, false}, {"assisted_sessions", PQ_INT64, -1, false}});
    PqPart parts[7] = {{cid.p, cid.n, nullptr}, {chan.p, chan.n, nullptr}, {day.p, day.n, nullptr},
                       {ses.p, ses.n, nullptr}, {pur.p, pur.n, nullptr}, {rev.p, rev.n, nullptr},
                       {ast.p, ast.n, nullptr}};
    f.row_group(PV_ROWS.size(), parts);
    f.close();
    fprintf(stderr, "probe numbers written into %zu rows of campaign_daily\n", pick.size());
}
static double probe_touch(size_t mb, int threads, bool huge) {
    size_t n = mb << 20;
    char* p = (char*)mmap(nullptr, n, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (p == MAP_FAILED) return 0;
    if (huge) madvise(p, n, MADV_HUGEPAGE);
    double t0 = now_s();
    std::vector<std::thread> th;
    for (int i = 0; i < threads; i++)
        th.emplace_back([=] {
            for (size_t x = n / threads * i, b = n / threads * (i + 1); x < b; x += 4096) p[x] = 1;
        });
    for (auto& t : th) t.join();
    double t1 = now_s();
    long thp = -1;
    if (FILE* f = fopen("/proc/self/smaps_rollup", "r")) {
        char line[256];
        while (fgets(line, sizeof line, f))
            if (!strncmp(line, "AnonHugePages:", 14)) thp = atol(line + 14) / 1024;
        fclose(f);
    }
    double t2 = now_s();
    munmap(p, n);
    double t3 = now_s();
    fprintf(stderr, "probe touch %zu MB, %d threads, madvise huge %d: %.1f ms (%.2f us per 4K), huge now %ld MB, unmap %.1f ms\n",
            mb, threads, (int)huge, (t1 - t0) * 1e3, (t1 - t0) * 1e6 / (double)(n / 4096), thp, (t3 - t2) * 1e3);
    return (t1 - t0) * 1e3;
}
static double probe_clock(int threads) {
    const u64 N = 200000000ull;
    std::vector<std::thread> th;
    std::vector<double> secs((size_t)threads);
    for (int i = 0; i < threads; i++)
        th.emplace_back([&secs, i, N] {
            double t0 = now_s();
            u64 x = (u64)i + 1;
            for (u64 k = 0; k < N; k++) x = x * 6364136223846793005ull + 1442695040888963407ull;
            secs[(size_t)i] = now_s() - t0 + (x == 42 ? 1e-12 : 0);
        });
    for (auto& t : th) t.join();
    double worst = 0, best = 1e9;
    for (double s : secs) worst = std::max(worst, s), best = std::min(best, s);
    fprintf(stderr, "probe clock, %d threads: %.2f to %.2f GHz (4-cycle multiply-add chain)\n", threads,
            (double)N * 4 / worst / 1e9, (double)N * 4 / best / 1e9);
    return (double)N * 4 / worst / 1e9;
}
[[maybe_unused]] static void probe_env() {
    fprintf(stderr, "==== probe: the machine ====\n");
    {
        cpu_set_t cs;
        CPU_ZERO(&cs);
        int aff = sched_getaffinity(0, sizeof cs, &cs) == 0 ? CPU_COUNT(&cs) : 0;
        pv(0, (double)sysconf(_SC_NPROCESSORS_ONLN) * 100 + aff);
        std::string ci = probe_text("/proc/cpuinfo");
        pv(1, probe_field(ci, "model") * 100 + probe_field(ci, "stepping"));
        pv(2, probe_field(ci, "cpu MHz"));
        pv(3, probe_choice(probe_text("/sys/kernel/mm/transparent_hugepage/enabled"), {"always", "madvise", "never"}) * 10 +
                  probe_choice(probe_text("/sys/kernel/mm/transparent_hugepage/defrag"),
                               {"always", "defer", "defer+madvise", "madvise", "never"}));
        // CPUs the cgroup may use, times 100 (0: no limit), and its memory limit in MB.
        double q = 99998;
        std::string s = probe_text("/sys/fs/cgroup/cpu.max");
        if (!s.empty()) {
            double a = 0, b = 0;
            if (!s.compare(0, 3, "max")) q = 0;
            else if (sscanf(s.c_str(), "%lf %lf", &a, &b) == 2 && b > 0) q = a * 100 / b;
        } else {
            std::string a = probe_text("/sys/fs/cgroup/cpu/cpu.cfs_quota_us"), b = probe_text("/sys/fs/cgroup/cpu/cpu.cfs_period_us");
            if (!a.empty() && !b.empty()) q = atof(a.c_str()) < 0 ? 0 : atof(b.c_str()) > 0 ? atof(a.c_str()) * 100 / atof(b.c_str()) : q;
        }
        pv(4, q);
        s = probe_text("/sys/fs/cgroup/memory.max");
        if (s.empty()) s = probe_text("/sys/fs/cgroup/memory/memory.limit_in_bytes");
        pv(5, s.empty() ? 99998 : !s.compare(0, 3, "max") ? 99999 : atof(s.c_str()) / 1048576.0);
        std::string mi = probe_text("/proc/self/mountinfo");
        pv(6, probe_fs(mi, "/data") * 10 + probe_fs(mi, "/"));
    }
    probe_cat("/proc/version");
    probe_cat("/proc/cpuinfo", "model name", 1);
    probe_cat("/proc/cpuinfo", "flags", 1);
    probe_cat("/proc/cpuinfo", "cpu MHz", 16);
    probe_cat("/proc/cpuinfo", "cache size", 1);
    probe_cat("/sys/devices/system/cpu/cpu0/cache/index1/size");
    probe_cat("/sys/devices/system/cpu/cpu0/cache/index2/size");
    probe_cat("/sys/devices/system/cpu/cpu0/cache/index3/size");
    probe_cat("/sys/devices/system/cpu/cpu0/topology/thread_siblings_list");
    probe_cat("/sys/devices/system/cpu/online");
    probe_cat("/proc/self/status", "Cpus_allowed_list", 1);
    fprintf(stderr, "hardware_concurrency %u, threads %d, NCPU=%s, MEM_GB=%s\n", std::thread::hardware_concurrency(), T,
            getenv("NCPU") ? getenv("NCPU") : "", getenv("MEM_GB") ? getenv("MEM_GB") : "");
    probe_cat("/sys/kernel/mm/transparent_hugepage/enabled");
    probe_cat("/sys/kernel/mm/transparent_hugepage/defrag");
    probe_cat("/sys/kernel/mm/transparent_hugepage/khugepaged/defrag");
    probe_cat("/proc/sys/vm/overcommit_memory");
    probe_cat("/proc/meminfo", nullptr, 7);
    probe_cat("/proc/meminfo", "Huge", 8);
    probe_cat("/proc/meminfo", "Dirty", 1);
    probe_cat("/sys/fs/cgroup/memory.max");
    probe_cat("/sys/fs/cgroup/memory.high");
    probe_cat("/sys/fs/cgroup/cpu.max");
    probe_cat("/sys/fs/cgroup/cpuset.cpus.effective");
    probe_cat("/sys/fs/cgroup/memory/memory.limit_in_bytes");
    probe_cat("/sys/fs/cgroup/cpu/cpu.cfs_quota_us");
    probe_cat("/proc/self/mountinfo", " /data ", 2);
    probe_cat("/proc/self/mountinfo", " /output ", 2);
    probe_cat("/proc/self/mountinfo", " /scratch ", 2);
    probe_cat("/proc/self/mountinfo", " /tmp ", 2);
    probe_cat("/proc/self/mountinfo", " / ", 2);
    probe_cat("/proc/loadavg");

    // Was the input already in the page cache when the container started? Mapped input has no
    // descriptor left, so its own mapping is asked.
    const MFile* big = nullptr;
    u64 files = 0, cached = 0, pages = 0;
    for (auto* v : {&F_EVENTS, &F_CLICKS, &F_LINKS})
        for (auto& f : *v) {
            if (!big || f.size > big->size) big = &f;
            if ((f.fd < 0 && !f.p) || !f.size) continue;
            void* m = f.p ? (void*)f.p : mmap(nullptr, f.size, PROT_READ, MAP_SHARED, f.fd, 0);
            if (m == MAP_FAILED) continue;
            size_t np = (size_t)((f.size + 4095) / 4096);
            std::vector<unsigned char> vec(np);
            if (!mincore(m, f.size, vec.data()))
                for (unsigned char c : vec) cached += c & 1;
            pages += np, files++;
            if (!f.p) munmap(m, f.size);
        }
    fprintf(stderr, "probe input: %llu files, %llu MB, %.1f%% of pages already in the page cache\n",
            (unsigned long long)files, (unsigned long long)(pages >> 8), pages ? 100.0 * (double)cached / (double)pages : 0.0);
    pv(7, pages ? 1000.0 * (double)cached / (double)pages : 0.0);

    // Reading speed, the way the pipeline reads: 128 KB pieces of the largest file (copied out
    // of the mapping when the input is mapped).
    if (big && (big->fd >= 0 || big->p)) {
        u8* buf = (u8*)aligned_alloc(4096, 128 << 10);
        for (int pass = 0; pass < 2; pass++) {
            double t0 = now_s();
            u64 got = 0, lim = std::min<u64>(big->size, 1ull << 30);
            while (got < lim) {
                ssize_t r;
                if (big->fd >= 0) {
                    r = pread(big->fd, buf, 128 << 10, (off_t)got);
                } else {
                    r = (ssize_t)std::min<u64>(128 << 10, lim - got);
                    memcpy(buf, big->p + got, (size_t)r);
                }
                if (r <= 0) break;
                got += (u64)r;
            }
            double dt = now_s() - t0;
            fprintf(stderr, "probe read pass %d: %llu MB in %.1f ms, %.2f GB/s on one thread\n", pass,
                    (unsigned long long)(got >> 20), dt * 1e3, (double)got / dt / 1e9);
            pv(8 + pass, dt > 0 ? (double)got / dt / 1e6 : 0);
        }
        free(buf);
    }
    probe_touch(256, 1, false);
    pv(10, probe_touch(256, T, false) * 10);
    probe_touch(256, 1, true);
    pv(11, probe_touch(256, T, true) * 10);
    pv(12, probe_clock(1) * 100);
    probe_clock(T / 2 > 0 ? T / 2 : 1);
    pv(13, probe_clock(T) * 100);
}

// ---- the probe's benchmark: the pipeline at the size of the timed runs, on the scoring machine.
// The dev set is copied many times into files that live in memory (memfd), so nothing waits on a
// disk. Every copy has the last characters of each ID rotated, so the copies are different
// people, events and clicks of the same shape.
static inline bool probe_is36(char c) { return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z'); }
static inline void probe_rot(char& c) { c = c == '9' ? 'a' : c == 'z' ? '0' : (char)(c + 1); }
static double PROBE_START;
static double probe_elapsed() { return now_s() - PROBE_START; }

struct ProbeFile {
    u64 order;  // kind, source file, copy
    int fd;
    u64 size;
    int kind;  // 0 events, 1 clicks, 2 links
};
static std::vector<ProbeFile> PROBE_FILES;
static std::mutex PROBE_MU;
static std::vector<std::string> PROBE_BEST;  // the best run of each setting, printed again as the log's last lines

// Adds copies [from, to) of every CSV file of the dataset in src. Returns the bytes added.
static u64 probe_replicate(const std::string& src, int from, int to, int threads) {
    struct Job {
        std::string in;
        int kind;
    };
    std::vector<Job> jobs;
    const char* kinds[3] = {"events", "clicks", "links"};
    for (int kind = 0; kind < 3; kind++) {
        std::string dir = src + "/" + kinds[kind];
        std::vector<std::string> names;
        if (DIR* d = opendir(dir.c_str())) {
            while (dirent* e = readdir(d)) {
                std::string n = e->d_name;
                if (n.size() > 4 && n.compare(n.size() - 4, 4, ".csv") == 0) names.push_back(n);
            }
            closedir(d);
        }
        std::sort(names.begin(), names.end());
        for (auto& n : names) jobs.push_back({dir + "/" + n, kind});
    }
    std::atomic<size_t> next{0};
    std::atomic<u64> bytes{0};
    std::vector<std::thread> th;
    for (int w = 0; w < threads; w++)
        th.emplace_back([&] {
            for (;;) {
                size_t j = next.fetch_add(1);
                if (j >= jobs.size()) break;
                std::string s = read_small(jobs[j].in);
                std::vector<u32> last, prev;  // the characters to rotate: the end of fields 0 and 1
                size_t pos = s.find('\n');
                pos = pos == std::string::npos ? s.size() : pos + 1;  // the header stays as it is
                while (pos < s.size()) {
                    size_t le = s.find('\n', pos);
                    if (le == std::string::npos) le = s.size();
                    size_t fs = pos;
                    for (int k = 0; k < 2 && fs <= le; k++) {
                        const char* c = (const char*)memchr(s.data() + fs, ',', le - fs);
                        size_t fe = c ? (size_t)(c - s.data()) : le;
                        size_t a = fs, b = fe;
                        if (b - a >= 2 && s[a] == '"' && s[b - 1] == '"') a++, b--;
                        if (b > a + 1 && probe_is36(s[b - 1])) {
                            last.push_back((u32)(b - 1));
                            if (b > a + 2 && probe_is36(s[b - 2])) prev.push_back((u32)(b - 2));
                        }
                        fs = fe + 1;
                    }
                    pos = le + 1;
                }
                for (int c = 0; c < to; c++) {
                    if (c) {
                        for (u32 at : last) probe_rot(s[at]);
                        if (c % 36 == 0)
                            for (u32 at : prev) probe_rot(s[at]);
                    }
                    if (c < from || s.empty()) continue;
                    int fd = memfd_create("ssb", MFD_CLOEXEC);
                    if (fd < 0) return;
                    size_t done = 0;
                    while (done < s.size()) {
                        ssize_t r = write(fd, s.data() + done, s.size() - done);
                        if (r <= 0) break;
                        done += (size_t)r;
                    }
                    if (done != s.size()) {
                        close(fd);
                        return;
                    }
                    bytes += done;
                    std::lock_guard<std::mutex> g(PROBE_MU);
                    PROBE_FILES.push_back({((u64)jobs[j].kind << 40) | ((u64)j << 16) | (u64)c, fd, (u64)s.size(), jobs[j].kind});
                }
            }
        });
    for (auto& t : th) t.join();
    std::sort(PROBE_FILES.begin(), PROBE_FILES.end(), [](const ProbeFile& a, const ProbeFile& b) { return a.order < b.order; });
    return bytes.load();
}

static void probe_close_inputs(bool close_fds) {
    for (auto* v : {&F_EVENTS, &F_CLICKS, &F_LINKS}) {
        for (auto& f : *v) {
            if (f.fd >= 0 && close_fds) close(f.fd);
            if (f.p) munmap((void*)f.p, ((f.size + 4095) & ~4095ULL) + PADB);
        }
        v->clear();
    }
    B_EVENTS = B_CLICKS = B_LINKS = 0;
}
// Points the pipeline at the benchmark's files, read in pieces or mapped.
static void probe_use_copies(bool map) {
    probe_close_inputs(false);
    USE_MMAP = map, MMAP_MODE = map ? 2 : 0;
    for (auto& pf : PROBE_FILES) {
        MFile m;
        m.size = pf.size;
        if (!map) {
            m.fd = pf.fd;
        } else {
            u64 rounded = (m.size + 4095) & ~4095ULL;
            u8* r = (u8*)mmap(nullptr, rounded + PADB, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
            if (r == MAP_FAILED || mmap(r, m.size, PROT_READ, MAP_PRIVATE | MAP_FIXED, pf.fd, 0) == MAP_FAILED)
                die("cannot map a benchmark file");
            m.p = r;
        }
        (pf.kind == 0 ? F_EVENTS : pf.kind == 1 ? F_CLICKS : F_LINKS).push_back(m);
        (pf.kind == 0 ? B_EVENTS : pf.kind == 1 ? B_CLICKS : B_LINKS) += m.size;
    }
}
// Back to the real dataset.
static void probe_use_data(const std::string& dir) {
    probe_close_inputs(false);
    for (auto& pf : PROBE_FILES) close(pf.fd);
    PROBE_FILES.clear();
    USE_MMAP = false, MMAP_MODE = 0;
    F_EVENTS = map_dir(dir + "/events", B_EVENTS);
    F_CLICKS = map_dir(dir + "/clicks", B_CLICKS);
    F_LINKS = map_dir(dir + "/links", B_LINKS);
}

struct ProbeCfg {
    const char* name;
    bool half;  // half the threads
    int io;     // -1 read or mapped as the startup copy test chose, 0 read, 1 mapped
    int huge;   // HUGE_MODE: 0 where the startup test finds them cheap, 1 never, 2 always
    int peb;    // added to the default number of partition bits
    int stage;  // SS_STAGE: stop the parse early (1 scan, 2 split, 3 fields, 4 lookups), first round only
    bool pin = false;  // SS_PIN
    int alt = 0;       // another code path: 1 memory touched first (SS_PRETOUCH), 2 SS_FUSED, 3 SS_QUEUE, 4 SS_SLOTSORT, 5 SS_OLDSPLIT, 6 SS_NOSKEW
};
// Probe v3. The first line is the entry as it ships. "memory touched" times the run after every
// page it will use is already there, so its gap to the first line is what first-touch faults cost.
// The others are the code paths left in the source and off, tried here on the scorer's own CPU.
static const ProbeCfg PROBE_CFGS[] = {
    {"as shipped", false, -1, 0, 0, 0},
    {"memory touched", false, -1, 0, 0, 0, false, 1},
    {"slot sort", false, -1, 0, 0, 0, false, 4},
    {"fused split", false, -1, 0, 0, 0, false, 2},
    {"queued rows", false, -1, 0, 0, 0, false, 3},
    {"old split", false, -1, 0, 0, 0, false, 5},
    {"no skew", false, -1, 0, 0, 0, false, 6},
    {"partitions / 2", false, -1, 0, -1, 0},
};
struct ProbeRes {
    int n;
    double ms[16], lsys[16];
    long lflt[16];
    double sys0;
    long flt0;
    double tk[8];  // thread CPU ms summed over the threads: dedup table, scatter; buckets gather, sort, purchases, clicks, walk
    double user, sys;
    long faults;
};

// Runs the first nset settings `rounds` times, in turn. Each run is a child process that does what
// the real entry does and exits, so the time from fork to reaped includes giving the memory back,
// as the scorer's clock does. Prints one line per run and the best of each setting at the end.
// Probe numbers from pv0 (v3): what the entry decided, then at the practice size (`faults`) the
// best "as shipped" wall, its 7 steps (tenths of ms), user and sys ms, page faults / 100, sys ms and
// faults / 100 for five groups of steps, thread ms for the 7 parts of dedup and sessions; a few
// numbers for each other setting. At the final's size, a shorter list.
static void probe_bench(const char* label, int full, int rounds, double deadline, int pv0, int nset, bool faults) {
    const int NC = std::min(nset, (int)(sizeof PROBE_CFGS / sizeof PROBE_CFGS[0]));
    std::vector<double> best((size_t)NC, 1e18);
    std::vector<std::string> best_line((size_t)NC);
    std::vector<ProbeRes> best_res((size_t)NC);
    // The huge page test again, for a dataset of this size: its line in the log says what the
    // entry would decide here, and "as shipped" below runs with that decision.
    probe_use_copies(false);
    HUGE_OK = huge_pages_cheap((B_EVENTS + B_CLICKS) / 2 + ((B_EVENTS + B_CLICKS) / 500 + B_LINKS / 10 + 4096) * 16);
    fprintf(stderr, "bench %s: as shipped the input is %s\n", label, COPY_SLOW ? "mapped" : "read");
    pv(pv0, 100 + (HUGE_OK ? 10 : 0) + (COPY_SLOW ? 1 : 0));
    // Round -1 is one run of the first setting that is not counted: the first run after the
    // copies are made was slower than the same setting run later, whatever the setting.
    for (int round = -1; round < rounds; round++)
        for (int ci = 0; ci < NC; ci++) {
            const ProbeCfg& c = PROBE_CFGS[ci];
            if (round < 0 && ci) break;
            if (c.stage && round) continue;
            if (probe_elapsed() > deadline) {
                fprintf(stderr, "bench %s: out of time before round %d, setting %d\n", label, round, ci);
                round = rounds;
                break;
            }
            probe_use_copies(c.io < 0 ? COPY_SLOW : c.io == 1);
            T = c.half ? std::max(1, full / 2) : full;
            HUGE_MODE = c.huge;
            STAGE = c.stage;
            PIN = c.pin;
            u32 peb = 4;
            u64 est_rows = B_EVENTS / 74 + 1;
            while (peb < 13 && (est_rows >> peb) > 20000) peb++;
            FORCE_PEB = std::max(4, std::min(13, (int)peb + c.peb));
            u64 slots = (B_EVENTS + B_CLICKS) / 500 + B_LINKS / 10 + 4096;
            int pfd[2];
            if (pipe(pfd)) return;
            double w0 = now_s();
            pid_t pid = fork();
            if (pid == 0) {
                close(pfd[0]);
                signal(SIGALRM, SIG_DFL);
                alarm(20);  // a run that hangs is killed and reported, the probe goes on
                PROBE_CHILD = true;
                LAP_QUIET = true;
                switch (c.alt) {
                case 1: setenv("SS_PRETOUCH", "1", 1); break;
                case 2: FUSED = !FUSED; break;
                case 3: NOQUEUE = false; break;
                case 4: FULLSORT = false; break;
                case 5: OLDSPLIT = true; break;
                case 6: NOSKEW = true; break;
                }
                ProbeRes res{};
                rusage ru;
                getrusage(RUSAGE_SELF, &ru);
                res.sys0 = (double)ru.ru_stime.tv_sec * 1e3 + (double)ru.ru_stime.tv_usec * 1e-3;
                res.flt0 = ru.ru_minflt;
                do {
                    LAP_N = 0;
                    T0 = now_s();
                } while (!run(slots) && (slots *= 4));
                getrusage(RUSAGE_SELF, &ru);
                res.n = LAP_N;
                memcpy(res.ms, LAP_MS, sizeof res.ms);
                memcpy(res.lsys, LAP_SYS, sizeof res.lsys);
                memcpy(res.lflt, LAP_FLT, sizeof res.lflt);
                for (auto t : TC)
                    for (int k = 0; k < 8; k++) res.tk[k] += (double)t->tk[k] * 1e-6;
                res.user = (double)ru.ru_utime.tv_sec * 1e3 + (double)ru.ru_utime.tv_usec * 1e-3;
                res.sys = (double)ru.ru_stime.tv_sec * 1e3 + (double)ru.ru_stime.tv_usec * 1e-3;
                res.faults = ru.ru_minflt;
                if (write(pfd[1], &res, sizeof res) != (ssize_t)sizeof res) _exit(3);
                _exit(0);
            }
            close(pfd[1]);
            ProbeRes res{};
            ssize_t got = pid > 0 ? read(pfd[0], &res, sizeof res) : -1;
            close(pfd[0]);
            int status = 0;
            if (pid > 0) waitpid(pid, &status, 0);
            double wall = (now_s() - w0) * 1e3;
            if (got != (ssize_t)sizeof res || res.n <= 0 || res.n > 16) {
                fprintf(stderr, "bench %s %-17s failed, wait status %d\n", label, c.name, status);
                continue;
            }
            double total = res.ms[res.n - 1];
            char line[512];
            int n = snprintf(line, sizeof line, "bench %s %-17s T%-2d peb%-2d wall %7.1f ms (run %7.1f, exit %5.1f) | steps", label,
                             c.name, T, FORCE_PEB, wall, total, wall - total);
            for (int i = 0; i < res.n && n < 400; i++)
                n += snprintf(line + n, sizeof line - (size_t)n, " %.0f", res.ms[i] - (i ? res.ms[i - 1] : 0));
            snprintf(line + n, sizeof line - (size_t)n, " | user %.0f sys %.0f ms, faults %ld", res.user, res.sys, res.faults);
            if (round < 0) {
                fprintf(stderr, "warm-up, not counted: %s\n", line);
                continue;
            }
            fprintf(stderr, "%s\n", line);
            if (wall < best[(size_t)ci]) best[(size_t)ci] = wall, best_line[(size_t)ci] = line, best_res[(size_t)ci] = res;
        }
    for (int ci = 0; ci < NC; ci++) {
        if (best_line[(size_t)ci].empty()) continue;
        const ProbeRes& r = best_res[(size_t)ci];
        const int o = PROBE_CFGS[ci].alt == 1 ? 1 : 0;  // "memory touched" has one more lap first, at the touch
        if (r.n < o + 7) continue;
        // Step i of the run: 0 links, 1 join, 2 parse, 3 dedup, 4 sessions, 5 campaigns, 6 release.
        auto end = [&](int i) { return r.ms[o + i]; };
        auto step = [&](int i) { return (end(i) - (o + i ? r.ms[o + i - 1] : 0)) * 10; };
        auto sys_to = [&](int i) { return o + i < 0 ? r.sys0 : r.lsys[o + i]; };
        auto flt_to = [&](int i) { return o + i < 0 ? (double)r.flt0 : (double)r.lflt[o + i]; };
        if (faults) {  // the practice size: everything about "as shipped", a few numbers about the others
            switch (ci) {
            case 0: {
                pv(pv0 + 1, best[0] * 10);
                for (int i = 0; i < 7; i++) pv(pv0 + 2 + i, step(i));
                pv(pv0 + 9, r.user);
                pv(pv0 + 10, r.sys);
                pv(pv0 + 11, (double)r.faults / 100);
                const int g[6] = {-1, 1, 2, 3, 4, 6};  // links and join, parse, dedup, sessions, campaigns and release
                for (int k = 0; k < 5; k++) {
                    pv(pv0 + 12 + k, sys_to(g[k + 1]) - sys_to(g[k]));
                    pv(pv0 + 17 + k, (flt_to(g[k + 1]) - flt_to(g[k])) / 100);
                }
                for (int k = 0; k < 7; k++) pv(pv0 + 22 + k, r.tk[k]);
                break;
            }
            case 1:
                pv(pv0 + 29, end(6) * 10);  // the run after the touch, to the memory released
                pv(pv0 + 30, step(2));
                pv(pv0 + 31, step(3));
                pv(pv0 + 32, step(4));
                pv(pv0 + 33, (flt_to(6) - flt_to(-1)) / 100);
                break;
            case 2:
                pv(pv0 + 34, best[(size_t)ci] * 10);
                pv(pv0 + 35, step(4));
                break;
            default: pv(pv0 + 33 + ci, best[(size_t)ci] * 10);
            }
        } else if (ci == 0) {  // the final's size
            pv(pv0 + 1, best[0] * 10);
            pv(pv0 + 2, step(2));
            pv(pv0 + 3, step(3));
            pv(pv0 + 4, step(4));
            pv(pv0 + 6, sys_to(4) - sys_to(3));
            pv(pv0 + 7, (flt_to(4) - flt_to(3)) / 100);
            for (int k = 0; k < 7; k++) pv(pv0 + 8 + k, r.tk[k]);
        } else if (ci == 1) {
            pv(pv0 + 5, end(6) * 10);
            pv(pv0 + 15, step(4));
        }
    }
    fprintf(stderr, "==== bench %s: the best run of each setting. wall is fork to reaped, so it has the cost of exiting. "
                    "steps: links, join, parse, dedup, sessions, campaigns, release ====\n",
            label);
    for (int ci = 0; ci < NC; ci++)
        if (!best_line[(size_t)ci].empty()) {
            fprintf(stderr, "best  %s\n", best_line[(size_t)ci].c_str());
            PROBE_BEST.push_back(best_line[(size_t)ci]);
        }
    FORCE_PEB = 0, HUGE_MODE = 0, STAGE = 0, PIN = false, T = full;
}
#endif

int main() {
    T0 = now_s();
    VERBOSE = getenv("SS_VERBOSE") != nullptr;
#ifdef SS_PROBE
    VERBOSE = true;
#endif
    const char* e;
    std::string data = (e = getenv("DATA_DIR")) && *e ? e : "/data";
    OUT_DIR = (e = getenv("OUTPUT_DIR")) && *e ? e : "/output";
    int ncpu = (e = getenv("NCPU")) ? atoi(e) : 0;
    if (ncpu <= 0) ncpu = (int)std::thread::hardware_concurrency();
    T = std::max(1, std::min(ncpu, 32));
    if ((e = getenv("SS_THREADS")) && atoi(e) > 0) T = std::min(atoi(e), 32);

    init_calendar();
    std::string manifest = read_small(data + "/manifest.json");
    WS = manifest_ts(manifest, "window_start");
    WE = manifest_ts(manifest, "window_end");
    if (WE <= WS) die("window_end is not after window_start");
    if (WE - WS + WEEKMS >= (1LL << 31)) die("a window longer than 17 days is not supported");
    CWS = WS - WEEKMS;
    i64 ws_sec = WS >= 0 ? WS / 1000 : -((-WS + 999) / 1000);
    ING_BASE = ws_sec - (1LL << 31);
    DAY0 = WS >= 0 ? WS / DAYMS : -((-WS + DAYMS - 1) / DAYMS);
    WS_OFF = (u32)(WS - DAY0 * DAYMS);
    i64 last = WE - 1;
    i64 last_day = last >= 0 ? last / DAYMS : -((-last + DAYMS - 1) / DAYMS);
    NDAYS = (u32)(last_day - DAY0 + 1);

    // With one thread the products load in line. Nothing then depends on how two threads take
    // turns, so the training run of the profile-guided build counts the same every time.
    if (T == 1) load_products(data);
    else g_products_thread = std::thread([data] { load_products(data); });
    load_campaigns(data);
    if ((e = getenv("SS_MMAP"))) USE_MMAP = true, MMAP_MODE = std::max(1, atoi(e));
    if (getenv("SS_NOHUGE")) HUGE_MODE = 1;
    else if (getenv("SS_HUGE")) HUGE_MODE = 2;
    PIN = getenv("SS_PIN") != nullptr;
    if (PIN) pin_init();
    if ((e = getenv("SS_PEB"))) FORCE_PEB = atoi(e);
    if (getenv("SS_OLDSPLIT")) OLDSPLIT = true;
    if ((e = getenv("SS_FUSED"))) FUSED = atoi(e) != 0;
    if (getenv("SS_NOSKEW")) NOSKEW = true;
    if (getenv("SS_QUEUE")) NOQUEUE = false;
    if (getenv("SS_SLOTSORT")) FULLSORT = false;
#if defined(SS_PROBE) || defined(SS_STAGES)
    if ((e = getenv("SS_STAGE"))) STAGE = atoi(e);
#endif
    F_EVENTS = map_dir(data + "/events", B_EVENTS);
    F_CLICKS = map_dir(data + "/clicks", B_CLICKS);
    F_LINKS = map_dir(data + "/links", B_LINKS);
    // Reading or mapping the input. Reading wins where the kernel copies fast (4% over
    // mapping on Intel runners). On other machines the same copy runs at a fifth of the
    // speed and mapping wins by far. So time the copy of 8 MB the way the pipeline reads,
    // and map the files when it is slow. SS_READ: always read. SS_MMAP: always map.
    if (!USE_MMAP && !getenv("SS_READ")) {
        MFile* big = nullptr;
        for (auto& f : F_EVENTS)
            if (!big || f.size > big->size) big = &f;
        const size_t piece = 128 << 10, pieces = 64;
        if (big && big->fd >= 0 && big->size >= 2 * piece * pieces) {
            u8* buf = (u8*)aligned_alloc(4096, piece);
            memset(buf, 1, piece);
            size_t got = 0;
            const u64 t0 = mono_ns();
            for (size_t i = 0; i < pieces; i++) {
                ssize_t r = pread(big->fd, buf, piece, (off_t)(i * piece));
                if (r <= 0) break;
                got += (size_t)r;
            }
            const u64 dt = mono_ns() - t0;
            free(buf);
            const double gbs = dt ? (double)got / (double)dt : 99.0;  // bytes per ns
            const bool slow = got == piece * pieces && gbs < 3.0;
            if (VERBOSE) fprintf(stderr, "kernel copy %.1f GB/s: the input is %s\n", gbs, slow ? "mapped" : "read");
            if (slow) {
                COPY_SLOW = true;
                USE_MMAP = true, MMAP_MODE = 2;
                for (auto* v : {&F_EVENTS, &F_CLICKS, &F_LINKS})
                    for (auto& f : *v) map_open_file(f);
            }
        }
    }
    mkdir(OUT_DIR.c_str(), 0777);
    mkdir((OUT_DIR + "/user_daily").c_str(), 0777);
    mkdir((OUT_DIR + "/campaign_daily").c_str(), 0777);
    lap("inputs mapped");

    u64 slots = (B_EVENTS + B_CLICKS) / 500 + B_LINKS / 10 + 4096;
    // Huge pages are asked for where they are cheap, unless SS_NOHUGE or SS_HUGE settled it above.
    if (HUGE_MODE == 0) HUGE_OK = huge_pages_cheap((B_EVENTS + B_CLICKS) / 2 + slots * 16);
    if ((e = getenv("SS_SLOTS")) && atoll(e) > 0) slots = (u64)atoll(e);  // testing: force the regrow path
#ifdef SS_PROBE
    PROBE_START = T0;
    // Never run into the scorer's own time limit: a probe that is cut off may hand back no log.
    signal(SIGALRM, [](int) {
        static const char m[] = "==== probe: out of time, stopping ====\n";
        ssize_t r = write(2, m, sizeof m - 1);
        (void)r;
        _exit(0);
    });
    alarm(165);
    if (g_products_thread.joinable()) g_products_thread.join();  // the benchmark forks: no thread may be left running
    pv(0, 3);  // probe v3; probe_env's machine numbers are known from v2 and left out
    pv(2, T * 100 + (HUGE_OK ? 10 : 0) + (COPY_SLOW ? 1 : 0));
    {
        const int full = T;
        // The real tables first, so a probe cut short still leaves its numbers: the run keeps the
        // campaign rows, and campaign_daily is written again with the numbers after each part.
        {
            fprintf(stderr, "==== probe: pipeline run on the dev set, %d threads, %.1f s since the start ====\n", T, probe_elapsed());
            u64 s = slots;
            double t = now_s();
            T0 = t;
            PV_SAVE = true;
            while (!run(s)) s *= 4;
            PV_SAVE = false;
            pv(1, (now_s() - t) * 1e4);
            lap("done");
            pv_write();
        }
        // The benchmark: the dev set 20 times over (the size of the practice run), every setting
        // twice, then 60 times over (the size of the final) if there is time. The dev check gives
        // a submission 3 minutes; everything here stops by itself well before that.
        int copies = (e = getenv("SS_PROBE_COPIES")) ? atoi(e) : 20;
        int big = (e = getenv("SS_PROBE_BIG")) ? atoi(e) : 60;
        rlimit nof;
        if (!getrlimit(RLIMIT_NOFILE, &nof)) {
            nof.rlim_cur = nof.rlim_max;
            setrlimit(RLIMIT_NOFILE, &nof);
        }
        pin_init();
        if (copies > 0) {
            // The original fds are closed by hand here: the real dataset is opened again after the benchmark.
            probe_close_inputs(true);
            std::string scratch = (e = getenv("SCRATCH_DIR")) && *e ? e : "/scratch";
            std::string real_out = OUT_DIR, bench_out = scratch + "/ssb-out";
            auto save = [&] {
                std::string keep = OUT_DIR;
                OUT_DIR = real_out;
                pv_write();
                OUT_DIR = keep;
            };
            bool own_out = mkdir(bench_out.c_str(), 0777) == 0;
            if (own_out) {
                OUT_DIR = bench_out;
                mkdir((OUT_DIR + "/user_daily").c_str(), 0777);
                mkdir((OUT_DIR + "/campaign_daily").c_str(), 0777);
            }
            double t = now_s();
            u64 wrote = probe_replicate(data, 0, copies, full);
            fprintf(stderr, "==== probe: %d copies of the dev set in memory, %zu files, %llu MB in %.1f s (%.1f s since the start), "
                            "output to %s ====\n",
                    copies, PROBE_FILES.size(), (unsigned long long)(wrote >> 20), now_s() - t, probe_elapsed(), OUT_DIR.c_str());
            char label[16];
            snprintf(label, sizeof label, "x%d", copies);
            if (wrote) probe_bench(label, full, 2, 80, 3, 99, true);
            save();
            if (wrote && big > copies && probe_elapsed() < 70) {
                t = now_s();
                wrote = probe_replicate(data, copies, big, full);
                fprintf(stderr, "==== probe: %d more copies, %zu files, %llu MB in %.1f s (%.1f s since the start) ====\n", big - copies,
                        PROBE_FILES.size(), (unsigned long long)(wrote >> 20), now_s() - t, probe_elapsed());
                snprintf(label, sizeof label, "x%d", big);
                if (wrote) probe_bench(label, full, 2, 135, 44, 2, false);
                save();
            }
            if (own_out) {  // leave the scratch disk as it was found
                for (const char* kind : {"/user_daily", "/campaign_daily", ""}) {
                    std::string dir = bench_out + kind;
                    if (DIR* d = opendir(dir.c_str())) {
                        while (dirent* en = readdir(d))
                            if (en->d_name[0] != '.') unlink((dir + "/" + en->d_name).c_str());
                        closedir(d);
                    }
                    rmdir(dir.c_str());
                }
            }
            OUT_DIR = real_out;
            probe_use_data(data);
        }
        // The dev set again: half the threads, then all of them from an empty folder, so
        // user_daily is left complete and right whatever the benchmark did.
        const int plan[2] = {std::max(1, full / 2), full};
        for (int r = 0; r < 2; r++) {
            T = plan[r];
            if (r == 1) {
                std::string dir = OUT_DIR + "/user_daily";
                if (DIR* d = opendir(dir.c_str())) {
                    while (dirent* en = readdir(d))
                        if (en->d_name[0] != '.') unlink((dir + "/" + en->d_name).c_str());
                    closedir(d);
                }
            }
            fprintf(stderr, "==== probe: pipeline run %d on the dev set, %d threads, %.1f s since the start ====\n", r, T,
                    probe_elapsed());
            double t = now_s();
            T0 = t;
            PV_SAVE = r == 1;
            slots = (B_EVENTS + B_CLICKS) / 500 + B_LINKS / 10 + 4096;
            while (!run(slots)) slots *= 4;
            PV_SAVE = false;
            lap("done");
        }
        pv_write();
        fprintf(stderr, "probe numbers:");
        for (int k = 0; k < 60; k++) fprintf(stderr, " %lld", (long long)PV[k]);
        fprintf(stderr, "\n");
        // Once more at the very end, in case the scorer hands back only the end of a log.
        fprintf(stderr, "==== the benchmark's best runs again (wall = fork to reaped; steps: links, join, parse, dedup, "
                        "sessions, campaigns, release) ====\n");
        for (auto& line : PROBE_BEST) fprintf(stderr, "best  %s\n", line.c_str());
        fprintf(stderr, "==== probe: done, the numbers are in campaign_daily's first rows ====\n");
        fflush(stderr);
        _exit(0);
    }
#endif
    while (!run(slots)) {
        if (VERBOSE) fprintf(stderr, "user table too small at %llu slots, retrying\n", (unsigned long long)slots);
        slots *= 4;
    }
    lap("done");
    fflush(stderr);
    // The counting build of a profile-guided compile writes its counters here. No other build
    // has the function, so they go straight to the exit, and both compiles see the same code.
    if (__gcov_dump) __gcov_dump();
    _exit(0);
}
